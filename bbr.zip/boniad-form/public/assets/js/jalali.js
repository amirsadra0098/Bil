/* تبدیل تاریخ شمسی/میلادی + تقویم انتخاب تاریخ */
(function (global) {
  'use strict';

  function g2j(gy, gm, gd) {
    var gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
    var gy2 = (gm > 2) ? (gy + 1) : gy;
    var days = 355666 + (365 * gy) + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100)
             + Math.floor((gy2 + 399) / 400) + gd + gdm[gm - 1];
    var jy = -1595 + (33 * Math.floor(days / 12053));
    days %= 12053;
    jy += 4 * Math.floor(days / 1461);
    days %= 1461;
    if (days > 365) { jy += Math.floor((days - 1) / 365); days = (days - 1) % 365; }
    var jm, jd;
    if (days < 186) { jm = 1 + Math.floor(days / 31); jd = 1 + (days % 31); }
    else { jm = 7 + Math.floor((days - 186) / 30); jd = 1 + ((days - 186) % 30); }
    return [jy, jm, jd];
  }

  function j2g(jy, jm, jd) {
    jy += 1595;
    var days = -355668 + (365 * jy) + (Math.floor(jy / 33) * 8) + Math.floor(((jy % 33) + 3) / 4)
             + jd + ((jm < 7) ? (jm - 1) * 31 : ((jm - 7) * 30) + 186);
    var gy = 400 * Math.floor(days / 146097);
    days %= 146097;
    if (days > 36524) {
      gy += 100 * Math.floor(--days / 36524);
      days %= 36524;
      if (days >= 365) days++;
    }
    gy += 4 * Math.floor(days / 1461);
    days %= 1461;
    if (days > 365) { gy += Math.floor((days - 1) / 365); days = (days - 1) % 365; }
    var gd = days + 1;
    var leap = ((gy % 4 === 0 && gy % 100 !== 0) || (gy % 400 === 0));
    var sal = [0, 31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    var gm;
    for (gm = 0; gm < 13 && gd > sal[gm]; gm++) gd -= sal[gm];
    return [gy, gm, gd];
  }

  function jMonthLen(jy, jm) {
    if (jm <= 6) return 31;
    if (jm <= 11) return 30;
    // اسفند: بررسی کبیسه با مقایسه اول فروردین سال بعد
    var g = j2g(jy + 1, 1, 1);
    var d = new Date(g[0], g[1] - 1, g[2]);
    d.setDate(d.getDate() - 1);
    return g2j(d.getFullYear(), d.getMonth() + 1, d.getDate())[2];
  }

  var MONTHS = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
                'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
  var WDAYS = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];

  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function fmt(y, m, d) { return y + '/' + pad(m) + '/' + pad(d); }

  function today() {
    var n = new Date();
    return g2j(n.getFullYear(), n.getMonth() + 1, n.getDate());
  }

  /** شنبه = 0 */
  function weekdayOfJ(jy, jm, jd) {
    var g = j2g(jy, jm, jd);
    var w = new Date(g[0], g[1] - 1, g[2]).getDay(); // یکشنبه = 0
    return (w + 1) % 7;
  }

  global.Jalali = {
    g2j: g2j, j2g: j2g, monthLen: jMonthLen, MONTHS: MONTHS, WDAYS: WDAYS,
    today: today, fmt: fmt, weekday: weekdayOfJ, pad: pad
  };

  /* ------------------------------------------------------------ تقویم */

  var openPicker = null;

  function closePicker() {
    if (openPicker) { openPicker.el.remove(); openPicker = null; }
  }

  document.addEventListener('click', function (ev) {
    if (!openPicker) return;
    // کلیک‌های داخل تقویم توسط خود تقویم علامت‌گذاری می‌شوند؛
    // چون بعد از رسم دوباره، عنصر کلیک‌شده از DOM جدا می‌شود و
    // بررسی contains دیگر جواب نمی‌دهد.
    if (ev.__dpInside) return;
    if (openPicker.wrap.contains(ev.target)) return;
    closePicker();
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closePicker(); });

  function faDigits(v) {
    return String(v).replace(/[0-9]/g, function (c) { return '۰۱۲۳۴۵۶۷۸۹'[+c]; });
  }

  function buildPicker(input, wrap) {
    var t = today();
    var parts = String(input.value || '').replace(/[۰-۹]/g, function (c) {
      return '۰۱۲۳۴۵۶۷۸۹'.indexOf(c);
    }).split('/');

    var cy = parseInt(parts[0], 10) || t[0];
    var cm = parseInt(parts[1], 10) || t[1];
    var sel = (parts.length === 3 && parts[0] && parts[2]) ? [cy, cm, parseInt(parts[2], 10)] : null;

    var minY = parseInt(input.dataset.minYear, 10) || (t[0] - 100);
    var maxY = parseInt(input.dataset.maxYear, 10) || (t[0] + 5);
    if (cy < minY) minY = cy;
    if (cy > maxY) maxY = cy;

    var el = document.createElement('div');
    el.className = 'dp';

    function head() {
      // در چیدمان راست‌چین، اولین دکمه سمت راست می‌نشیند.
      // «ماه بعد» راست با فلش ‹›‹ و «ماه قبل» چپ با فلش ‹‹› تا جهت‌ها بیرون‌سو و آشنا باشند.
      var h = '<div class="dp-head">'
            + '<button type="button" data-a="nm" title="ماه بعد" aria-label="ماه بعد">&#8250;</button>'
            + '<select class="dp-sel dp-m" aria-label="ماه">';
      for (var m = 1; m <= 12; m++) {
        h += '<option value="' + m + '"' + (m === cm ? ' selected' : '') + '>' + MONTHS[m - 1] + '</option>';
      }
      h += '</select><select class="dp-sel dp-y" aria-label="سال">';
      for (var y = maxY; y >= minY; y--) {
        h += '<option value="' + y + '"' + (y === cy ? ' selected' : '') + '>' + faDigits(y) + '</option>';
      }
      return h + '</select>'
        + '<button type="button" data-a="pm" title="ماه قبل" aria-label="ماه قبل">&#8249;</button>'
        + '</div>';
    }

    function foot() {
      return '<div class="dp-foot">'
        + '<button type="button" data-a="clear">پاک کردن</button>'
        + '</div>';
    }

    function render() {
      var h = head() + '<div class="dp-grid">';
      for (var w = 0; w < 7; w++) h += '<div class="wd">' + WDAYS[w] + '</div>';

      var first = weekdayOfJ(cy, cm, 1);
      for (var s = 0; s < first; s++) h += '<div></div>';

      var len = jMonthLen(cy, cm);
      for (var d = 1; d <= len; d++) {
        var cls = [];
        if (t[0] === cy && t[1] === cm && t[2] === d) cls.push('today');
        if (sel && sel[0] === cy && sel[1] === cm && sel[2] === d) cls.push('sel');
        h += '<button type="button" class="' + cls.join(' ') + '" data-d="' + d + '">' + faDigits(d) + '</button>';
      }
      el.innerHTML = h + '</div>' + foot();
    }

    function pick(y, m, d) {
      input.value = fmt(y, m, d);
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('change', { bubbles: true }));
      closePicker();
    }

    el.addEventListener('click', function (ev) {
      ev.__dpInside = true;                       // مانع بسته شدن پس از رسم دوباره
      var b = ev.target.closest('button');
      if (!b) return;
      ev.preventDefault();

      if (b.hasAttribute('data-d')) { pick(cy, cm, parseInt(b.getAttribute('data-d'), 10)); return; }

      var a = b.getAttribute('data-a');
      if (a === 'pm') { cm--; if (cm < 1) { cm = 12; cy--; } render(); }
      else if (a === 'nm') { cm++; if (cm > 12) { cm = 1; cy++; } render(); }
      else if (a === 'clear') {
        input.value = '';
        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
        closePicker();
      }
    });

    el.addEventListener('change', function (ev) {
      ev.__dpInside = true;
      if (ev.target.classList.contains('dp-m')) { cm = parseInt(ev.target.value, 10); render(); }
      else if (ev.target.classList.contains('dp-y')) { cy = parseInt(ev.target.value, 10); render(); }
    });
    el.addEventListener('mousedown', function (ev) { ev.__dpInside = true; });

    render();
    wrap.appendChild(el);

    var r = input.getBoundingClientRect();
    el.style.top = (input.offsetTop + input.offsetHeight + 4) + 'px';
    el.style.insetInlineStart = '0px';
    if (r.bottom + el.offsetHeight + 8 > window.innerHeight && r.top > el.offsetHeight + 8) {
      el.style.top = (input.offsetTop - el.offsetHeight - 4) + 'px';
    }
    openPicker = { el: el, input: input, wrap: wrap };
  }

  global.attachDatePicker = function (input) {
    var wrap = input.closest('.date-wrap');
    if (!wrap) return;
    function open(ev) {
      if (ev) ev.__dpInside = true;
      if (openPicker && openPicker.input === input) return;
      closePicker();
      buildPicker(input, wrap);
    }
    input.addEventListener('focus', open);
    input.addEventListener('click', open);
    var btn = wrap.querySelector('.cal-btn');
    if (btn) btn.addEventListener('click', function (e) {
      e.preventDefault();
      e.__dpInside = true;
      if (openPicker && openPicker.input === input) { closePicker(); return; }
      closePicker();
      buildPicker(input, wrap);
      input.focus({ preventScroll: true });
    });
  };
})(window);
