/* منطق فرم چندمرحله‌ای */
(function () {
  'use strict';

  var form = document.getElementById('mainForm');
  if (!form) return;

  var steps    = Array.prototype.slice.call(form.querySelectorAll('.step'));
  var chips    = Array.prototype.slice.call(document.querySelectorAll('.step-chip'));
  var progress = document.querySelector('.progress-line i');
  var btnPrev  = document.getElementById('btnPrev');
  var btnNext  = document.getElementById('btnNext');
  var btnSend  = document.getElementById('btnSend');
  var counter  = document.getElementById('stepCounter');
  var current  = 0;
  var DRAFT_KEY = 'bmform-draft-v1';

  var FA = '۰۱۲۳۴۵۶۷۸۹', AR = '٠١٢٣٤٥٦٧٨٩';
  function toEn(s) {
    return String(s).replace(/[۰-۹]/g, function (c) { return FA.indexOf(c); })
                    .replace(/[٠-٩]/g, function (c) { return AR.indexOf(c); });
  }
  function faNum(s) { return String(s).replace(/[0-9]/g, function (c) { return FA[+c]; }); }

  /* یکسان‌سازی نویسه‌های عربی با معادل فارسی */
  var FA_MAP = { 'ي': 'ی', 'ى': 'ی', 'ك': 'ک',
                 'ڪ': 'ک', 'ؤ': 'و', 'إ': 'ا',
                 'أ': 'ا', 'ـ': '', ' ': ' ' };
  function faNormalize(s) {
    return String(s).replace(/[يىكڪؤإأـ ]/g,
      function (c) { return FA_MAP[c]; });
  }
  var FA_RE = /^[ؠ-يٮ-ۓ‌‏\s]+$/;

  /* ------------------------------------------------------- اعتبارسنجی */

  function validNid(code) {
    code = toEn(code).replace(/\D/g, '');
    if (code.length !== 10) return false;
    if (/^(\d)\1{9}$/.test(code)) return false;
    var sum = 0;
    for (var i = 0; i < 9; i++) sum += (+code[i]) * (10 - i);
    var r = sum % 11, c = +code[9];
    return r < 2 ? c === r : c === 11 - r;
  }

  function fieldError(el) {
    var v = toEn((el.value || '').trim());
    var t = el.dataset.vtype || '';
    if (el.required && v === '') return 'این فیلد الزامی است.';
    if (v === '') return null;
    if (t === 'nid' && !validNid(v)) return 'کد ملی معتبر نیست.';
    if (t === 'tel' && el.dataset.mobile === '1' && !/^09\d{9}$/.test(v.replace(/\D/g, ''))) return 'شماره همراه باید ۱۱ رقم و با ۰۹ شروع شود.';
    if (t === 'postal' && v.replace(/\D/g, '').length !== 10) return 'کد پستی باید ۱۰ رقم باشد.';
    if (t === 'date' && !/^\d{4}\/\d{1,2}\/\d{1,2}$/.test(v)) return 'قالب تاریخ باید ۱۴۰۳/۰۵/۱۲ باشد.';
    if (t === 'email' && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v)) return 'قالب ایمیل صحیح نیست.';
    if (t === 'fa' && !FA_RE.test((el.value || '').trim())) return 'فقط با حروف فارسی بنویسید.';
    return null;
  }

  function showError(el, msg) {
    var box = el.closest('.f') || el.parentElement;
    var old = box.querySelector('.field-err');
    if (old) old.remove();
    box.classList.toggle('has-err', !!msg);
    if (msg) {
      var s = document.createElement('span');
      s.className = 'field-err';
      s.textContent = msg;
      box.appendChild(s);
    }
  }

  function validateStep(i, focus) {
    var ok = true, first = null;
    var els = steps[i].querySelectorAll('input, select, textarea');
    for (var k = 0; k < els.length; k++) {
      var el = els[k];
      if (el.type === 'hidden' || el.disabled) continue;
      var msg = fieldError(el);
      showError(el, msg);
      if (msg) { ok = false; if (!first) first = el; }
    }
    // رادیوی الزامی (تعهدنامه)
    var reqGroups = steps[i].querySelectorAll('[data-req-group="1"]');
    for (var g = 0; g < reqGroups.length; g++) {
      var grp = reqGroups[g];
      var checked = grp.querySelector('input:checked');
      var box = grp.closest('.f');
      var e0 = box.querySelector('.field-err');
      if (e0) e0.remove();
      box.classList.toggle('has-err', !checked);
      if (!checked) {
        ok = false;
        var s = document.createElement('span');
        s.className = 'field-err';
        s.textContent = 'انتخاب این گزینه الزامی است.';
        box.appendChild(s);
        if (!first) first = grp;
      }
    }
    if (!ok && focus && first) {
      first.scrollIntoView({ behavior: 'smooth', block: 'center' });
      if (first.focus) try { first.focus({ preventScroll: true }); } catch (e) {}
    }
    chips[i].classList.toggle('has-error', !ok);
    return ok;
  }

  /* --------------------------------------------------------- ناوبری */

  function isSingle() {
    var r = form.querySelector('input[name="f[personal][marital]"]:checked');
    return r && r.value === 'مجرد';
  }

  function go(i, skipValidate) {
    if (i > current && !skipValidate) {
      for (var k = current; k < i; k++) {
        if (!validateStep(k, k === current)) { i = k; break; }
      }
    }
    current = Math.max(0, Math.min(steps.length - 1, i));
    steps.forEach(function (s, n) { s.hidden = (n !== current); });
    chips.forEach(function (c, n) {
      c.classList.toggle('active', n === current);
      c.classList.toggle('done', n < current);
    });
    if (progress) progress.style.width = ((current + 1) / steps.length * 100) + '%';
    if (counter) counter.textContent = 'مرحله ' + faNum(current + 1) + ' از ' + faNum(steps.length);
    btnPrev.disabled = current === 0;
    btnNext.hidden = current === steps.length - 1;
    btnSend.hidden = current !== steps.length - 1;

    var spouseChip = chips[1];
    if (spouseChip) spouseChip.style.opacity = isSingle() ? '.55' : '';

    if (current === steps.length - 1) { prefillPledge(); if (sigResize) sigResize(); }
    window.scrollTo({ top: 0, behavior: 'smooth' });
    saveDraft();
  }

  btnNext.addEventListener('click', function () {
    var next = current + 1;
    if (current === 0 && isSingle() && next === 1) next = 2;
    go(next);
  });
  btnPrev.addEventListener('click', function () {
    var prev = current - 1;
    if (current === 2 && isSingle() && prev === 1) prev = 0;
    go(prev, true);
  });
  chips.forEach(function (c, n) {
    c.addEventListener('click', function () { go(n, n < current); });
  });

  form.addEventListener('submit', function (ev) {
    var bad = -1;
    for (var i = 0; i < steps.length; i++) {
      if (i === 1 && isSingle()) continue;
      if (!validateStep(i, false)) { bad = i; break; }
    }
    if (bad >= 0) {
      ev.preventDefault();
      go(bad, true);
      validateStep(bad, true);
      return;
    }
    if (sigPad && sigInput) sigInput.value = sigPad.isEmpty() ? '' : sigPad.toDataURL();
    localStorage.removeItem(DRAFT_KEY);
    btnSend.disabled = true;
    btnSend.textContent = 'در حال ثبت…';
  });

  function prefillPledge() {
    var fn = form.querySelector('[name="f[personal][first_name]"]');
    var ln = form.querySelector('[name="f[personal][last_name]"]');
    var t  = form.querySelector('[name="f[pledge][filler_name]"]');
    var d  = form.querySelector('[name="f[pledge][filler_date]"]');
    if (t && !t.value && fn && ln) t.value = ((fn.value || '') + ' ' + (ln.value || '')).trim();
    if (d && !d.value && window.Jalali) {
      var j = Jalali.today();
      d.value = Jalali.fmt(j[0], j[1], j[2]);
    }
    var nm = document.getElementById('pledgeName');
    if (nm && t) nm.textContent = t.value || '..................';
  }

  /* ------------------------------------- فیلدهای شرطی و گزینه «ندارم» */

  /** مقدار فعلی یک گروه ورودی با نام مشخص */
  function valueOf(name) {
    var els = form.querySelectorAll('[name="' + name.replace(/"/g, '\\"') + '"]');
    for (var i = 0; i < els.length; i++) {
      var el = els[i];
      if (el.type === 'radio' || el.type === 'checkbox') { if (el.checked) return el.value; }
      else return el.value;
    }
    return '';
  }

  /** فیلدهایی که فقط با مقدار مشخصی از فیلد دیگر «الزامی» می‌شوند */
  function applyRequiredWhen(scope) {
    (scope || form).querySelectorAll('[data-req-when]').forEach(function (el) {
      var want = (el.dataset.reqWhenValues || '').split('|');
      el.required = want.indexOf(valueOf(el.dataset.reqWhen)) !== -1;
    });
  }

  /** فعال/غیرفعال کردن بخش‌هایی که به مقدار فیلد دیگری وابسته‌اند */
  function applyConditionals(scope) {
    applyRequiredWhen(scope);
    // ترتیب سند رعایت می‌شود: ظرف بیرونی زودتر پردازش می‌شود تا شرط داخلی
    // نتواند فیلدی را که ظرف بیرونی خاموش کرده دوباره روشن کند.
    (scope || form).querySelectorAll('[data-when-field]').forEach(function (box) {
      var want   = (box.dataset.whenValues || '').split('|');
      var parent = box.parentElement ? box.parentElement.closest('.cond-off') : null;
      var on     = !parent && want.indexOf(valueOf(box.dataset.whenField)) !== -1;
      box.classList.toggle('cond-off', !on);
      box.querySelectorAll('input, select, textarea').forEach(function (el) {
        if (el.disabled === !on) return;
        el.disabled = !on;
        if (!on) {
          if (el.type === 'radio' || el.type === 'checkbox') el.checked = false;
          else el.value = '';
          showError(el, null);
        }
      });
    });
  }

  form.addEventListener('change', function () { applyConditionals(); });

  /* پیام خطا به‌محض اصلاح فیلد پاک شود، نه در اعتبارسنجی بعدی */
  function clearErrorIfFixed(el) {
    if (!el || !el.name || el.type === 'hidden') return;

    // گروه رادیویی الزامی (مثل «نوع شناسنامه» یا «وضعیت تأهل»)
    var grp = el.closest ? el.closest('[data-req-group="1"]') : null;
    if (grp) {
      var gbox = grp.closest('.f');
      if (gbox && gbox.classList.contains('has-err') && grp.querySelector('input:checked')) {
        var ge = gbox.querySelector('.field-err');
        if (ge) ge.remove();
        gbox.classList.remove('has-err');
      }
      return;
    }

    var box = el.closest('.f');
    if (box && box.classList.contains('has-err')) showError(el, fieldError(el));
  }

  form.addEventListener('input',  function (e) { clearErrorIfFixed(e.target); });
  form.addEventListener('change', function (e) { clearErrorIfFixed(e.target); });

  /** چک‌باکس «ندارم»: مقدار ثابت می‌گذارد و فیلد را قفل می‌کند */
  function initNoneBoxes(scope) {
    scope.querySelectorAll('[data-none-for]').forEach(function (chk) {
      if (chk.dataset.noneReady) return;
      chk.dataset.noneReady = '1';
      var target = form.querySelector('[name="' + chk.dataset.noneFor.replace(/"/g, '\\"') + '"]');
      if (!target) return;
      var val = chk.dataset.noneValue || 'ندارم';

      function sync() {
        if (chk.checked) {
          target.dataset.prev = (target.value === val) ? '' : target.value;
          target.value = val;
          target.readOnly = true;
          target.classList.add('is-none');
          showError(target, null);
        } else {
          if (target.value === val) target.value = target.dataset.prev || '';
          target.readOnly = false;
          target.classList.remove('is-none');
        }
      }
      chk.addEventListener('change', sync);
      if (target.value === val) { chk.checked = true; }
      sync();
    });
  }

  /* ----------------------------------------------------- ردیف‌های تکراری */

  function initRepeat(box) {
    var list  = box.querySelector('.rows');
    var tpl   = box.querySelector('template');
    var add   = box.querySelector('.add-row');
    var label = box.dataset.rowLabel || 'ردیف';
    var seq   = parseInt(box.dataset.next || '0', 10);

    function renumber() {
      var cards = list.querySelectorAll('.rowcard');
      for (var i = 0; i < cards.length; i++) {
        var tag = cards[i].querySelector('.tag');
        if (tag) tag.textContent = label + ' ' + faNum(i + 1);
      }
      var del = list.querySelectorAll('.del-row');
      for (var j = 0; j < del.length; j++) del[j].disabled = cards.length <= 1;
    }

    function addRow() {
      var html = tpl.innerHTML.replace(/__IDX__/g, String(seq++));
      var d = document.createElement('div');
      d.innerHTML = html.trim();
      var node = d.firstElementChild;
      list.appendChild(node);
      enhance(node);
      renumber();
      box.dataset.next = seq;
      return node;
    }

    add.addEventListener('click', function () {
      var node = addRow();
      node.scrollIntoView({ behavior: 'smooth', block: 'center' });
      var f = node.querySelector('input, select, textarea');
      if (f) f.focus({ preventScroll: true });
    });

    list.addEventListener('click', function (ev) {
      var b = ev.target.closest('.del-row');
      if (!b) return;
      var cards = list.querySelectorAll('.rowcard');
      if (cards.length <= 1) return;
      b.closest('.rowcard').remove();
      renumber();
      saveDraft();
    });

    box._addRow = addRow;
    renumber();
  }

  /* ---------------------------------------------- بهبود فیلدها پس از افزودن */

  function enhance(scope) {
    scope.querySelectorAll('.date-input').forEach(function (el) {
      if (el.dataset.dpReady) return;
      el.dataset.dpReady = '1';
      if (window.attachDatePicker) attachDatePicker(el);
      el.addEventListener('input', function () {
        var v = toEn(el.value).replace(/[^\d\/]/g, '');
        if (/^\d{4}$/.test(v) || /^\d{4}\/\d{2}$/.test(v)) v += '/';
        el.value = v.slice(0, 10);
      });
    });

    initNoneBoxes(scope);

    scope.querySelectorAll('[data-vtype="fa"]').forEach(function (el) {
      if (el.dataset.faReady) return;
      el.dataset.faReady = '1';
      el.addEventListener('input', function () {
        var v = faNormalize(el.value);
        if (v !== el.value) {
          var p = el.selectionStart;
          el.value = v;
          try { el.setSelectionRange(p, p); } catch (e) {}
        }
      });
      el.addEventListener('blur', function () { showError(el, fieldError(el)); });
    });

    scope.querySelectorAll('[data-digits="1"]').forEach(function (el) {
      if (el.dataset.dgReady) return;
      el.dataset.dgReady = '1';
      el.setAttribute('inputmode', 'numeric');
      el.addEventListener('input', function () { el.value = toEn(el.value); });
      el.addEventListener('blur', function () { showError(el, fieldError(el)); });
    });

    scope.querySelectorAll('.opt input').forEach(function (inp) {
      if (inp.dataset.optReady) return;
      inp.dataset.optReady = '1';
      var sync = function () {
        var group = inp.closest('.opts');
        if (inp.type === 'radio') {
          group.querySelectorAll('.opt').forEach(function (o) {
            o.classList.toggle('sel', o.querySelector('input').checked);
          });
        } else {
          inp.closest('.opt').classList.toggle('sel', inp.checked);
        }
      };
      inp.addEventListener('change', sync);
      sync();
    });

    scope.querySelectorAll('input, select, textarea').forEach(function (el) {
      if (el.dataset.blurReady) return;
      el.dataset.blurReady = '1';
      el.addEventListener('blur', function () {
        if (el.closest('.has-err') || el.required) showError(el, fieldError(el));
      });
      el.addEventListener('input', saveDraftDebounced);
      el.addEventListener('change', saveDraftDebounced);
    });

    scope.querySelectorAll('.repeat').forEach(function (b) {
      if (!b.dataset.repReady) { b.dataset.repReady = '1'; initRepeat(b); }
    });
  }

  /* ----------------------------------------------------------- پیش‌نویس */

  var draftTimer = null;
  function saveDraftDebounced() {
    clearTimeout(draftTimer);
    draftTimer = setTimeout(saveDraft, 900);
  }

  function saveDraft() {
    try {
      var fd = new FormData(form);
      var obj = {};
      fd.forEach(function (v, k) {
        if (k === '_csrf' || k === 'website' || typeof v !== 'string') return;
        if (k.slice(-2) === '[]') { (obj[k] = obj[k] || []).push(v); }
        else obj[k] = v;
      });
      localStorage.setItem(DRAFT_KEY, JSON.stringify({ t: Date.now(), step: current, d: obj }));
      var st = document.getElementById('autosave');
      if (st) {
        st.textContent = 'پیش‌نویس ذخیره شد';
        clearTimeout(st._t);
        st._t = setTimeout(function () { st.textContent = ''; }, 2200);
      }
    } catch (e) {}
  }

  function repeatCountNeeded(obj) {
    var need = {};
    Object.keys(obj).forEach(function (k) {
      var m = k.match(/^f\[([a-z_]+)\]\[(\d+)\]/);
      if (m) need[m[1]] = Math.max(need[m[1]] || 0, parseInt(m[2], 10) + 1);
    });
    return need;
  }

  function applyDraft(obj, step) {
    var need = repeatCountNeeded(obj);
    document.querySelectorAll('.repeat').forEach(function (box) {
      var name = box.dataset.block;
      var have = box.querySelectorAll('.rowcard').length;
      var want = need[name] || 0;
      for (var i = have; i < want; i++) box._addRow();
    });
    Object.keys(obj).forEach(function (k) {
      var val = obj[k];
      var els = form.querySelectorAll('[name="' + k.replace(/"/g, '\\"') + '"]');
      if (!els.length) return;
      if (els[0].type === 'radio' || els[0].type === 'checkbox') {
        var vals = Array.isArray(val) ? val : [val];
        els.forEach(function (el) {
          el.checked = vals.indexOf(el.value) >= 0;
          el.dispatchEvent(new Event('change', { bubbles: true }));
        });
      } else {
        els[0].value = val;
      }
    });
    go(typeof step === 'number' ? step : 0, true);
  }

  function initDraftBanner() {
    var raw = localStorage.getItem(DRAFT_KEY);
    if (!raw) return;
    var d;
    try { d = JSON.parse(raw); } catch (e) { return; }
    if (!d || !d.d || Object.keys(d.d).length < 2) return;

    var bar = document.getElementById('draftBar');
    if (!bar) return;
    var when = new Date(d.t);
    bar.hidden = false;
    bar.querySelector('.when').textContent =
      faNum(when.toLocaleDateString('fa-IR')) + ' ساعت ' + faNum(when.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }));
    bar.querySelector('.restore').addEventListener('click', function () {
      applyDraft(d.d, d.step);
      bar.hidden = true;
    });
    bar.querySelector('.discard').addEventListener('click', function () {
      localStorage.removeItem(DRAFT_KEY);
      bar.hidden = true;
    });
  }

  /* -------------------------------------------------------------- امضا */

  var sigPad = null, sigInput = null, sigResize = null;
  function initSignature() {
    var cv = document.getElementById('signPad');
    sigInput = document.getElementById('signValue');
    if (!cv) return;

    var ctx = cv.getContext('2d');
    var drawing = false, empty = true, lastW = 0, lastH = 0;

    function applyCtx() {
      var ratio = window.devicePixelRatio || 1;
      ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
      ctx.lineWidth = 2; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = '#17222e';
    }

    /** اندازه‌ی بوم را با اندازه‌ی نمایشی هماهنگ می‌کند و نقاشی را حفظ می‌کند */
    sigResize = function () {
      var w = cv.clientWidth, h = cv.clientHeight;
      if (!w || !h || (w === lastW && h === lastH)) return;
      var ratio = window.devicePixelRatio || 1;
      var prev = empty ? null : cv.toDataURL('image/png');
      lastW = w; lastH = h;
      cv.width = Math.round(w * ratio);
      cv.height = Math.round(h * ratio);
      applyCtx();
      if (prev) {
        var im = new Image();
        im.onload = function () { ctx.drawImage(im, 0, 0, w, h); };
        im.src = prev;
      }
    };

    window.addEventListener('resize', function () { lastW = 0; sigResize(); });

    function pos(e) {
      var r = cv.getBoundingClientRect();
      var p = e.touches ? e.touches[0] : e;
      return { x: p.clientX - r.left, y: p.clientY - r.top };
    }
    function start(e) { e.preventDefault(); sigResize(); drawing = true; empty = false; var p = pos(e); ctx.beginPath(); ctx.moveTo(p.x, p.y); }
    function move(e) { if (!drawing) return; e.preventDefault(); var p = pos(e); ctx.lineTo(p.x, p.y); ctx.stroke(); }
    function end() { drawing = false; }

    ['mousedown', 'touchstart'].forEach(function (t) { cv.addEventListener(t, start, { passive: false }); });
    ['mousemove', 'touchmove'].forEach(function (t) { cv.addEventListener(t, move, { passive: false }); });
    ['mouseup', 'mouseleave', 'touchend', 'touchcancel'].forEach(function (t) { cv.addEventListener(t, end); });

    var clr = document.getElementById('signClear');
    if (clr) clr.addEventListener('click', function () {
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.clearRect(0, 0, cv.width, cv.height);
      applyCtx();
      empty = true;
      if (sigInput) sigInput.value = '';
    });

    sigPad = { isEmpty: function () { return empty; }, toDataURL: function () { return cv.toDataURL('image/png'); } };
  }

  /* --------------------------------------------------------------- شروع */

  enhance(form);
  initSignature();
  initDraftBanner();

  var marital = form.querySelectorAll('input[name="f[personal][marital]"]');
  marital.forEach(function (r) { r.addEventListener('change', function () { if (chips[1]) chips[1].style.opacity = isSingle() ? '.55' : ''; }); });

  var startAt = 0;
  if (document.querySelector('.has-err')) {
    for (var i = 0; i < steps.length; i++) {
      if (steps[i].querySelector('.has-err')) { startAt = i; break; }
    }
  }
  applyConditionals();
  go(startAt, true);

  window.addEventListener('beforeunload', function (e) {
    if (btnSend.disabled) return;
    var touched = form.querySelector('input[value]:not([value=""])');
    if (!touched) return;
    e.preventDefault();
    e.returnValue = '';
  });
})();

/* --------------------------------------- تأیید حذف در پنل مدیریت */
document.addEventListener('submit', function (e) {
  var f = e.target;
  if (f.dataset && f.dataset.confirm) {
    if (!window.confirm(f.dataset.confirm)) e.preventDefault();
  }
});
