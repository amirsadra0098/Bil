<?php
/**
 * لایه اتصال به پایگاه داده (MySQL/MariaDB، PostgreSQL، SQLite)
 */

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;

    $c = $GLOBALS['CONFIG']['db'];
    $driver = $c['driver'];

    $opts = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    switch ($driver) {
        case 'mysql':
            $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
                $c['host'], $c['port'] ?: 3306, $c['database']);
            $pdo = new PDO($dsn, $c['username'], $c['password'], $opts);
            $pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
            break;

        case 'pgsql':
            $dsn = sprintf('pgsql:host=%s;port=%d;dbname=%s',
                $c['host'], $c['port'] ?: 5432, $c['database']);
            $pdo = new PDO($dsn, $c['username'], $c['password'], $opts);
            $pdo->exec("SET client_encoding TO 'UTF8'");
            break;

        case 'sqlite':
            $path = $c['database'];
            if (!is_dir(dirname($path))) @mkdir(dirname($path), 0775, true);
            $pdo = new PDO('sqlite:' . $path, null, null, $opts);
            $pdo->exec('PRAGMA journal_mode = WAL');
            $pdo->exec('PRAGMA foreign_keys = ON');
            $pdo->exec('PRAGMA busy_timeout = 5000');
            break;

        default:
            throw new RuntimeException('درایور پایگاه داده پشتیبانی نمی‌شود: ' . $driver);
    }

    return $pdo;
}

function db_driver(): string { return $GLOBALS['CONFIG']['db']['driver']; }

/** عبارت LIKE غیرحساس به بزرگی/کوچکی حروف برای هر درایور */
function like_op(): string { return db_driver() === 'pgsql' ? 'ILIKE' : 'LIKE'; }

/** ثبت رویداد در جدول لاگ */
function log_action(string $action, string $entity = '', $entityId = null, string $details = ''): void
{
    try {
        $admin = $_SESSION['admin'] ?? null;
        $st = db()->prepare(
            'INSERT INTO audit_logs (admin_id, actor, action, entity, entity_id, details, ip, user_agent, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $st->execute([
            $admin['id'] ?? null,
            $admin['username'] ?? 'مهمان',
            $action,
            $entity,
            $entityId !== null ? (int)$entityId : null,
            mb_substr($details, 0, 900),
            client_ip(),
            user_agent(),
            date('Y-m-d H:i:s'),
        ]);
    } catch (Throwable $ex) {
        error_log('audit log failed: ' . $ex->getMessage());
    }
}
