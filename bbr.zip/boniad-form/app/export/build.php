<?php
/**
 * ساخت خروجی Word و Excel از یک فرم ثبت‌شده، بر اساس همان اسکیمای فرم.
 */

require_once __DIR__ . '/ooxml.php';
require_once __DIR__ . '/../formdata.php';

const EXPORT_MAX_COLS = 8;   // بیش از این تعداد ستون، به شکل «برچسب/مقدار» چاپ می‌شود

/* ==========================================================================
 *  WORD
 * ========================================================================== */

function submission_docx(array $sub, array $data): string
{
    $body   = [];
    $images = [];

    $org  = app_setting('org_title', cfg('org_title', 'بنیاد مسکن انقلاب اسلامی'));
    $ftit = app_setting('form_title', cfg('form_title', 'فرم اطلاعات فردی'));
    $stit = app_setting('sub_title', cfg('sub_title', 'مدیریت حراست'));

    // نشان سازمان در بالای سند
    $lf = logo_file();
    if ($lf && is_readable($lf)) {
        $bin = @file_get_contents($lf);
        $sz  = @getimagesize($lf);
        if ($bin !== false && $sz && strlen($bin) < 3000000) {
            $images['logo.png'] = $bin;
            $relId = 100 + count($images);      // هم‌ترتیب با docx_build
            $hCm = 2.2;
            $wCm = max(0.5, min(6.0, $hCm * ($sz[0] / max($sz[1], 1))));
            $body[] = docx_image_centered($relId, $wCm, $hCm, 'logo');
        }
    }

    $body[] = docx_p($org, ['align' => 'center', 'bold' => true, 'size' => 26, 'color' => '12507E', 'after' => 20]);
    $body[] = docx_p($stit . ' — ' . $ftit, ['align' => 'center', 'bold' => true, 'size' => 22, 'after' => 160]);

    $body[] = docx_table([
        [['t' => 'کد رهگیری', 'shade' => 'E7EEF5', 'bold' => true], $sub['tracking_code'],
         ['t' => 'تاریخ ثبت', 'shade' => 'E7EEF5', 'bold' => true], jdate($sub['created_at'], true),
         ['t' => 'وضعیت', 'shade' => 'E7EEF5', 'bold' => true], status_label($sub['status'] ?? 'new')],
    ], [13, 20, 13, 22, 12, 20], false);

    foreach (form_steps() as $step) {
        $stepBody = [];
        foreach ($step['blocks'] as $b) {
            $chunk = docx_block($b, $data[$b['name']] ?? null, $images);
            if ($chunk) $stepBody[] = $chunk;
        }
        if (!$stepBody) continue;
        $body[] = docx_p($step['num'] . ') ' . $step['title'], [
            'bold' => true, 'size' => 24, 'color' => 'FFFFFF', 'shade' => '12507E',
            'before' => 200, 'after' => 100,
        ]);
        foreach ($stepBody as $c) $body[] = $c;
    }

    // امضا
    $sig = $data['pledge']['signature'] ?? '';
    if (is_string($sig) && str_starts_with($sig, 'data:image/png;base64,')) {
        $bin = base64_decode(substr($sig, 22), true);
        if ($bin !== false && strlen($bin) > 100) {
            $images['signature.png'] = $bin;
            $sigRel = 100 + count($images);     // هم‌ترتیب با docx_build
            $body[] = docx_p('امضای تکمیل‌کننده:', ['bold' => true, 'before' => 160]);
            $body[] = docx_image($sigRel, 6.5, 2.4);
        }
    }

    $body[] = docx_p('', ['after' => 200]);
    $body[] = docx_p(
        'این سند به صورت خودکار از سامانه ثبت فرم اطلاعات فردی تولید شده است — ' . jdate(date('Y-m-d H:i:s'), true),
        ['align' => 'center', 'size' => 16, 'color' => '7A8794']
    );

    return docx_build($body, $images);
}

function docx_block(array $b, $val, array &$images): string
{
    $title = $b['title'] ?? '';

    if ($b['kind'] === 'fields') {
        $rows = [];
        $pair = [];
        foreach ($b['fields'] as $f) {
            if (($f['type'] ?? '') === 'sign') continue;
            $t = field_text($f, $val[$f['name']] ?? '');
            $pair[] = ['t' => $f['label'], 'shade' => 'F5F7FA', 'bold' => true];
            $pair[] = ['t' => $t !== '' ? $t : '—'];
            if (count($pair) === 4) { $rows[] = $pair; $pair = []; }
        }
        if ($pair) { $pair[] = ['t' => '']; $pair[] = ['t' => '']; $rows[] = $pair; }
        if (!$rows) return '';
        $out = $title ? docx_p($title, ['bold' => true, 'size' => 21, 'before' => 120, 'after' => 60]) : '';
        if (!empty($b['note'])) $out .= docx_p($b['note'], ['size' => 18, 'color' => '4A5A6A']);
        return $out . docx_table($rows, [18, 32, 18, 32], false);
    }

    if ($b['kind'] === 'fixed') {
        $cols = $b['columns'];
        $out  = $title ? docx_p($title, ['bold' => true, 'size' => 21, 'before' => 120, 'after' => 60]) : '';
        $any  = false;

        if (count($cols) + 1 <= EXPORT_MAX_COLS) {
            $head = [['t' => '']];
            foreach ($cols as $c) $head[] = ['t' => $c['label']];
            $rows = [$head];
            foreach ($b['rows'] as $r) {
                $line = [['t' => $r['label'], 'shade' => 'F5F7FA', 'bold' => true]];
                foreach ($cols as $c) {
                    $t = field_text($c, $val[$r['key']][$c['name']] ?? '');
                    if ($t !== '') $any = true;
                    $line[] = ['t' => $t !== '' ? $t : '—'];
                }
                $rows[] = $line;
            }
            return $any ? $out . docx_table($rows) : '';
        }

        // ستون‌های زیاد → هر ردیف به شکل برچسب/مقدار
        $chunks = '';
        foreach ($b['rows'] as $r) {
            $pair = []; $rows = []; $has = false;
            foreach ($cols as $c) {
                $t = field_text($c, $val[$r['key']][$c['name']] ?? '');
                if ($t !== '') $has = true;
                $pair[] = ['t' => $c['label'], 'shade' => 'F5F7FA', 'bold' => true];
                $pair[] = ['t' => $t !== '' ? $t : '—'];
                if (count($pair) === 4) { $rows[] = $pair; $pair = []; }
            }
            if ($pair) { $pair[] = ['t' => '']; $pair[] = ['t' => '']; $rows[] = $pair; }
            if (!$has) continue;
            $any = true;
            $chunks .= docx_p($r['label'], ['bold' => true, 'size' => 19, 'shade' => 'E7EEF5', 'before' => 80, 'after' => 40]);
            $chunks .= docx_table($rows, [18, 32, 18, 32], false);
        }
        return $any ? $out . $chunks : '';
    }

    if ($b['kind'] === 'repeat') {
        $rows = clean_rows($b, $val);
        if (!$rows) return '';
        $cols = $b['columns'];
        $out  = $title ? docx_p($title, ['bold' => true, 'size' => 21, 'before' => 120, 'after' => 60]) : '';

        if (count($cols) + 1 <= EXPORT_MAX_COLS) {
            $head = [['t' => 'ردیف']];
            foreach ($cols as $c) $head[] = ['t' => $c['label']];
            $table = [$head];
            $i = 0;
            foreach ($rows as $r) {
                $i++;
                $line = [['t' => fa_num($i), 'align' => 'center']];
                foreach ($cols as $c) {
                    $t = field_text($c, $r[$c['name']] ?? '');
                    $line[] = ['t' => $t !== '' ? $t : '—'];
                }
                $table[] = $line;
            }
            $w = array_fill(0, count($cols) + 1, 0);
            $w[0] = 6;
            $rest = (100 - 6) / max(count($cols), 1);
            for ($k = 1; $k <= count($cols); $k++) $w[$k] = $rest;
            return $out . docx_table($table, $w);
        }

        $chunks = ''; $i = 0;
        foreach ($rows as $r) {
            $i++;
            $pair = []; $t2 = [];
            foreach ($cols as $c) {
                $t = field_text($c, $r[$c['name']] ?? '');
                $pair[] = ['t' => $c['label'], 'shade' => 'F5F7FA', 'bold' => true];
                $pair[] = ['t' => $t !== '' ? $t : '—'];
                if (count($pair) === 4) { $t2[] = $pair; $pair = []; }
            }
            if ($pair) { $pair[] = ['t' => '']; $pair[] = ['t' => '']; $t2[] = $pair; }
            $chunks .= docx_p(($b['row_label'] ?? 'ردیف') . ' ' . fa_num($i), ['bold' => true, 'size' => 19, 'shade' => 'E7EEF5', 'before' => 80, 'after' => 40]);
            $chunks .= docx_table($t2, [18, 32, 18, 32], false);
        }
        return $out . $chunks;
    }

    return '';
}

/* ==========================================================================
 *  EXCEL — یک فرم
 * ========================================================================== */

function submission_xlsx(array $sub, array $data): string
{
    $W = EXPORT_MAX_COLS;                      // A..H
    $rows = [];
    $merges = [];
    $r = 0;

    $push = function (array $cells) use (&$rows, &$r) { $rows[] = $cells; $r++; return $r; };
    $blank = array_fill(0, $W, ['v' => '', 's' => 0]);

    $org  = app_setting('org_title', cfg('org_title', ''));
    $stit = app_setting('sub_title', cfg('sub_title', ''));
    $ftit = app_setting('form_title', cfg('form_title', ''));

    $line = array_fill(0, $W, ['v' => '', 's' => 1]);
    $line[0] = ['v' => $org . ' — ' . $stit . ' — ' . $ftit, 's' => 1];
    $n = $push($line);
    $rows[$n - 1]['__h'] = 30;
    $merges[] = 'A' . $n . ':' . xlsx_col_letter($W - 1) . $n;

    $meta = [
        'کد رهگیری'      => $sub['tracking_code'],
        'نام و نام خانوادگی' => sub_full_name($sub),
        'کد ملی'          => fa_num($sub['national_id'] ?? ''),
        'تاریخ ثبت'       => jdate($sub['created_at'], true),
        'وضعیت'           => status_label($sub['status'] ?? 'new'),
    ];
    foreach ($meta as $k => $v) {
        $line = array_fill(0, $W, ['v' => '', 's' => 4]);
        $line[0] = ['v' => $k, 's' => 3];
        $line[1] = ['v' => $v, 's' => 4];
        $n = $push($line);
        $merges[] = 'B' . $n . ':' . xlsx_col_letter($W - 1) . $n;
    }
    $push($blank);

    foreach (form_steps() as $step) {
        $body = [];
        foreach ($step['blocks'] as $b) {
            $chunk = xlsx_block($b, $data[$b['name']] ?? null, $W);
            if ($chunk) $body = array_merge($body, $chunk);
        }
        if (!$body) continue;

        $line = array_fill(0, $W, ['v' => '', 's' => 2]);
        $line[0] = ['v' => $step['num'] . ') ' . $step['title'], 's' => 2];
        $n = $push($line);
        $rows[$n - 1]['__h'] = 24;
        $merges[] = 'A' . $n . ':' . xlsx_col_letter($W - 1) . $n;

        foreach ($body as $item) {
            $n = $push($item['cells']);
            if (!empty($item['merge'])) {
                $merges[] = xlsx_col_letter($item['merge'][0]) . $n . ':' . xlsx_col_letter($item['merge'][1]) . $n;
            }
            if (!empty($item['h'])) $rows[$n - 1]['__h'] = $item['h'];
        }
        $push($blank);
    }

    $widths = array_fill(0, $W, 17);
    $widths[0] = 26;
    $widths[1] = 24;

    return xlsx_build([[
        'name'   => 'فرم اطلاعات فردی',
        'widths' => $widths,
        'rows'   => $rows,
        'merges' => $merges,
    ]]);
}

function xlsx_block(array $b, $val, int $W): array
{
    $out = [];
    $sub = function (string $t) use ($W) {
        $line = array_fill(0, $W, ['v' => '', 's' => 0]);
        $line[0] = ['v' => $t, 's' => 3];
        return ['cells' => $line, 'merge' => [0, $W - 1]];
    };

    if ($b['kind'] === 'fields') {
        $any = [];
        foreach ($b['fields'] as $f) {
            if (($f['type'] ?? '') === 'sign') continue;
            $t = field_text($f, $val[$f['name']] ?? '');
            $line = array_fill(0, $W, ['v' => '', 's' => 4]);
            $line[0] = ['v' => $f['label'], 's' => 3];
            $line[1] = ['v' => $t, 's' => 4];
            $any[] = ['cells' => $line, 'merge' => [1, $W - 1]];
        }
        if (!$any) return [];
        if (!empty($b['title'])) $out[] = $sub($b['title']);
        return array_merge($out, $any);
    }

    if ($b['kind'] === 'fixed') {
        $cols = $b['columns'];
        $body = [];
        $any  = false;

        if (count($cols) + 1 <= $W) {
            $head = array_fill(0, $W, ['v' => '', 's' => 5]);
            $head[0] = ['v' => '', 's' => 5];
            foreach ($cols as $i => $c) $head[$i + 1] = ['v' => $c['label'], 's' => 5];
            $body[] = ['cells' => $head, 'h' => 30];
            foreach ($b['rows'] as $rw) {
                $line = array_fill(0, $W, ['v' => '', 's' => 4]);
                $line[0] = ['v' => $rw['label'], 's' => 3];
                foreach ($cols as $i => $c) {
                    $t = field_text($c, $val[$rw['key']][$c['name']] ?? '');
                    if ($t !== '') $any = true;
                    $line[$i + 1] = ['v' => $t, 's' => 4];
                }
                $body[] = ['cells' => $line];
            }
            if (!$any) return [];
            if (!empty($b['title'])) $out[] = $sub($b['title']);
            return array_merge($out, $body);
        }

        foreach ($b['rows'] as $rw) {
            $chunk = []; $has = false;
            foreach ($cols as $c) {
                $t = field_text($c, $val[$rw['key']][$c['name']] ?? '');
                if ($t !== '') $has = true;
                $line = array_fill(0, $W, ['v' => '', 's' => 4]);
                $line[0] = ['v' => $c['label'], 's' => 3];
                $line[1] = ['v' => $t, 's' => 4];
                $chunk[] = ['cells' => $line, 'merge' => [1, $W - 1]];
            }
            if (!$has) continue;
            $any = true;
            $body[] = $sub('— ' . $rw['label']);
            $body = array_merge($body, $chunk);
        }
        if (!$any) return [];
        if (!empty($b['title'])) $out[] = $sub($b['title']);
        return array_merge($out, $body);
    }

    if ($b['kind'] === 'repeat') {
        $rows = clean_rows($b, $val);
        if (!$rows) return [];
        $cols = $b['columns'];
        if (!empty($b['title'])) $out[] = $sub($b['title']);

        if (count($cols) + 1 <= $W) {
            $head = array_fill(0, $W, ['v' => '', 's' => 5]);
            $head[0] = ['v' => 'ردیف', 's' => 5];
            foreach ($cols as $i => $c) $head[$i + 1] = ['v' => $c['label'], 's' => 5];
            $out[] = ['cells' => $head, 'h' => 30];
            $k = 0;
            foreach ($rows as $rw) {
                $k++;
                $line = array_fill(0, $W, ['v' => '', 's' => 4]);
                $line[0] = ['v' => fa_num($k), 's' => 6];
                foreach ($cols as $i => $c) $line[$i + 1] = ['v' => field_text($c, $rw[$c['name']] ?? ''), 's' => 4];
                $out[] = ['cells' => $line];
            }
            return $out;
        }

        $k = 0;
        foreach ($rows as $rw) {
            $k++;
            $out[] = $sub('— ' . ($b['row_label'] ?? 'ردیف') . ' ' . fa_num($k));
            foreach ($cols as $c) {
                $line = array_fill(0, $W, ['v' => '', 's' => 4]);
                $line[0] = ['v' => $c['label'], 's' => 3];
                $line[1] = ['v' => field_text($c, $rw[$c['name']] ?? ''), 's' => 4];
                $out[] = ['cells' => $line, 'merge' => [1, $W - 1]];
            }
        }
        return $out;
    }

    return [];
}

/* ==========================================================================
 *  EXCEL — فهرست فرم‌ها
 * ========================================================================== */

function submissions_list_xlsx(array $list): string
{
    $head = ['ردیف', 'کد رهگیری', 'نام', 'نام خانوادگی', 'نام پدر', 'کد ملی', 'تاریخ تولد',
             'تلفن همراه', 'سازمان / محل خدمت', 'پست سازمانی', 'وضعیت', 'تاریخ ثبت', 'IP'];

    $rows = [];
    $line = array_fill(0, count($head), ['v' => '', 's' => 1]);
    $line[0] = ['v' => 'فهرست فرم‌های ثبت‌شده — ' . jdate(date('Y-m-d H:i:s'), true), 's' => 1];
    $rows[] = $line;
    $rows[0]['__h'] = 28;

    $rows[] = array_map(fn($h) => ['v' => $h, 's' => 5], $head);

    $i = 0;
    foreach ($list as $s) {
        $i++;
        $rows[] = [
            ['v' => fa_num($i), 's' => 6],
            ['v' => $s['tracking_code'], 's' => 6],
            ['v' => $s['first_name'], 's' => 4],
            ['v' => $s['last_name'], 's' => 4],
            ['v' => $s['father_name'], 's' => 4],
            ['v' => fa_num($s['national_id']), 's' => 6],
            ['v' => fa_num($s['birth_date']), 's' => 6],
            ['v' => fa_num($s['mobile']), 's' => 6],
            ['v' => $s['org_name'], 's' => 4],
            ['v' => $s['position'], 's' => 4],
            ['v' => status_label($s['status']), 's' => 6],
            ['v' => jdate($s['created_at'], true), 's' => 6],
            ['v' => $s['ip'], 's' => 6],
        ];
    }

    return xlsx_build([[
        'name'   => 'فهرست فرم‌ها',
        'widths' => [6, 14, 14, 16, 14, 14, 13, 15, 26, 20, 15, 18, 14],
        'rows'   => $rows,
        'merges' => ['A1:M1'],
    ]]);
}

