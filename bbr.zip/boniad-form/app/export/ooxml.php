<?php
/**
 * تولید فایل‌های واقعی Office Open XML (xlsx / docx) بدون هیچ کتابخانه‌ی جانبی.
 * فقط به افزونه‌ی zip در PHP نیاز دارد.
 */

function xe($s): string
{
    $s = (string)$s;
    $s = str_replace(["\r\n", "\r"], "\n", $s);
    // حذف نویسه‌های کنترلی غیرمجاز در XML
    $s = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/u', '', $s);
    return htmlspecialchars($s, ENT_QUOTES | ENT_XML1 | ENT_SUBSTITUTE, 'UTF-8');
}

/** ساخت آرشیو zip از آرایه‌ی «مسیر => محتوا» و بازگرداندن محتوای باینری */
function ooxml_zip(array $files): string
{
    if (!class_exists('ZipArchive')) {
        throw new RuntimeException('افزونه‌ی zip در PHP فعال نیست (php-zip را نصب کنید).');
    }
    $tmp = tempnam(sys_get_temp_dir(), 'ooxml');
    $zip = new ZipArchive();
    if ($zip->open($tmp, ZipArchive::OVERWRITE | ZipArchive::CREATE) !== true) {
        throw new RuntimeException('امکان ساخت فایل موقت وجود ندارد.');
    }
    foreach ($files as $name => $content) $zip->addFromString($name, $content);
    $zip->close();
    $bin = file_get_contents($tmp);
    @unlink($tmp);
    return $bin;
}

/* ==========================================================================
 *  XLSX
 * ========================================================================== */

function xlsx_col_letter(int $i): string
{
    $s = '';
    $i++;
    while ($i > 0) { $m = ($i - 1) % 26; $s = chr(65 + $m) . $s; $i = (int)(($i - $m) / 26); }
    return $s;
}

/**
 * @param array $sheets  هر شیت: ['name'=>..,'widths'=>[..],'rows'=>[[cell,..],..],'merges'=>['A1:F1']]
 *                        هر سلول یا رشته است یا ['v'=>..,'s'=>styleIndex]
 */
function xlsx_build(array $sheets): string
{
    $sheetXml = [];
    $i = 0;
    foreach ($sheets as $sh) {
        $i++;
        $cols = '';
        if (!empty($sh['widths'])) {
            $cols .= '<cols>';
            foreach ($sh['widths'] as $n => $w) {
                $cols .= '<col min="' . ($n + 1) . '" max="' . ($n + 1) . '" width="' . (float)$w . '" customWidth="1"/>';
            }
            $cols .= '</cols>';
        }

        $rowsXml = '';
        $r = 0;
        foreach ($sh['rows'] as $row) {
            $r++;
            $meta = '';
            if (is_array($row) && isset($row['__h'])) { $meta = ' ht="' . (float)$row['__h'] . '" customHeight="1"'; unset($row['__h']); }
            $cellsXml = '';
            $c = 0;
            foreach ($row as $cell) {
                $style = 4;
                $val   = $cell;
                if (is_array($cell)) { $val = $cell['v'] ?? ''; $style = $cell['s'] ?? 4; }
                $ref = xlsx_col_letter($c) . $r;
                if ($val === '' || $val === null) {
                    $cellsXml .= '<c r="' . $ref . '" s="' . $style . '"/>';
                } else {
                    $cellsXml .= '<c r="' . $ref . '" s="' . $style . '" t="inlineStr"><is><t xml:space="preserve">'
                               . xe($val) . '</t></is></c>';
                }
                $c++;
            }
            $rowsXml .= '<row r="' . $r . '"' . $meta . '>' . $cellsXml . '</row>';
        }

        $merges = '';
        if (!empty($sh['merges'])) {
            $merges = '<mergeCells count="' . count($sh['merges']) . '">';
            foreach ($sh['merges'] as $m) $merges .= '<mergeCell ref="' . $m . '"/>';
            $merges .= '</mergeCells>';
        }

        $sheetXml[$i] =
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<sheetViews><sheetView rightToLeft="1" workbookViewId="0" tabSelected="' . ($i === 1 ? 1 : 0) . '"/></sheetViews>'
            . '<sheetFormatPr defaultRowHeight="18"/>'
            . $cols
            . '<sheetData>' . $rowsXml . '</sheetData>'
            . $merges
            . '<pageMargins left="0.3" right="0.3" top="0.5" bottom="0.5" header="0.2" footer="0.2"/>'
            . '<pageSetup orientation="landscape" paperSize="9" fitToWidth="1"/>'
            . '</worksheet>';
    }

    $sheetsTag = '';
    $rels      = '';
    $ctOver    = '';
    $n = 0;
    foreach ($sheets as $sh) {
        $n++;
        $sheetsTag .= '<sheet name="' . xe(mb_substr($sh['name'], 0, 30)) . '" sheetId="' . $n . '" r:id="rId' . $n . '"/>';
        $rels .= '<Relationship Id="rId' . $n . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' . $n . '.xml"/>';
        $ctOver .= '<Override PartName="/xl/worksheets/sheet' . $n . '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
    }
    $styleRelId = $n + 1;

    $files = [];

    $files['[Content_Types].xml'] =
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        . '<Default Extension="xml" ContentType="application/xml"/>'
        . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        . $ctOver
        . '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
        . '</Types>';

    $files['_rels/.rels'] =
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        . '<Relationship Id="rIdWb" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
        . '</Relationships>';

    $files['xl/workbook.xml'] =
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        . 'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        . '<sheets>' . $sheetsTag . '</sheets></workbook>';

    $files['xl/_rels/workbook.xml.rels'] =
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        . $rels
        . '<Relationship Id="rId' . $styleRelId . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
        . '</Relationships>';

    $files['xl/styles.xml'] = xlsx_styles();

    foreach ($sheetXml as $k => $xml) $files['xl/worksheets/sheet' . $k . '.xml'] = $xml;

    return ooxml_zip($files);
}

function xlsx_styles(): string
{
    $border = '<border><left style="thin"><color rgb="FFBFC9D4"/></left><right style="thin"><color rgb="FFBFC9D4"/></right>'
            . '<top style="thin"><color rgb="FFBFC9D4"/></top><bottom style="thin"><color rgb="FFBFC9D4"/></bottom><diagonal/></border>';

    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        . '<fonts count="5">'
        . '<font><sz val="10"/><name val="Tahoma"/></font>'                                              /* 0 */
        . '<font><b/><sz val="15"/><color rgb="FFFFFFFF"/><name val="Tahoma"/></font>'                    /* 1 */
        . '<font><b/><sz val="11"/><color rgb="FF0F3557"/><name val="Tahoma"/></font>'                    /* 2 */
        . '<font><b/><sz val="10"/><color rgb="FF25405A"/><name val="Tahoma"/></font>'                    /* 3 */
        . '<font><sz val="10"/><color rgb="FF1B2733"/><name val="Tahoma"/></font>'                        /* 4 */
        . '</fonts>'
        . '<fills count="5">'
        . '<fill><patternFill patternType="none"/></fill>'
        . '<fill><patternFill patternType="gray125"/></fill>'
        . '<fill><patternFill patternType="solid"><fgColor rgb="FF12507E"/><bgColor indexed="64"/></patternFill></fill>' /* 2 */
        . '<fill><patternFill patternType="solid"><fgColor rgb="FFE7EEF5"/><bgColor indexed="64"/></patternFill></fill>' /* 3 */
        . '<fill><patternFill patternType="solid"><fgColor rgb="FFF5F7FA"/><bgColor indexed="64"/></patternFill></fill>' /* 4 */
        . '</fills>'
        . '<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border>' . $border . '</borders>'
        . '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
        . '<cellXfs count="7">'
        /* 0 عادی بدون کادر */
        . '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="right" vertical="center" readingOrder="2"/></xf>'
        /* 1 عنوان اصلی */
        . '<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" readingOrder="2"/></xf>'
        /* 2 سرفصل بخش */
        . '<xf numFmtId="0" fontId="2" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center" readingOrder="2"/></xf>'
        /* 3 برچسب */
        . '<xf numFmtId="49" fontId="3" fillId="4" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center" wrapText="1" readingOrder="2"/></xf>'
        /* 4 مقدار */
        . '<xf numFmtId="49" fontId="4" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center" wrapText="1" readingOrder="2"/></xf>'
        /* 5 سر ستون جدول */
        . '<xf numFmtId="0" fontId="3" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1" readingOrder="2"/></xf>'
        /* 6 مقدار وسط‌چین */
        . '<xf numFmtId="49" fontId="4" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1" readingOrder="2"/></xf>'
        . '</cellXfs>'
        . '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
        . '</styleSheet>';
}

/* ==========================================================================
 *  DOCX
 * ========================================================================== */

const DOCX_EMU_PER_CM = 360000;

function docx_runs(string $text, bool $bold = false, int $size = 20, ?string $color = null): string
{
    $rpr = '<w:rPr><w:rFonts w:ascii="Tahoma" w:hAnsi="Tahoma" w:cs="Tahoma"/>'
         . ($bold ? '<w:b/><w:bCs/>' : '')
         . ($color ? '<w:color w:val="' . $color . '"/>' : '')
         . '<w:sz w:val="' . $size . '"/><w:szCs w:val="' . $size . '"/><w:rtl/></w:rPr>';
    $parts = explode("\n", str_replace(["\r\n", "\r"], "\n", $text));
    $out = '';
    foreach ($parts as $k => $p) {
        if ($k > 0) $out .= '<w:r>' . $rpr . '<w:br/></w:r>';
        if ($p !== '') $out .= '<w:r>' . $rpr . '<w:t xml:space="preserve">' . xe($p) . '</w:t></w:r>';
    }
    if ($out === '') $out = '<w:r>' . $rpr . '<w:t xml:space="preserve"></w:t></w:r>';
    return $out;
}

function docx_p(string $text, array $o = []): string
{
    $align  = $o['align'] ?? 'right';
    $bold   = !empty($o['bold']);
    $size   = $o['size'] ?? 20;
    $color  = $o['color'] ?? null;
    $shade  = $o['shade'] ?? null;
    $spaceB = $o['after'] ?? 60;
    $ppr = '<w:pPr><w:bidi/><w:jc w:val="' . $align . '"/>'
         . ($shade ? '<w:shd w:val="clear" w:color="auto" w:fill="' . $shade . '"/>' : '')
         . '<w:spacing w:before="' . ($o['before'] ?? 0) . '" w:after="' . $spaceB . '" w:line="264" w:lineRule="auto"/></w:pPr>';
    return '<w:p>' . $ppr . docx_runs($text, $bold, $size, $color) . '</w:p>';
}

function docx_cell(string $text, array $o = []): string
{
    $w      = $o['w'] ?? 2000;
    $shade  = $o['shade'] ?? null;
    $align  = $o['align'] ?? 'right';
    $bold   = !empty($o['bold']);
    $size   = $o['size'] ?? 18;
    $span   = $o['span'] ?? 1;
    return '<w:tc><w:tcPr><w:tcW w:w="' . $w . '" w:type="dxa"/>'
        . ($span > 1 ? '<w:gridSpan w:val="' . $span . '"/>' : '')
        . ($shade ? '<w:shd w:val="clear" w:color="auto" w:fill="' . $shade . '"/>' : '')
        . '<w:vAlign w:val="center"/></w:tcPr>'
        . '<w:p><w:pPr><w:bidi/><w:jc w:val="' . $align . '"/><w:spacing w:before="20" w:after="20"/></w:pPr>'
        . docx_runs($text, $bold, $size) . '</w:p></w:tc>';
}

/**
 * جدول docx
 * @param array $rows هر ردیف آرایه‌ای از سلول‌ها: رشته یا ['t'=>متن,'shade'=>..,'bold'=>..,'span'=>..]
 * @param array $widths عرض ستون‌ها بر حسب درصد
 */
function docx_table(array $rows, array $widths = [], bool $headerFirst = true): string
{
    $total = 9600;
    $n = 0;
    foreach ($rows as $r) { $n = max($n, count($r)); }
    if (!$widths) $widths = array_fill(0, $n, 100 / max($n, 1));

    $grid = '<w:tblGrid>';
    foreach ($widths as $p) $grid .= '<w:gridCol w:w="' . (int)round($total * $p / 100) . '"/>';
    $grid .= '</w:tblGrid>';

    $b = '<w:tblBorders>'
       . '<w:top w:val="single" w:sz="4" w:color="BFC9D4"/><w:left w:val="single" w:sz="4" w:color="BFC9D4"/>'
       . '<w:bottom w:val="single" w:sz="4" w:color="BFC9D4"/><w:right w:val="single" w:sz="4" w:color="BFC9D4"/>'
       . '<w:insideH w:val="single" w:sz="4" w:color="BFC9D4"/><w:insideV w:val="single" w:sz="4" w:color="BFC9D4"/>'
       . '</w:tblBorders>';

    $xml = '<w:tbl><w:tblPr><w:bidiVisual/><w:tblW w:w="5000" w:type="pct"/>' . $b
         . '<w:tblLayout w:type="fixed"/><w:tblCellMar>'
         . '<w:top w:w="40" w:type="dxa"/><w:left w:w="70" w:type="dxa"/><w:bottom w:w="40" w:type="dxa"/><w:right w:w="70" w:type="dxa"/>'
         . '</w:tblCellMar></w:tblPr>' . $grid;

    foreach ($rows as $ri => $row) {
        $isHeader = $headerFirst && $ri === 0;
        $xml .= '<w:tr>' . ($isHeader ? '<w:trPr><w:tblHeader/></w:trPr>' : '');
        $ci = 0;
        foreach ($row as $cell) {
            $o = ['w' => (int)round($total * ($widths[$ci] ?? (100 / max($n, 1))) / 100)];
            if (is_array($cell)) {
                $t = $cell['t'] ?? '';
                $o = array_merge($o, $cell);
                unset($o['t']);
            } else { $t = (string)$cell; }
            if ($isHeader) { $o['shade'] = $o['shade'] ?? 'E7EEF5'; $o['bold'] = true; $o['align'] = $o['align'] ?? 'center'; }
            $xml .= docx_cell($t, $o);
            $ci += (int)($o['span'] ?? 1);
        }
        $xml .= '</w:tr>';
    }
    return $xml . '</w:tbl>' . docx_p('', ['after' => 60]);
}

/**
 * @param array $body  آرایه‌ای از رشته‌های XML آماده (خروجی docx_p / docx_table / docx_image)
 * @param array $images  ['image1.png' => binary, ...]
 */
function docx_build(array $body, array $images = [], string $footerText = ''): string
{
    $imgRels = '';
    $imgCT   = '';
    $files   = [];
    $idx     = 100;
    foreach ($images as $name => $bin) {
        $idx++;
        $files['word/media/' . $name] = $bin;
        $imgRels .= '<Relationship Id="rId' . $idx . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/' . $name . '"/>';
    }
    if ($images) {
        $imgCT = '<Default Extension="png" ContentType="image/png"/>';
    }

    $sectPr = '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/>'
            . '<w:pgMar w:top="900" w:right="900" w:bottom="900" w:left="900" w:header="400" w:footer="400" w:gutter="0"/>'
            . '<w:bidi/><w:rtlGutter/></w:sectPr>';

    $files['word/document.xml'] =
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
        . 'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
        . 'xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" '
        . 'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
        . 'xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">'
        . '<w:body>' . implode('', $body) . $sectPr . '</w:body></w:document>';

    $files['[Content_Types].xml'] =
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        . '<Default Extension="xml" ContentType="application/xml"/>'
        . $imgCT
        . '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
        . '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>'
        . '</Types>';

    $files['_rels/.rels'] =
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        . '<Relationship Id="rIdDoc" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
        . '</Relationships>';

    $files['word/_rels/document.xml.rels'] =
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        . '<Relationship Id="rIdStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
        . $imgRels
        . '</Relationships>';

    $files['word/styles.xml'] =
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        . '<w:docDefaults><w:rPrDefault><w:rPr>'
        . '<w:rFonts w:ascii="Tahoma" w:hAnsi="Tahoma" w:cs="Tahoma"/><w:sz w:val="20"/><w:szCs w:val="20"/>'
        . '</w:rPr></w:rPrDefault>'
        . '<w:pPrDefault><w:pPr><w:bidi/><w:jc w:val="right"/></w:pPr></w:pPrDefault></w:docDefaults>'
        . '<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/>'
        . '<w:pPr><w:bidi/><w:jc w:val="right"/></w:pPr></w:style>'
        . '</w:styles>';

    return ooxml_zip($files);
}

/** تصویر درون‌خطی (امضا) */
function docx_image(int $relIndex, float $wCm, float $hCm, string $name = 'signature'): string
{
    $cx = (int)round($wCm * DOCX_EMU_PER_CM);
    $cy = (int)round($hCm * DOCX_EMU_PER_CM);
    return '<w:p><w:pPr><w:bidi/><w:jc w:val="left"/></w:pPr><w:r><w:drawing>'
        . '<wp:inline distT="0" distB="0" distL="0" distR="0">'
        . '<wp:extent cx="' . $cx . '" cy="' . $cy . '"/><wp:docPr id="' . $relIndex . '" name="' . $name . '"/>'
        . '<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">'
        . '<pic:pic><pic:nvPicPr><pic:cNvPr id="' . $relIndex . '" name="' . $name . '.png"/><pic:cNvPicPr/></pic:nvPicPr>'
        . '<pic:blipFill><a:blip r:embed="rId' . $relIndex . '"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>'
        . '<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="' . $cx . '" cy="' . $cy . '"/></a:xfrm>'
        . '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic>'
        . '</a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>';
}

/** تصویر درون‌خطی وسط‌چین */
function docx_image_centered(int $relIndex, float $wCm, float $hCm, string $name = 'image'): string
{
    return str_replace('<w:jc w:val="left"/>', '<w:jc w:val="center"/>',
        docx_image($relIndex, $wCm, $hCm, $name));
}

/** ارسال فایل به مرورگر */
function send_download(string $bin, string $filename, string $mime): void
{
    while (ob_get_level() > 0) ob_end_clean();
    $ext   = pathinfo($filename, PATHINFO_EXTENSION);
    $ascii = preg_replace('/[^A-Za-z0-9._-]+/', '-', $filename);
    $ascii = trim(preg_replace('/-{2,}/', '-', $ascii), '-.');
    if (strlen(preg_replace('/[^A-Za-z0-9]/', '', pathinfo($ascii, PATHINFO_FILENAME))) < 3) {
        $ascii = 'form-' . date('Ymd-His') . ($ext ? '.' . $ext : '');
    }
    header('Content-Type: ' . $mime);
    header('Content-Length: ' . strlen($bin));
    header("Content-Disposition: attachment; filename=\"$ascii\"; filename*=UTF-8''" . rawurlencode($filename));
    header('Cache-Control: private, max-age=0, must-revalidate');
    header('Pragma: public');
    echo $bin;
    exit;
}
