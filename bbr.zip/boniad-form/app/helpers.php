<?php
/**
 * توابع کمکی عمومی
 */

function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

/* ---------------------------------------------------------------- اعداد */

const FA_DIGITS = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
const AR_DIGITS = ['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];

function fa_num($v): string {
    return str_replace(['0','1','2','3','4','5','6','7','8','9'], FA_DIGITS, (string)$v);
}
function en_num($v): string {
    $v = str_replace(FA_DIGITS, ['0','1','2','3','4','5','6','7','8','9'], (string)$v);
    $v = str_replace(AR_DIGITS, ['0','1','2','3','4','5','6','7','8','9'], $v);
    return str_replace(['٫','٬'], ['.',','], $v);
}

/* --------------------------------------------------------- تاریخ شمسی */

function g2j(int $gy, int $gm, int $gd): array {
    $g_d_m = [0,31,59,90,120,151,181,212,243,273,304,334];
    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
    $days = 355666 + (365 * $gy) + ((int)(($gy2 + 3) / 4)) - ((int)(($gy2 + 99) / 100))
          + ((int)(($gy2 + 399) / 400)) + $gd + $g_d_m[$gm - 1];
    $jy = -1595 + (33 * ((int)($days / 12053)));
    $days %= 12053;
    $jy += 4 * ((int)($days / 1461));
    $days %= 1461;
    if ($days > 365) { $jy += (int)(($days - 1) / 365); $days = ($days - 1) % 365; }
    if ($days < 186) { $jm = 1 + (int)($days / 31); $jd = 1 + ($days % 31); }
    else { $jm = 7 + (int)(($days - 186) / 30); $jd = 1 + (($days - 186) % 30); }
    return [$jy, $jm, $jd];
}

function j2g(int $jy, int $jm, int $jd): array {
    $jy += 1595;
    $days = -355668 + (365 * $jy) + (((int)($jy / 33)) * 8) + ((int)((($jy % 33) + 3) / 4))
          + $jd + (($jm < 7) ? ($jm - 1) * 31 : (($jm - 7) * 30) + 186);
    $gy = 400 * ((int)($days / 146097));
    $days %= 146097;
    if ($days > 36524) {
        $gy += 100 * ((int)(--$days / 36524));
        $days %= 36524;
        if ($days >= 365) $days++;
    }
    $gy += 4 * ((int)($days / 1461));
    $days %= 1461;
    if ($days > 365) { $gy += (int)(($days - 1) / 365); $days = ($days - 1) % 365; }
    $gd = $days + 1;
    $leap = (($gy % 4 == 0 && $gy % 100 != 0) || ($gy % 400 == 0));
    $sal_a = [0,31,$leap ? 29 : 28,31,30,31,30,31,31,30,31,30,31];
    for ($gm = 0; $gm < 13 && $gd > $sal_a[$gm]; $gm++) $gd -= $sal_a[$gm];
    return [$gy, $gm, $gd];
}

/** «1403/05/12» از یک رشته تاریخ/زمان میلادی */
function jdate(?string $datetime, bool $withTime = false, bool $faDigits = true): string {
    if (!$datetime) return '';
    $ts = strtotime($datetime);
    if ($ts === false) return '';
    [$jy, $jm, $jd] = g2j((int)date('Y', $ts), (int)date('n', $ts), (int)date('j', $ts));
    $out = sprintf('%04d/%02d/%02d', $jy, $jm, $jd);
    if ($withTime) $out .= ' - ' . date('H:i', $ts);
    return $faDigits ? fa_num($out) : $out;
}

function jtoday(bool $faDigits = false): string {
    [$jy, $jm, $jd] = g2j((int)date('Y'), (int)date('n'), (int)date('j'));
    $s = sprintf('%04d/%02d/%02d', $jy, $jm, $jd);
    return $faDigits ? fa_num($s) : $s;
}

const JMONTHS = ['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];

function jdate_long(?string $datetime): string {
    if (!$datetime) return '';
    $ts = strtotime($datetime);
    if ($ts === false) return '';
    [$jy, $jm, $jd] = g2j((int)date('Y', $ts), (int)date('n', $ts), (int)date('j', $ts));
    return fa_num($jd) . ' ' . JMONTHS[$jm - 1] . ' ' . fa_num($jy);
}

/** تبدیل «1403/05/12» شمسی به «2024-08-02» میلادی جهت فیلتر تاریخ */
function jalali_str_to_gregorian(string $s): ?string {
    $s = en_num(trim($s));
    if (!preg_match('/^(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})$/', $s, $m)) return null;
    [$gy, $gm, $gd] = j2g((int)$m[1], (int)$m[2], (int)$m[3]);
    return sprintf('%04d-%02d-%02d', $gy, $gm, $gd);
}

/* --------------------------------------------------------- متن فارسی */

/** یکسان‌سازی نویسه‌های عربی با معادل فارسی (ي→ی ، ك→ک و ...) */
function fa_normalize(string $v): string
{
    return strtr($v, [
        "\u{064A}" => "\u{06CC}",   // ي → ی
        "\u{0649}" => "\u{06CC}",   // ى → ی
        "\u{0643}" => "\u{06A9}",   // ك → ک
        "\u{06AA}" => "\u{06A9}",   // ڪ → ک
        "\u{0624}" => "\u{0648}",   // ؤ → و
        "\u{0625}" => "\u{0627}",   // إ → ا
        "\u{0623}" => "\u{0627}",   // أ → ا
        "\u{0640}" => '',           // کشیده (ـ) حذف می‌شود
        "\u{00A0}" => ' ',          // فاصله‌ی سخت
    ]);
}

/** آیا متن فقط از حروف فارسی، فاصله و نیم‌فاصله تشکیل شده است؟ */
function is_persian_text(string $v): bool
{
    $v = trim($v);
    if ($v === '') return true;
    return (bool)preg_match('/^[\x{0620}-\x{064A}\x{066E}-\x{06D3}\x{200C}\x{200F}\s]+$/u', $v);
}

/* ---------------------------------------------------------- اعتبارسنجی */

function valid_national_id(string $code): bool {
    $code = preg_replace('/\D/', '', en_num($code));
    if (strlen($code) !== 10) return false;
    if (preg_match('/^(\d)\1{9}$/', $code)) return false;
    $sum = 0;
    for ($i = 0; $i < 9; $i++) $sum += ((int)$code[$i]) * (10 - $i);
    $r = $sum % 11;
    $check = (int)$code[9];
    return ($r < 2) ? ($check === $r) : ($check === 11 - $r);
}

function valid_mobile(string $m): bool {
    $m = preg_replace('/\D/', '', en_num($m));
    return (bool)preg_match('/^09\d{9}$/', $m);
}

/* ------------------------------------------------------------ عمومی */

function client_ip(): string {
    foreach (['HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR'] as $k) {
        if (!empty($_SERVER[$k])) {
            $ip = trim(explode(',', $_SERVER[$k])[0]);
            if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
        }
    }
    return '0.0.0.0';
}

function user_agent(): string { return mb_substr($_SERVER['HTTP_USER_AGENT'] ?? '-', 0, 250); }

function redirect(string $url): void { header('Location: ' . $url); exit; }

function base_url(string $path = ''): string {
    $base = rtrim(BASE_PATH_URL, '/');
    return $base . '/' . ltrim($path, '/');
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function csrf_field(): string {
    return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}
function csrf_verify(): void {
    $t = $_POST['_csrf'] ?? '';
    if (!is_string($t) || empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $t)) {
        http_response_code(419);
        exit('نشست شما منقضی شده است. لطفاً صفحه را دوباره باز کنید.');
    }
}

function flash(?string $msg = null, string $type = 'ok') {
    if ($msg === null) {
        $f = $_SESSION['_flash'] ?? null;
        unset($_SESSION['_flash']);
        return $f;
    }
    $_SESSION['_flash'] = ['type' => $type, 'msg' => $msg];
    return null;
}

function tracking_code(): string {
    [$jy] = g2j((int)date('Y'), (int)date('n'), (int)date('j'));
    return 'BM-' . substr((string)$jy, -2) . '-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 6));
}

function str_limit(?string $s, int $n = 60): string {
    $s = trim((string)$s);
    return mb_strlen($s) > $n ? mb_substr($s, 0, $n) . '…' : $s;
}

function app_setting(string $key, $default = null) {
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        try {
            foreach (db()->query('SELECT k, v FROM settings') as $r) $cache[$r['k']] = $r['v'];
        } catch (Throwable $ex) { $cache = []; }
    }
    return $cache[$key] ?? $default;
}

function set_setting(string $key, string $val): void {
    $db = db();
    $st = $db->prepare('SELECT COUNT(*) FROM settings WHERE k = ?');
    $st->execute([$key]);
    if ((int)$st->fetchColumn() > 0) {
        $db->prepare('UPDATE settings SET v = ? WHERE k = ?')->execute([$val, $key]);
    } else {
        $db->prepare('INSERT INTO settings (k, v) VALUES (?, ?)')->execute([$key, $val]);
    }
}
