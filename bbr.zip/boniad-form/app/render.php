<?php
/**
 * تولید HTML فیلدها و بلوک‌های فرم بر اساس اسکیما.
 */

function input_attrs(array $f): string
{
    $a = [];
    $t = $f['type'] ?? 'text';
    if (!empty($f['required'])) $a[] = 'required';
    $a[] = 'data-vtype="' . e($t) . '"';
    if (in_array($t, ['nid', 'postal', 'tel', 'number'], true)) $a[] = 'data-digits="1"';
    if ($t === 'nid')    $a[] = 'maxlength="10" placeholder="۱۰ رقم"';
    if ($t === 'postal') $a[] = 'maxlength="10" placeholder="۱۰ رقم"';
    if ($f['name'] === 'mobile') $a[] = 'data-mobile="1" maxlength="11" placeholder="۰۹۱۲۳۴۵۶۷۸۹"';
    if ($t === 'fa') $a[] = 'lang="fa" spellcheck="false" placeholder="به فارسی بنویسید"';
    if (!empty($f['required_when'])) {
        $rw = $f['required_when'];
        $a[] = 'data-req-when="f[' . e($rw['block']) . '][' . e($rw['field']) . ']"';
        $a[] = 'data-req-when-values="' . e(implode('|', $rw['values'])) . '"';
    }
    return implode(' ', $a);
}

/**
 * @param string $prefix مثل f[personal]
 */
function render_field(array $f, string $prefix, $value, ?string $err = null): string
{
    $type = $f['type'] ?? 'text';
    $name = $prefix . '[' . $f['name'] . ']';
    $id   = 'i_' . preg_replace('/[^a-z0-9_]+/i', '_', $name);
    $w    = 'w' . ($f['w'] ?? 3);
    $cls  = 'f ' . $w . ($err ? ' has-err' : '');

    // فیلدی که فقط با مقدار مشخصی از فیلد دیگر فعال می‌شود
    $cond = '';
    if (!empty($f['when'])) {
        $ctrl = $prefix . '[' . $f['when']['field'] . ']';
        $cond = ' data-when-field="' . e($ctrl) . '"'
              . ' data-when-values="' . e(implode('|', $f['when']['values'])) . '"';
        $cls .= ' cond';
    }

    $star = (!empty($f['required']) || !empty($f['required_when'])) ? '<span class="req">*</span>' : '';
    $lbl  = '<label class="lbl" for="' . e($id) . '">' . e($f['label']) . $star . '</label>';

    $out = '<div class="' . $cls . '"' . $cond . '>';

    if ($type === 'sign') {
        $out .= $lbl
             . '<canvas id="signPad" class="sign-pad"></canvas>'
             . '<input type="hidden" id="signValue" name="' . e($name) . '" value="' . e(is_string($value) ? $value : '') . '">'
             . '<div class="btn-row" style="margin-top:8px">'
             . '<button type="button" class="btn ghost sm" id="signClear">پاک کردن امضا</button></div>';
        if (!empty($f['hint'])) $out .= '<span class="hint">' . e($f['hint']) . '</span>';
        return $out . '</div>';
    }

    $out .= $lbl;

    // چک‌باکس «ندارم» کنار فیلدهای اختیاری
    $noneBox = '';
    if (!empty($f['none'])) {
        $chk = ((string)$value === (string)$f['none']) ? ' checked' : '';
        $noneBox = '<label class="none-chk"><input type="checkbox" data-none-for="' . e($name) . '"'
                 . ' data-none-value="' . e($f['none']) . '"' . $chk . '><span>' . e($f['none']) . '</span></label>';
    }

    switch ($type) {
        case 'textarea':
            $out .= '<textarea id="' . e($id) . '" name="' . e($name) . '" ' . input_attrs($f) . ' rows="3">'
                  . e(is_scalar($value) ? $value : '') . '</textarea>';
            break;

        case 'select':
            $out .= '<select id="' . e($id) . '" name="' . e($name) . '" ' . input_attrs($f) . '>'
                  . '<option value="">— انتخاب کنید —</option>';
            foreach ($f['options'] as $o) {
                $out .= '<option value="' . e($o) . '"' . ((string)$value === (string)$o ? ' selected' : '') . '>' . e($o) . '</option>';
            }
            $out .= '</select>';
            break;

        case 'radio':
            $req = !empty($f['required']) ? ' data-req-group="1"' : '';
            $out .= '<div class="opts"' . $req . '>';
            foreach ($f['options'] as $k => $o) {
                $chk = ((string)$value === (string)$o) ? ' checked' : '';
                $out .= '<label class="opt' . ($chk ? ' sel' : '') . '">'
                      . '<input type="radio" name="' . e($name) . '" value="' . e($o) . '"' . $chk . '>'
                      . '<span>' . e($o) . '</span></label>';
            }
            $out .= '</div>';
            break;

        case 'checks':
            $vals = is_array($value) ? $value : [];
            $out .= '<div class="opts">';
            foreach ($f['options'] as $o) {
                $chk = in_array($o, $vals, true) ? ' checked' : '';
                $out .= '<label class="opt' . ($chk ? ' sel' : '') . '">'
                      . '<input type="checkbox" name="' . e($name) . '[]" value="' . e($o) . '"' . $chk . '>'
                      . '<span>' . e($o) . '</span></label>';
            }
            $out .= '</div>';
            break;

        case 'date':
            $out .= '<div class="date-wrap">'
                  . '<input type="text" class="date-input" id="' . e($id) . '" name="' . e($name) . '" '
                  . 'value="' . e(is_scalar($value) ? $value : '') . '" placeholder="۱۴۰۳/۰۵/۱۲" '
                  . 'autocomplete="off" maxlength="10" ' . input_attrs($f) . '>'
                  . '<button type="button" class="cal-btn" tabindex="-1" aria-label="انتخاب تاریخ">🗓</button>'
                  . '</div>';
            break;

        default:
            $html = ['tel' => 'tel', 'email' => 'email', 'number' => 'number'][$type] ?? 'text';
            $out .= '<input type="' . $html . '" id="' . e($id) . '" name="' . e($name) . '" '
                  . 'value="' . e(is_scalar($value) ? $value : '') . '" ' . input_attrs($f) . '>';
    }

    if ($noneBox !== '') $out .= $noneBox;
    if (!empty($f['hint'])) $out .= '<span class="hint">' . e($f['hint']) . '</span>';
    if ($err) $out .= '<span class="field-err">' . e($err) . '</span>';

    return $out . '</div>';
}

/** یک بلوک کامل فرم */
function render_block(array $b, array $old, array $errors): string
{
    $name = $b['name'];
    $src  = is_array($old[$name] ?? null) ? $old[$name] : [];
    $head = '';

    if (!empty($b['title'])) {
        $head = '<header><h3>' . e($b['title']) . '</h3>';
        if (!empty($b['hint'])) $head .= '<span class="muted">' . e($b['hint']) . '</span>';
        $head .= '<div class="spacer"></div>';
    }

    /* --------------------------------------------------- fields */
    if ($b['kind'] === 'fields') {
        $body = '';
        if (!empty($b['note'])) $body .= '<div class="alert info">' . e($b['note']) . '</div>';
        $body .= '<div class="grid">';
        foreach ($b['fields'] as $f) {
            $err = $errors[$name . '.' . $f['name']] ?? null;
            $body .= render_field($f, 'f[' . $name . ']', $src[$f['name']] ?? '', $err);
        }
        $body .= '</div>';
        return '<div class="block">' . ($head ? $head . '</header>' : '') . '<div class="block-body">' . $body . '</div></div>';
    }

    /* ---------------------------------------------------- fixed */
    if ($b['kind'] === 'fixed') {
        $body = '';
        foreach ($b['rows'] as $r) {
            $rv     = is_array($src[$r['key']] ?? null) ? $src[$r['key']] : [];
            $prefix = 'f[' . $name . '][' . $r['key'] . ']';

            $body .= '<div class="rowcard"><div class="rc-head"><span class="tag">' . e($r['label']) . '</span>'
                   . '<div class="spacer"></div>';

            // ردیف‌هایی که با «دارد / ندارد» فعال می‌شوند
            $gateAttr = '';
            if (!empty($r['gate'])) {
                $gCol = null;
                foreach ($b['columns'] as $c) if ($c['name'] === $r['gate']) { $gCol = $c; break; }
                if ($gCol) {
                    $gName = $prefix . '[' . $gCol['name'] . ']';
                    $gVal  = (string)($rv[$gCol['name']] ?? $gCol['options'][0]);
                    $body .= '<div class="gate opts">';
                    foreach ($gCol['options'] as $o) {
                        $sel = ($gVal === $o) ? ' checked' : '';
                        $body .= '<label class="opt' . ($sel ? ' sel' : '') . '">'
                               . '<input type="radio" name="' . e($gName) . '" value="' . e($o) . '"' . $sel . '>'
                               . '<span>' . e($o) . '</span></label>';
                    }
                    $body .= '</div>';
                    $gateAttr = ' data-when-field="' . e($gName) . '" data-when-values="'
                              . e(end($gCol['options'])) . '"';
                }
            }

            $body .= '</div><div class="grid' . ($gateAttr ? ' cond' : '') . '"' . $gateAttr . '>';
            foreach ($b['columns'] as $c) {
                if (!empty($c['gate'])) continue;          // در سربرگ رسم شده است
                $err = $errors[$name . '.' . $r['key'] . '.' . $c['name']] ?? null;
                $body .= render_field($c, $prefix, $rv[$c['name']] ?? '', $err);
            }
            $body .= '</div></div>';
        }
        return '<div class="block">' . ($head ? $head . '</header>' : '') . '<div class="block-body">' . $body . '</div></div>';
    }

    /* --------------------------------------------------- repeat */
    $min   = max(1, (int)($b['min'] ?? 1));
    $rows  = is_array($src) ? array_values($src) : [];
    $count = max($min, count($rows));
    $label = $b['row_label'] ?? 'ردیف';

    $mk = function (int $i, $vals) use ($b, $name, $label, $errors) {
        $idx = $i === -1 ? '__IDX__' : (string)$i;
        $h = '<div class="rowcard"><div class="rc-head"><span class="tag">' . e($label) . '</span>'
           . '<div class="spacer"></div>'
           . '<button type="button" class="btn danger xs del-row">حذف</button></div><div class="grid">';
        foreach ($b['columns'] as $c) {
            $err = $i === -1 ? null : ($errors[$name . '.' . $i . '.' . $c['name']] ?? null);
            $h .= render_field($c, 'f[' . $name . '][' . $idx . ']',
                               is_array($vals) ? ($vals[$c['name']] ?? '') : '', $err);
        }
        return $h . '</div></div>';
    };

    $body = '<div class="rows">';
    for ($i = 0; $i < $count; $i++) $body .= $mk($i, $rows[$i] ?? null);
    $body .= '</div>';
    $body .= '<template>' . $mk(-1, null) . '</template>';
    $body .= '<div class="btn-row"><button type="button" class="btn ghost sm add-row">+ افزودن ' . e($label) . '</button>'
           . '<span class="muted">در صورت نداشتن مورد، خالی بگذارید.</span></div>';

    return '<div class="block repeat" data-block="' . e($name) . '" data-row-label="' . e($label) . '" data-next="' . $count . '">'
         . ($head ? $head . '</header>' : '')
         . '<div class="block-body">' . $body . '</div></div>';
}

/* ==========================================================================
 *  نمایش فقط‌خواندنی (پنل مدیریت و چاپ)
 * ========================================================================== */

function ro_val($t): string { return $t === '' ? '<span class="muted">—</span>' : e($t); }

function render_ro_block(array $b, $val): string
{
    if (!block_has_data($b, $val)) return '';
    $out = '';
    if (!empty($b['title'])) $out .= '<div class="sub-title">' . e($b['title']) . '</div>';

    if ($b['kind'] === 'fields') {
        $out .= '<div class="kv">';
        foreach ($b['fields'] as $f) {
            if (($f['type'] ?? '') === 'sign') continue;
            $out .= '<div><b>' . e($f['label']) . '</b><span>' . ro_val(field_text($f, $val[$f['name']] ?? '')) . '</span></div>';
        }
        return $out . '</div>';
    }

    if ($b['kind'] === 'fixed') {
        foreach ($b['rows'] as $r) {
            $has = false;
            foreach ($b['columns'] as $c) if (!is_blank($val[$r['key']][$c['name']] ?? '')) { $has = true; break; }
            if (!$has) continue;
            $out .= '<div class="muted" style="margin:10px 0 5px;font-weight:700;color:var(--navy-800)">' . e($r['label']) . '</div><div class="kv">';
            foreach ($b['columns'] as $c) {
                $out .= '<div><b>' . e($c['label']) . '</b><span>' . ro_val(field_text($c, $val[$r['key']][$c['name']] ?? '')) . '</span></div>';
            }
            $out .= '</div>';
        }
        return $out;
    }

    $rows = clean_rows($b, $val);
    $out .= '<div class="table-wrap"><table class="tbl"><thead><tr><th class="c" style="width:48px">#</th>';
    foreach ($b['columns'] as $c) $out .= '<th>' . e($c['label']) . '</th>';
    $out .= '</tr></thead><tbody>';
    $i = 0;
    foreach ($rows as $r) {
        $i++;
        $out .= '<tr><td class="c">' . fa_num($i) . '</td>';
        foreach ($b['columns'] as $c) $out .= '<td>' . ro_val(field_text($c, $r[$c['name']] ?? '')) . '</td>';
        $out .= '</tr>';
    }
    return $out . '</tbody></table></div>';
}

/** نمایش کامل یک فرم ثبت‌شده */
function render_ro_form(array $data): string
{
    $out = '';
    foreach (form_steps() as $step) {
        $chunk = '';
        foreach ($step['blocks'] as $b) $chunk .= render_ro_block($b, $data[$b['name']] ?? null);
        if (trim($chunk) === '') continue;
        $out .= '<div class="sec-title">' . e($step['num'] . ') ' . $step['title']) . '</div>' . $chunk;
    }
    $sig = $data['pledge']['signature'] ?? '';
    if (is_string($sig) && str_starts_with($sig, 'data:image/png;base64,')) {
        $out .= '<div class="sub-title">امضای تکمیل‌کننده</div>'
              . '<img src="' . e($sig) . '" alt="امضا" style="max-width:340px;border:1px solid var(--line);border-radius:8px;background:#fff">';
    }
    return $out ?: '<div class="empty">اطلاعاتی ثبت نشده است.</div>';
}
