<?php
/**
 * ساخت جداول پایگاه داده و ایجاد کاربر مدیر اولیه.
 *
 * اجرا:  php app/migrate.php --admin-user=admin --admin-pass=Secret123 --dev-pass=OwnerPass
 */

if (PHP_SAPI !== 'cli') { http_response_code(403); exit('این اسکریپت فقط از خط فرمان اجرا می‌شود.'); }

require __DIR__ . '/bootstrap.php';

$args = [];
foreach ($argv as $a) {
    if (preg_match('/^--([^=]+)=(.*)$/s', $a, $m)) $args[$m[1]] = $m[2];
    elseif (preg_match('/^--(.+)$/', $a, $m)) $args[$m[1]] = true;
}

$driver = db_driver();
$pdo    = db();

/* ------------------------------------------------ نگاشت انواع بر اساس درایور */
$T = [
    'mysql' => [
        'pk'   => 'INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY',
        'int'  => 'INT',
        'txt'  => 'TEXT',
        'ltxt' => 'LONGTEXT',
        'dt'   => 'DATETIME',
        'bool' => 'TINYINT(1)',
        'tail' => ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
    ],
    'pgsql' => [
        'pk'   => 'SERIAL PRIMARY KEY',
        'int'  => 'INTEGER',
        'txt'  => 'TEXT',
        'ltxt' => 'TEXT',
        'dt'   => 'TIMESTAMP',
        'bool' => 'SMALLINT',
        'tail' => '',
    ],
    'sqlite' => [
        'pk'   => 'INTEGER PRIMARY KEY AUTOINCREMENT',
        'int'  => 'INTEGER',
        'txt'  => 'TEXT',
        'ltxt' => 'TEXT',
        'dt'   => 'TEXT',
        'bool' => 'INTEGER',
        'tail' => '',
    ],
][$driver];

function vc(int $n): string { return db_driver() === 'sqlite' ? 'TEXT' : "VARCHAR($n)"; }

$tables = [];

$tables['submissions'] = "
    id {$T['pk']},
    tracking_code " . vc(24) . " NOT NULL,
    first_name " . vc(120) . " NULL,
    last_name " . vc(120) . " NULL,
    father_name " . vc(120) . " NULL,
    national_id " . vc(20) . " NULL,
    mobile " . vc(24) . " NULL,
    birth_date " . vc(16) . " NULL,
    org_name " . vc(190) . " NULL,
    position " . vc(190) . " NULL,
    status " . vc(20) . " NOT NULL,
    reviewer_name " . vc(190) . " NULL,
    reviewed_at {$T['dt']} NULL,
    admin_note {$T['txt']} NULL,
    data {$T['ltxt']} NOT NULL,
    ip " . vc(45) . " NULL,
    user_agent " . vc(255) . " NULL,
    created_at {$T['dt']} NOT NULL,
    updated_at {$T['dt']} NULL
";

$tables['admins'] = "
    id {$T['pk']},
    username " . vc(80) . " NOT NULL,
    password_hash " . vc(255) . " NOT NULL,
    display_name " . vc(150) . " NULL,
    role " . vc(20) . " NOT NULL,
    is_active {$T['bool']} NOT NULL,
    last_login_at {$T['dt']} NULL,
    created_at {$T['dt']} NOT NULL
";

$tables['audit_logs'] = "
    id {$T['pk']},
    admin_id {$T['int']} NULL,
    actor " . vc(100) . " NULL,
    action " . vc(60) . " NOT NULL,
    entity " . vc(40) . " NULL,
    entity_id {$T['int']} NULL,
    details {$T['txt']} NULL,
    ip " . vc(45) . " NULL,
    user_agent " . vc(255) . " NULL,
    created_at {$T['dt']} NOT NULL
";

$tables['login_attempts'] = "
    id {$T['pk']},
    username " . vc(80) . " NULL,
    ip " . vc(45) . " NULL,
    success {$T['bool']} NOT NULL,
    created_at {$T['dt']} NOT NULL
";

$tables['settings'] = "
    k " . vc(80) . " NOT NULL PRIMARY KEY,
    v {$T['txt']} NULL
";

foreach ($tables as $name => $cols) {
    $pdo->exec("CREATE TABLE IF NOT EXISTS $name ($cols){$T['tail']}");
    echo "✔ جدول $name آماده است\n";
}

/* --------------------------------------------------------------- ایندکس‌ها */
$indexes = [
    'idx_sub_created'  => 'submissions (created_at)',
    'idx_sub_nid'      => 'submissions (national_id)',
    'idx_sub_last'     => 'submissions (last_name)',
    'idx_sub_track'    => 'submissions (tracking_code)',
    'idx_sub_status'   => 'submissions (status)',
    'idx_log_created'  => 'audit_logs (created_at)',
    'idx_att_created'  => 'login_attempts (created_at)',
];
foreach ($indexes as $iname => $def) {
    try { $pdo->exec("CREATE INDEX IF NOT EXISTS $iname ON $def"); }
    catch (Throwable $ex) {
        // MySQL < 8.0.29 از IF NOT EXISTS برای ایندکس پشتیبانی نمی‌کند
        try { $pdo->exec("CREATE INDEX $iname ON $def"); } catch (Throwable $e2) { /* از قبل وجود دارد */ }
    }
}
// یکتایی نام کاربری مدیران
try { $pdo->exec('CREATE UNIQUE INDEX uq_admin_username ON admins (username)'); } catch (Throwable $ex) {}
try { $pdo->exec('CREATE UNIQUE INDEX uq_sub_tracking ON submissions (tracking_code)'); } catch (Throwable $ex) {}
echo "✔ ایندکس‌ها آماده است\n";

/* --------------------------------------------------------- تنظیمات پیش‌فرض */
foreach ([
    'org_title'   => cfg('org_title', 'بنیاد مسکن انقلاب اسلامی'),
    'form_title'  => cfg('form_title', 'فرم اطلاعات فردی'),
    'sub_title'   => cfg('sub_title', 'مدیریت حراست'),
    'form_open'   => '1',
    'credit_enabled' => '0',        // امضای سازنده پیش‌فرض خاموش
    'intro_text'  => 'لطفاً کلیه بخش‌ها را با دقت و بر اساس مدارک رسمی تکمیل نمایید. اطلاعات این فرم محرمانه تلقی می‌شود.',
] as $k => $v) {
    $st = $pdo->prepare('SELECT COUNT(*) FROM settings WHERE k = ?');
    $st->execute([$k]);
    if ((int)$st->fetchColumn() === 0) {
        $pdo->prepare('INSERT INTO settings (k, v) VALUES (?, ?)')->execute([$k, (string)$v]);
    }
}
echo "✔ تنظیمات پیش‌فرض ثبت شد\n";

/* ------------------------------------------------------------- کاربر مدیر */
$user = (string)($args['admin-user'] ?? 'admin');
$pass = (string)($args['admin-pass'] ?? '');

$st = $pdo->prepare('SELECT COUNT(*) FROM admins');
$st->execute();
$hasAdmin = (int)$st->fetchColumn() > 0;

if (!$hasAdmin) {
    if ($pass === '') {
        $pass = bin2hex(random_bytes(5)) . 'Aa1';
    }
    $pdo->prepare(
        'INSERT INTO admins (username, password_hash, display_name, role, is_active, created_at)
         VALUES (?, ?, ?, ?, ?, ?)'
    )->execute([$user, password_hash($pass, PASSWORD_DEFAULT), 'مدیر سامانه', 'super', 1, date('Y-m-d H:i:s')]);

    echo "\n=====================================================\n";
    echo "  کاربر مدیر ساخته شد\n";
    echo "  نام کاربری : $user\n";
    echo "  رمز عبور   : $pass\n";
    echo "=====================================================\n\n";
} else {
    if (!empty($args['reset-admin-pass']) && $pass !== '') {
        $pdo->prepare('UPDATE admins SET password_hash = ? WHERE username = ?')
            ->execute([password_hash($pass, PASSWORD_DEFAULT), $user]);
        echo "✔ رمز عبور کاربر «$user» بازنشانی شد\n";
    } else {
        echo "ℹ کاربر مدیر از قبل وجود دارد؛ تغییری اعمال نشد.\n";
    }
}

/* ------------------------------------------------- رمز پنل سازنده */
$devPass = (string)($args['dev-pass'] ?? '');
if ($devPass !== '') {
    $hash = password_hash($devPass, PASSWORD_DEFAULT);
    $st = $pdo->prepare('SELECT COUNT(*) FROM settings WHERE k = ?');
    $st->execute(['dev_pass']);
    if ((int)$st->fetchColumn() > 0) {
        $pdo->prepare('UPDATE settings SET v = ? WHERE k = ?')->execute([$hash, 'dev_pass']);
    } else {
        $pdo->prepare('INSERT INTO settings (k, v) VALUES (?, ?)')->execute(['dev_pass', $hash]);
    }
    echo "✔ رمز پنل سازنده ثبت شد
";
}

echo "✔ پایگاه داده ({$driver}) با موفقیت آماده‌سازی شد.\n";
