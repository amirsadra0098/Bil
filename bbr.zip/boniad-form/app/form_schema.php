<?php
/**
 * تعریف کامل فرم (صفحات ۲ تا ۶ فرم چاپی).
 *
 * این ساختار، منبع واحد حقیقت است و هم برای نمایش فرم، هم اعتبارسنجی،
 * هم نمایش در پنل مدیریت و هم خروجی Word/Excel استفاده می‌شود.
 *
 * انواع بلوک:
 *   fields  → مجموعه‌ای از فیلدهای ساده
 *   fixed   → جدول با ردیف‌های ثابت (مثل «خود / همسر»)
 *   repeat  → جدول با ردیف‌های قابل افزودن توسط کاربر
 *
 * انواع فیلد: text, fa (فقط حروف فارسی), textarea, tel, email, number, date,
 *              select, radio, checks, nid, postal, sign
 */

function fld(string $name, string $label, array $o = []): array
{
    return array_merge(['name' => $name, 'label' => $label, 'type' => 'text', 'w' => 3], $o);
}

function form_steps(): array
{
    static $steps = null;
    if ($steps !== null) return $steps;

    $YESNO = ['دارم', 'ندارم'];

    $steps = [

        /* =================================================== گام ۱ — صفحه ۲ بالا */
        [
            'id'    => 'personal',
            'num'   => '۱',
            'title' => 'اطلاعات فردی',
            'desc'  => 'مشخصات شناسنامه‌ای، ظاهری، شغلی و راه‌های ارتباطی خود را وارد کنید.',
            'blocks' => [
                [
                    'kind' => 'fields', 'name' => 'personal', 'title' => 'مشخصات شناسنامه‌ای',
                    'fields' => [
                        fld('first_name', 'نام', ['type' => 'fa', 'required' => true]),
                        fld('last_name', 'نام خانوادگی', ['type' => 'fa', 'required' => true]),
                        fld('father_name', 'نام پدر', ['type' => 'fa', 'required' => true]),
                        fld('birth_cert_no', 'شماره شناسنامه'),
                        fld('national_id', 'شماره ملی', ['type' => 'nid', 'required' => true]),
                        fld('birth_date', 'تاریخ تولد', ['type' => 'date', 'required' => true]),
                        fld('birth_place', 'محل تولد', ['type' => 'fa', 'required' => true]),
                        fld('issue_place', 'محل صدور', ['type' => 'fa', 'required' => true]),
                        fld('prev_last_name', 'نام خانوادگی قبلی', ['type' => 'fa', 'none' => 'ندارم']),
                        fld('nickname', 'شهرت یا القاب', ['type' => 'fa', 'none' => 'ندارم']),
                        fld('id_type', 'نوع شناسنامه', ['type' => 'radio', 'options' => ['اصلی', 'المثنی'], 'required' => true]),
                        fld('duplicate_issue_date', 'تاریخ صدور المثنی', ['type' => 'date',
                            'when' => ['field' => 'id_type', 'values' => ['المثنی']]]),
                        fld('duplicate_reason', 'علت صدور المثنی', [
                            'when' => ['field' => 'id_type', 'values' => ['المثنی']]]),
                        fld('religion', 'دین و مذهب', ['type' => 'fa', 'required' => true]),
                        fld('marital', 'وضعیت تأهل', ['type' => 'radio', 'options' => ['مجرد', 'متأهل'], 'required' => true]),
                        fld('dual_nationality', 'تابعیت مضاعف', ['type' => 'radio', 'options' => $YESNO, 'required' => true]),
                        fld('dual_country', 'نام کشور (تابعیت مضاعف)', [
                            'when' => ['field' => 'dual_nationality', 'values' => ['دارم']]]),
                    ],
                ],
                [
                    'kind' => 'fields', 'name' => 'appearance', 'title' => 'مشخصات ظاهری',
                    'fields' => [
                        fld('height', 'قد (سانتی‌متر)', ['type' => 'number', 'w' => 2]),
                        fld('weight', 'وزن (کیلوگرم)', ['type' => 'number', 'w' => 2]),
                        fld('blood_type', 'گروه خونی', ['type' => 'select', 'w' => 2, 'options' => [
                            'A مثبت', 'A منفی', 'B مثبت', 'B منفی',
                            'AB مثبت', 'AB منفی', 'O مثبت', 'O منفی',
                        ]]),
                        fld('face_color', 'رنگ چهره', ['w' => 2]),
                        fld('hair_color', 'رنگ مو', ['w' => 2]),
                        fld('eye_color', 'رنگ چشم', ['w' => 2]),
                        fld('special_mark', 'علامت ویژه', ['w' => 6]),
                    ],
                ],
                [
                    'kind' => 'fields', 'name' => 'edu_passport', 'title' => 'تحصیلات، گذرنامه و خدمت سربازی',
                    'fields' => [
                        fld('last_degree', 'آخرین مدرک تحصیلی', ['type' => 'select', 'options' => ['زیر دیپلم', 'دیپلم', 'فوق دیپلم', 'لیسانس', 'فوق لیسانس', 'دکتری', 'حوزوی']]),
                        fld('field_of_study', 'رشته تحصیلی'),
                        fld('passport_type_no', 'نوع و شماره گذرنامه'),
                        fld('passport_issue_date', 'تاریخ صدور گذرنامه', ['type' => 'date']),
                        fld('military_status', 'وضعیت خدمت سربازی', ['type' => 'radio', 'options' => ['خدمت کرده', 'معاف', 'مشمول', 'در حال خدمت', 'مشمول نیست']]),
                        fld('military_place', 'محل خدمت'),
                        fld('exemption_type', 'نوع معافیت'),
                    ],
                ],
                [
                    'kind' => 'fields', 'name' => 'workplace', 'title' => 'دستگاه یا سازمان محل خدمت',
                    'fields' => [
                        fld('org_name', 'نام وزارت / سازمان / شرکت', ['w' => 6]),
                        fld('general_dept', 'اداره کل'),
                        fld('deputy', 'معاونت'),
                        fld('dept', 'اداره'),
                        fld('position', 'مسئولیت و پست سازمانی'),
                        fld('employment_status', 'وضعیت استخدامی', ['type' => 'select', 'options' => ['رسمی', 'پیمانی', 'قراردادی', 'شرکتی', 'ساعتی', 'طرحی', 'مأمور']]),
                        fld('job_group', 'گروه شغلی'),
                        fld('transferred_from', 'مأمور یا انتقالی از'),
                    ],
                ],
                [
                    'kind' => 'fields', 'name' => 'contact', 'title' => 'راه‌های ارتباطی',
                    'fields' => [
                        fld('mobile', 'تلفن همراه', ['type' => 'tel', 'required' => true, 'hint' => 'مثال: ۰۹۱۲۱۲۳۴۵۶۷']),
                        fld('mobile2', 'تلفن همراه دوم', ['type' => 'tel']),
                        fld('work_phone', 'تلفن ثابت محل کار', ['type' => 'tel']),
                        fld('home_phone', 'تلفن ثابت منزل', ['type' => 'tel']),
                        fld('email', 'پست الکترونیکی', ['type' => 'email', 'w' => 4]),
                    ],
                ],
            ],
        ],

        /* =================================================== گام ۲ — صفحه ۲ پایین */
        [
            'id'    => 'spouse',
            'num'   => '۲',
            'title' => 'مشخصات همسر یا همسران',
            'desc'  => 'در صورت متأهل بودن تکمیل شود. اگر مجرد هستید این مرحله را رد کنید.',
            'blocks' => [
                [
                    'kind' => 'fixed', 'name' => 'spouses',
                    'title' => 'در صورت متأهل بودن، مشخصات همسر یا همسران',
                    'rows' => [
                        ['key' => 'current',  'label' => 'همسر فعلی'],
                        ['key' => 'previous', 'label' => 'همسر قبلی',   'gate' => 'has'],
                        ['key' => 'second',   'label' => 'همسر دوم',     'gate' => 'has'],
                    ],
                    'columns' => [
                        // این ستون در سربرگ ردیف رسم می‌شود و بقیه‌ی فیلدها را فعال/غیرفعال می‌کند
                        fld('has', 'وضعیت', ['type' => 'radio', 'options' => ['ندارد', 'دارد'], 'gate' => true, 'w' => 4]),
                        fld('full_name', 'نام و نام خانوادگی', ['type' => 'fa',
                            'required_when' => ['block' => 'personal', 'field' => 'marital', 'values' => ['متأهل']]]),
                        fld('prev_last_name', 'نام خانوادگی قبلی', ['type' => 'fa', 'none' => 'ندارد']),
                        fld('father_name', 'نام پدر', ['type' => 'fa', 'required_when' => ['block' => 'personal', 'field' => 'marital', 'values' => ['متأهل']]]),
                        fld('national_id', 'شماره ملی', ['type' => 'nid', 'required_when' => ['block' => 'personal', 'field' => 'marital', 'values' => ['متأهل']]]),
                        fld('birth_date', 'تاریخ تولد', ['type' => 'date', 'required_when' => ['block' => 'personal', 'field' => 'marital', 'values' => ['متأهل']]]),
                        fld('birth_place', 'محل تولد', ['type' => 'fa', 'required_when' => ['block' => 'personal', 'field' => 'marital', 'values' => ['متأهل']]]),
                        fld('birth_cert_no', 'شماره شناسنامه'),
                        fld('dual_nationality', 'تابعیت مضاعف', ['type' => 'radio',
                            'options' => ['دارد', 'ندارد'], 'required_when' => ['block' => 'personal', 'field' => 'marital', 'values' => ['متأهل']]]),
                        fld('dual_country', 'نام کشور', [
                            'when' => ['field' => 'dual_nationality', 'values' => ['دارد']]]),
                        fld('religion', 'دین و مذهب', ['type' => 'fa', 'required_when' => ['block' => 'personal', 'field' => 'marital', 'values' => ['متأهل']]]),
                        fld('marriage_date', 'تاریخ ازدواج', ['type' => 'date', 'required_when' => ['block' => 'personal', 'field' => 'marital', 'values' => ['متأهل']]]),
                        fld('education', 'میزان تحصیلات'),
                        fld('field_of_study', 'رشته تحصیلی'),
                        fld('job', 'شغل'),
                        fld('work_address', 'آدرس و تلفن محل اشتغال', ['type' => 'textarea', 'w' => 6]),
                        fld('email', 'پست الکترونیکی', ['type' => 'email']),
                    ],
                ],
            ],
        ],

        /* =================================================== گام ۳ — صفحه ۳ (۳ و ۴) */
        [
            'id'    => 'residence',
            'num'   => '۳',
            'title' => 'محل سکونت و خانواده',
            'desc'  => 'نشانی محل سکونت فعلی و قبلی و مشخصات بستگان درجه یک.',
            'blocks' => [
                [
                    'kind' => 'fixed', 'name' => 'residence',
                    'title' => '۳) نشانی و مشخصات دقیق محل سکونت فعلی و قبلی',
                    'rows' => [
                        ['key' => 'current',  'label' => 'محل سکونت فعلی'],
                        ['key' => 'previous', 'label' => 'محل سکونت قبلی'],
                    ],
                    'columns' => [
                        fld('from', 'زمان سکونت از', ['type' => 'date']),
                        fld('to', 'تا', ['type' => 'date']),
                        fld('address', 'آدرس', ['type' => 'textarea', 'w' => 12]),
                        fld('postal_code', 'کد پستی', ['type' => 'postal']),
                        fld('house_status', 'وضعیت منزل', ['type' => 'radio', 'options' => ['استیجاری', 'شخصی', 'سازمانی'], 'w' => 6]),
                    ],
                ],
                [
                    'kind' => 'repeat', 'name' => 'family',
                    'title' => '۴) مشخصات پدر، مادر، برادران، خواهران و فرزندان',
                    'row_label' => 'فرد',
                    'min' => 2,
                    'columns' => [
                        fld('full_name', 'نام و نام خانوادگی', ['type' => 'fa']),
                        fld('father_name', 'نام پدر', ['type' => 'fa']),
                        fld('relation', 'نسبت', ['type' => 'select', 'options' => ['پدر', 'مادر', 'برادر', 'خواهر', 'فرزند']]),
                        fld('age', 'سن', ['type' => 'number', 'w' => 2]),
                        fld('job', 'شغل'),
                        fld('address', 'آدرس محل سکونت و تلفن', ['type' => 'textarea', 'w' => 12]),
                    ],
                ],
            ],
        ],

        /* =================================================== گام ۴ — صفحه ۳ (۵) و صفحه ۴ (ج) */
        [
            'id'    => 'education',
            'num'   => '۴',
            'title' => 'تحصیلات و تخصص‌ها',
            'desc'  => 'سوابق تحصیلی، دوره‌های آموزشی و آشنایی با زبان‌های خارجی.',
            'blocks' => [
                [
                    'kind' => 'repeat', 'name' => 'education',
                    'title' => '۵-الف) تحصیلات از ابتدای دوره متوسطه تا دریافت آخرین مدرک تحصیلی',
                    'hint' => 'اعم از داخل یا خارج از کشور و یا حوزه علمیه.',
                    'row_label' => 'مقطع',
                    'min' => 1,
                    'columns' => [
                        fld('place', 'محل تحصیل'),
                        fld('field', 'رشته'),
                        fld('class_from', 'کلاس از', ['w' => 2]),
                        fld('class_to', 'کلاس تا', ['w' => 2]),
                        fld('date_from', 'تاریخ از', ['type' => 'date', 'w' => 2]),
                        fld('date_to', 'تاریخ تا', ['type' => 'date', 'w' => 2]),
                        fld('address', 'نشانی دقیق', ['type' => 'textarea', 'w' => 12]),
                    ],
                ],
                [
                    'kind' => 'repeat', 'name' => 'courses',
                    'title' => '۵-ب) دوره‌های آموزشی و تخصصی گذرانده شده',
                    'hint' => 'اعم از دوره‌های آموزشی، فنی، هنری، نظامی و ... .',
                    'row_label' => 'دوره',
                    'min' => 1,
                    'columns' => [
                        fld('name', 'نام دوره'),
                        fld('field', 'رشته تخصصی'),
                        fld('institute', 'نام مؤسسه'),
                        fld('from', 'مدت از', ['type' => 'date', 'w' => 2]),
                        fld('to', 'تا', ['type' => 'date', 'w' => 2]),
                        fld('address', 'نشانی دقیق', ['type' => 'textarea', 'w' => 12]),
                    ],
                ],
                [
                    'kind' => 'repeat', 'name' => 'languages',
                    'title' => '۵-ج) میزان آشنایی با زبان‌های خارجی',
                    'row_label' => 'زبان',
                    'min' => 1,
                    'columns' => [
                        fld('lang', 'نوع زبان'),
                        fld('level', 'میزان آشنایی', ['type' => 'select', 'options' => ['مقدماتی', 'متوسط', 'خوب', 'عالی', 'مکالمه', 'ترجمه']]),
                        fld('institute', 'نام مؤسسه'),
                        fld('from', 'مدت آموزش از', ['type' => 'date', 'w' => 2]),
                        fld('to', 'تا', ['type' => 'date', 'w' => 2]),
                        fld('address', 'نشانی دقیق', ['type' => 'textarea', 'w' => 12]),
                    ],
                ],
            ],
        ],

        /* =================================================== گام ۵ — صفحه ۴ (۶) */
        [
            'id'    => 'jobs',
            'num'   => '۵',
            'title' => 'مشاغل و سوابق همکاری',
            'desc'  => 'سوابق شغلی، همکاری با مؤسسات خارجی، نحوه جذب و بستگان شاغل در این دستگاه.',
            'blocks' => [
                [
                    'kind' => 'repeat', 'name' => 'jobs',
                    'title' => '۶-الف) هرگونه اشتغال و همکاری در دستگاه‌های دولتی و خصوصی',
                    'hint' => 'اعم از تمام وقت، نیمه وقت و یا پاره وقت.',
                    'row_label' => 'شغل',
                    'min' => 1,
                    'columns' => [
                        fld('title', 'نام شغل'),
                        fld('role', 'سمت و نوع فعالیت'),
                        fld('from', 'مدت اشتغال از', ['type' => 'date', 'w' => 2]),
                        fld('to', 'تا', ['type' => 'date', 'w' => 2]),
                        fld('leave_reason', 'علت تغییر شغل / قطع همکاری', ['w' => 4]),
                        fld('workplace', 'نام و آدرس دقیق محل کار و تلفن', ['type' => 'textarea', 'w' => 12]),
                    ],
                ],
                [
                    'kind' => 'fixed', 'name' => 'foreign_orgs',
                    'title' => '۶-ب) اشتغال یا همکاری با مؤسسات یا نمایندگی‌های خارجی در داخل و یا خارج از کشور',
                    'rows' => [
                        ['key' => 'self',      'label' => 'خود'],
                        ['key' => 'spouse',    'label' => 'همسر'],
                        ['key' => 'relatives', 'label' => 'بستگان و آشنایان'],
                    ],
                    'columns' => [
                        fld('role', 'سمت، نوع فعالیت یا همکاری', ['w' => 4]),
                        fld('duration', 'مدت اشتغال یا همکاری', ['w' => 4]),
                        fld('leave_reason', 'علت قطع همکاری', ['w' => 4]),
                        fld('workplace', 'نام و آدرس دقیق محل کار و تلفن', ['type' => 'textarea', 'w' => 12]),
                    ],
                ],
                [
                    'kind' => 'fields', 'name' => 'recruit',
                    'title' => '۶-ج) نحوه جذب خود به این وزارت / سازمان',
                    'fields' => [
                        fld('method', 'نحوه جذب', ['type' => 'textarea', 'w' => 12]),
                    ],
                ],
                [
                    'kind' => 'repeat', 'name' => 'referrers',
                    'title' => 'مشخصات معرف یا معرفین',
                    'row_label' => 'معرف',
                    'min' => 1,
                    'columns' => [
                        fld('full_name', 'نام و نام خانوادگی معرّف', ['type' => 'fa']),
                        fld('job', 'شغل و یا سمت وی'),
                        fld('relation', 'نسبت'),
                        fld('address', 'آدرس کامل و شماره تلفن', ['type' => 'textarea', 'w' => 12]),
                    ],
                ],
                [
                    'kind' => 'repeat', 'name' => 'relatives_in_org',
                    'title' => '۶-د) مشخصات بستگان (سببی و نسبی) خود که در این دستگاه شاغل بوده و هستند',
                    'row_label' => 'فرد',
                    'min' => 1,
                    'columns' => [
                        fld('full_name', 'نام و نام خانوادگی', ['type' => 'fa']),
                        fld('father_name', 'نام پدر', ['type' => 'fa']),
                        fld('relation', 'نسبت'),
                        fld('job', 'شغل و سمت'),
                        fld('work_phone', 'تلفن محل کار', ['type' => 'tel']),
                        fld('home', 'آدرس و تلفن محل سکونت', ['type' => 'textarea', 'w' => 12]),
                    ],
                ],
            ],
        ],

        /* =================================================== گام ۶ — صفحه ۵ (۷ تا ۱۲) */
        [
            'id'    => 'social',
            'num'   => '۶',
            'title' => 'مسافرت‌ها، دوستان، سلاح، احزاب و ایثارگری',
            'desc'  => 'بندهای ۷ تا ۱۲ فرم.',
            'blocks' => [
                [
                    'kind' => 'repeat', 'name' => 'travels',
                    'title' => '۷) مأموریت‌ها و مسافرت‌های خود و همسرتان به خارج از کشور',
                    'row_label' => 'سفر',
                    'min' => 1,
                    'columns' => [
                        fld('person', 'مربوط به', ['type' => 'select', 'options' => ['خود', 'همسر'], 'w' => 2]),
                        fld('country', 'کشور', ['w' => 2]),
                        fld('city', 'شهر', ['w' => 2]),
                        fld('duration', 'مدت مسافرت', ['w' => 2]),
                        fld('from', 'تاریخ از', ['type' => 'date', 'w' => 2]),
                        fld('to', 'تا', ['type' => 'date', 'w' => 2]),
                        fld('reason', 'علت مسافرت', ['w' => 6]),
                        fld('companions', 'نام همراهان', ['w' => 6]),
                    ],
                ],
                [
                    'kind' => 'repeat', 'name' => 'friends',
                    'title' => '۸) مشخصات ۴ نفر از دوستان اداری و غیراداری که با آنان ارتباط نزدیک و صمیمی دارید',
                    'row_label' => 'دوست',
                    'min' => 4,
                    'columns' => [
                        fld('full_name', 'نام و نام خانوادگی', ['type' => 'fa', 'w' => 4]),
                        fld('job', 'شغل یا سمت', ['w' => 4]),
                        fld('workplace', 'محل دقیق خدمتی و شماره تلفن', ['type' => 'textarea', 'w' => 12]),
                    ],
                ],
                [
                    'kind' => 'repeat', 'name' => 'weapons',
                    'title' => '۹) در صورتی که تاکنون اسلحه در اختیار داشته و یا دارید',
                    'row_label' => 'سلاح',
                    'min' => 1,
                    'columns' => [
                        fld('type', 'نوع'),
                        fld('from', 'تاریخ استفاده از', ['type' => 'date', 'w' => 2]),
                        fld('to', 'تا', ['type' => 'date', 'w' => 2]),
                        fld('how', 'چگونگی دریافت', ['w' => 4]),
                        fld('issuer', 'ارگان صادر کننده مجوّز', ['w' => 4]),
                        fld('notes', 'ملاحظات', ['w' => 4]),
                    ],
                ],
                [
                    'kind' => 'repeat', 'name' => 'parties',
                    'title' => '۱۰) ارتباط تشکیلاتی یا غیرتشکیلاتی با حزب، سازمان، گروه، محفل و جریانات سیاسی و اجتماعی',
                    'hint' => 'اعم از قانونی یا غیرقانونی — برای خود و همسر.',
                    'row_label' => 'مورد',
                    'min' => 1,
                    'columns' => [
                        fld('person', 'مربوط به', ['type' => 'select', 'options' => ['خود', 'همسر'], 'w' => 2]),
                        fld('party', 'نام حزب یا جریان سیاسی', ['w' => 4]),
                        fld('role', 'نوع مسئولیت و نوع فعالیت', ['w' => 3]),
                        fld('place', 'محل فعالیت', ['w' => 3]),
                        fld('from', 'مدت فعالیت از', ['type' => 'date', 'w' => 2]),
                        fld('to', 'تا', ['type' => 'date', 'w' => 2]),
                        fld('quit_reason', 'علت کناره‌گیری', ['w' => 4]),
                    ],
                ],
                [
                    'kind' => 'repeat', 'name' => 'sacrifice',
                    'title' => '۱۱) سابقه ایثارگری (رزمنده، جانباز، آزادگی) برابر گواهی مراجع رسمی',
                    'row_label' => 'سابقه',
                    'min' => 1,
                    'columns' => [
                        fld('sender', 'مرجع اعزام کننده'),
                        fld('type', 'نوع ایثارگری', ['type' => 'select', 'options' => ['رزمنده', 'جانباز', 'آزاده', 'سایر']]),
                        fld('from', 'تاریخ از', ['type' => 'date', 'w' => 2]),
                        fld('to', 'تا', ['type' => 'date', 'w' => 2]),
                        fld('zone', 'منطقه عملیاتی', ['w' => 4]),
                    ],
                ],
                [
                    'kind' => 'repeat', 'name' => 'sacrifice_relatives',
                    'title' => '۱۲) بستگان درجه یک ایثارگر',
                    'row_label' => 'فرد',
                    'min' => 1,
                    'columns' => [
                        fld('full_name', 'نام و نام خانوادگی', ['type' => 'fa', 'w' => 4]),
                        fld('relation', 'نسبت', ['w' => 2]),
                        fld('kind', 'عنوان', ['type' => 'checks', 'options' => ['شهید', 'مفقود', 'آزاده', 'جانباز'], 'w' => 6]),
                        fld('address', 'آدرس محل سکونت', ['type' => 'textarea', 'w' => 12]),
                    ],
                ],
            ],
        ],

        /* =================================================== گام ۷ — صفحه ۶ (۱۳ تا ۱۷) */
        [
            'id'    => 'records',
            'num'   => '۷',
            'title' => 'سوابق قضایی و بستگان خارج از کشور',
            'desc'  => 'بندهای ۱۳ تا ۱۷ فرم. در صورت نداشتن مورد، جدول‌ها را خالی بگذارید.',
            'blocks' => [
                [
                    'kind' => 'repeat', 'name' => 'detentions',
                    'title' => '۱۳) بازداشت یا دستگیری توسط مراجع قضایی، امنیتی، انتظامی یا اداری (قبل یا بعد از انقلاب)',
                    'hint' => 'در داخل یا خارج از کشور، و یا سابقه در آن مراجع.',
                    'row_label' => 'مورد',
                    'min' => 1,
                    'columns' => [
                        fld('date', 'تاریخ', ['type' => 'date', 'w' => 2]),
                        fld('charge', 'نوع اتهام', ['w' => 3]),
                        fld('arrest_date', 'تاریخ دستگیری یا احضار', ['type' => 'date', 'w' => 3]),
                        fld('reason', 'علت دستگیری یا احضار', ['w' => 4]),
                        fld('authority', 'محل و مرجع رسیدگی', ['w' => 4]),
                        fld('duration', 'مدت بازداشت', ['w' => 2]),
                        fld('result', 'نتیجه رسیدگی', ['w' => 6]),
                    ],
                ],
                [
                    'kind' => 'repeat', 'name' => 'foreign_relatives',
                    'title' => '۱۴) آشنایان و بستگان مقیم و یا تابع کشورهای بیگانه',
                    'row_label' => 'فرد',
                    'min' => 1,
                    'columns' => [
                        fld('full_name', 'نام و نام خانوادگی'),
                        fld('relation', 'نسبت', ['w' => 2]),
                        fld('country', 'نام کشور و شهر', ['w' => 3]),
                        fld('status', 'مقیم یا تابع', ['type' => 'select', 'options' => ['مقیم', 'تابع', 'هر دو'], 'w' => 2]),
                        fld('residence_reason', 'نوع و علت اقامت', ['w' => 4]),
                        fld('jobs', 'مشاغل در خارج', ['w' => 4]),
                    ],
                ],
                [
                    'kind' => 'repeat', 'name' => 'migrants',
                    'title' => '۱۵) بستگان نسبی و سببی جزو مهاجرین به ایران و یا از معاودین',
                    'row_label' => 'فرد',
                    'min' => 1,
                    'columns' => [
                        fld('full_name', 'نام و نام خانوادگی'),
                        fld('relation', 'نسبت', ['w' => 2]),
                        fld('migration_date', 'تاریخ مهاجرت', ['type' => 'date', 'w' => 3]),
                        fld('country', 'کشور خارجی', ['w' => 2]),
                        fld('reason', 'علت مهاجرت به ایران', ['w' => 4]),
                        fld('notes', 'ملاحظات', ['w' => 4]),
                    ],
                ],
                [
                    'kind' => 'repeat', 'name' => 'criminal_records',
                    'title' => '۱۶) هرگونه پیشینه کیفری بستگان درجه یک',
                    'row_label' => 'مورد',
                    'min' => 1,
                    'columns' => [
                        fld('full_name', 'نام و نام خانوادگی', ['type' => 'fa']),
                        fld('relation', 'نسبت', ['w' => 2]),
                        fld('charge', 'نوع اتهام', ['w' => 3]),
                        fld('date', 'تاریخ', ['type' => 'date', 'w' => 2]),
                        fld('authority', 'مرجع و محل رسیدگی', ['w' => 4]),
                        fld('result', 'نتیجه دادرسی', ['w' => 4]),
                        fld('status', 'وضعیت فعلی', ['w' => 4]),
                    ],
                ],
                [
                    'kind' => 'repeat', 'name' => 'groupings',
                    'title' => '۱۷) بستگان و آشنایان مرتبط با گروهک‌های ضدانقلاب',
                    'hint' => 'کسانی که فعالیت داشته و یا دستگیر، بازداشت، زندانی، اعدام یا متواری شده‌اند.',
                    'row_label' => 'فرد',
                    'min' => 1,
                    'columns' => [
                        fld('full_name', 'نام و نام خانوادگی', ['type' => 'fa']),
                        fld('father_name', 'نام پدر', ['type' => 'fa']),
                        fld('relation', 'نسبت', ['w' => 2]),
                        fld('activity', 'نوع و میزان فعالیت', ['w' => 4]),
                        fld('group', 'نام گروهک', ['w' => 3]),
                        fld('status', 'وضعیت فعلی', ['w' => 3]),
                    ],
                ],
            ],
        ],

        /* =================================================== گام ۸ — تعهد */
        [
            'id'    => 'pledge',
            'num'   => '۸',
            'title' => 'تعهد و امضا',
            'desc'  => 'صحت اطلاعات را تأیید و فرم را ثبت نهایی کنید.',
            'blocks' => [
                [
                    'kind' => 'fields', 'name' => 'pledge',
                    'title' => 'تعهدنامه',
                    'note'  => 'اینجانب متعهد می‌شوم هرگونه تغییر در اطلاعات مندرج در فرم را در اسرع وقت به آگاهی حراست برسانم و صحت کلیه اطلاعات فوق را تأیید می‌نمایم.',
                    'fields' => [
                        fld('filler_name', 'نام و نام خانوادگی تکمیل کننده', ['type' => 'fa', 'required' => true, 'w' => 4]),
                        fld('filler_date', 'تاریخ تکمیل', ['type' => 'date', 'required' => true, 'w' => 4]),
                        fld('accept', 'تأیید تعهدنامه', ['type' => 'radio', 'options' => ['می‌پذیرم'], 'required' => true, 'w' => 4]),
                        fld('signature', 'امضا', ['type' => 'sign', 'w' => 12, 'hint' => 'با ماوس یا انگشت امضا کنید (اختیاری).']),
                    ],
                ],
            ],
        ],
    ];

    return $steps;
}

/** دسترسی سریع به تعریف یک بلوک با نام آن */
function schema_block(string $name): ?array
{
    foreach (form_steps() as $step) {
        foreach ($step['blocks'] as $b) {
            if ($b['name'] === $name) return $b;
        }
    }
    return null;
}

/** فیلدهای یک بلوک، صرف‌نظر از نوع آن */
function block_fields(array $b): array
{
    return $b['kind'] === 'fields' ? $b['fields'] : $b['columns'];
}
