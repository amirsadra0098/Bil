<?php
/**
 * پنل سازنده — جدا از پنل مدیریت سازمان.
 *
 * مسیر آن در هیچ صفحه‌ای لینک نشده و رمز جداگانه دارد.
 * فعلاً تنها کارش روشن و خاموش کردن امضای سازنده در فوتر است.
 *
 * مدیریت از خط فرمان:  php tools/dev.php  (یا  sudo bash install.sh --dev)
 */

const DEV_SESSION_KEY = 'dev_ok';
const DEV_SESSION_TTL = 7200;          // ۲ ساعت

function dev_path(): string
{
    $p = trim((string)cfg('dev_path', 'dev'), '/');
    return $p !== '' ? $p : 'dev';
}

function dev_logged_in(): bool
{
    $t = $_SESSION[DEV_SESSION_KEY] ?? 0;
    if (!$t || (time() - (int)$t) > DEV_SESSION_TTL) {
        unset($_SESSION[DEV_SESSION_KEY]);
        return false;
    }
    $_SESSION[DEV_SESSION_KEY] = time();
    return true;
}

/** آیا رمزی تنظیم شده است؟ */
function dev_hash(): string
{
    return (string)app_setting('dev_pass', '');
}

function dev_set_password(string $plain): void
{
    set_setting('dev_pass', password_hash($plain, PASSWORD_DEFAULT));
}

/** قفل موقت پس از تلاش‌های ناموفق */
function dev_locked(): bool
{
    try {
        $st = db()->prepare(
            'SELECT COUNT(*) FROM login_attempts
             WHERE success = 0 AND username = ? AND created_at > ?'
        );
        $st->execute(['__dev', date('Y-m-d H:i:s', time() - 900)]);
        return (int)$st->fetchColumn() >= 6;
    } catch (Throwable $ex) { return false; }
}

function dev_record(bool $ok): void
{
    try {
        db()->prepare('INSERT INTO login_attempts (username, ip, success, created_at) VALUES (?, ?, ?, ?)')
            ->execute(['__dev', client_ip(), $ok ? 1 : 0, date('Y-m-d H:i:s')]);
    } catch (Throwable $ex) { /* بی‌اهمیت */ }
}

/**
 * آیا امضای سازنده باید نمایش داده شود؟
 * پیش‌فرض خاموش است؛ فقط از پنل سازنده یا install.sh --dev روشن می‌شود.
 */
function credit_enabled(): bool
{
    return app_setting('credit_enabled', '0') === '1';
}

/* ------------------------------------------------------------- صفحه */

function dev_page(string $method): void
{
    $err = null;
    $msg = null;

    // اولین اجرا: اگر رمزی ثبت نشده، کاربر باید رمز بسازد
    $needsSetup = (dev_hash() === '');

    if ($method === 'POST') {
        csrf_verify();
        $do = $_POST['do'] ?? '';

        if ($do === 'setup' && $needsSetup) {
            $p1 = (string)($_POST['p1'] ?? '');
            $p2 = (string)($_POST['p2'] ?? '');
            if (mb_strlen($p1) < 8)      $err = 'رمز باید حداقل ۸ نویسه باشد.';
            elseif ($p1 !== $p2)         $err = 'دو رمز یکسان نیستند.';
            else {
                dev_set_password($p1);
                $_SESSION[DEV_SESSION_KEY] = time();
                log_action('dev_setup', 'dev', null, 'ساخت رمز پنل سازنده');
                redirect(base_url(dev_path()));
            }

        } elseif ($do === 'login') {
            if (dev_locked()) {
                $err = 'به دلیل تلاش‌های ناموفق، ورود موقتاً مسدود است. ۱۵ دقیقه دیگر تلاش کنید.';
            } else {
                $capErr = captcha_check($_POST['captcha'] ?? '');
                if ($capErr !== null) {
                    $err = $capErr;
                } elseif (password_verify((string)($_POST['password'] ?? ''), dev_hash())) {
                    session_regenerate_id(true);
                    $_SESSION[DEV_SESSION_KEY] = time();
                    dev_record(true);
                    log_action('dev_login', 'dev', null, 'ورود به پنل سازنده');
                    redirect(base_url(dev_path()));
                } else {
                    dev_record(false);
                    log_action('dev_login_failed', 'dev', null, 'ورود ناموفق به پنل سازنده');
                    $err = 'رمز نادرست است.';
                }
            }

        } elseif (dev_logged_in()) {
            if ($do === 'credit') {
                $on = !empty($_POST['on']) ? '1' : '0';
                set_setting('credit_enabled', $on);
                log_action('credit_toggle', 'dev', null, 'امضای سازنده: ' . ($on === '1' ? 'روشن' : 'خاموش'));
                redirect(base_url(dev_path() . '?saved=1'));

            } elseif ($do === 'passwd') {
                $p1 = (string)($_POST['p1'] ?? '');
                $p2 = (string)($_POST['p2'] ?? '');
                if (mb_strlen($p1) < 8) $err = 'رمز باید حداقل ۸ نویسه باشد.';
                elseif ($p1 !== $p2)    $err = 'دو رمز یکسان نیستند.';
                else {
                    dev_set_password($p1);
                    log_action('dev_passwd', 'dev', null, 'تغییر رمز پنل سازنده');
                    $msg = 'رمز جدید ثبت شد.';
                }

            } elseif ($do === 'logout') {
                unset($_SESSION[DEV_SESSION_KEY]);
                redirect(base_url(dev_path()));
            }
        }
    }

    if (isset($_GET['saved'])) $msg = 'تنظیمات ذخیره شد.';

    view('dev', [
        'err'        => $err,
        'msg'        => $msg,
        'needsSetup' => $needsSetup,
        'loggedIn'   => dev_logged_in(),
        'creditOn'   => credit_enabled(),
    ]);
}
