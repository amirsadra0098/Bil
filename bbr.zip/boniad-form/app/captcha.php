<?php
/**
 * کد اعتبارسنجی (کپچا) برای صفحه‌ی ورود پنل مدیریت.
 *
 * کد در نشست ذخیره می‌شود، هر ۲ دقیقه توسط مرورگر به‌صورت خودکار نوسازی می‌گردد
 * و در سمت سرور هم پس از CAPTCHA_TTL ثانیه بی‌اعتبار می‌شود.
 */

const CAPTCHA_LEN   = 5;
const CAPTCHA_TTL   = 180;   // اعتبار سمت سرور (ثانیه)
const CAPTCHA_CYCLE = 120;   // دوره‌ی نوسازی خودکار در مرورگر (ثانیه)

/** نویسه‌های بدون ابهام (بدون O/0 و I/1/L) */
const CAPTCHA_CHARS = '23456789ACDEFGHJKMNPQRTUVWXYZ';

function captcha_new(): string
{
    $max  = strlen(CAPTCHA_CHARS) - 1;
    $code = '';
    for ($i = 0; $i < CAPTCHA_LEN; $i++) $code .= CAPTCHA_CHARS[random_int(0, $max)];

    $_SESSION['captcha'] = ['code' => $code, 'time' => time(), 'tries' => 0];
    return $code;
}

/**
 * بررسی کد واردشده. در صورت موفقیت null و در غیر این صورت پیام خطا برمی‌گرداند.
 * کد پس از هر بررسی باطل می‌شود (یک‌بارمصرف).
 */
function captcha_check($input): ?string
{
    $c = $_SESSION['captcha'] ?? null;
    unset($_SESSION['captcha']);           // همیشه یک‌بارمصرف

    $input = is_string($input) ? trim(en_num($input)) : '';

    if (!$c || !isset($c['code'], $c['time'])) {
        return 'کد اعتبارسنجی منقضی شده است؛ کد جدید را وارد کنید.';
    }
    if (time() - (int)$c['time'] > CAPTCHA_TTL) {
        return 'مهلت کد اعتبارسنجی به پایان رسیده است؛ کد جدید را وارد کنید.';
    }
    if ($input === '') {
        return 'کد اعتبارسنجی را وارد کنید.';
    }
    if (!hash_equals(strtoupper($c['code']), strtoupper($input))) {
        return 'کد اعتبارسنجی نادرست است.';
    }
    return null;
}

/** یافتن یک فونت TrueType برای رسم کپچا */
function captcha_font(): ?string
{
    static $found = false;
    if ($found !== false) return $found;

    $candidates = [
        // فونت همراه برنامه — روی سرور بدون اینترنت هم موجود است
        APP_ROOT . '/public/assets/fonts/Vazirmatn-Bold.ttf',
        '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
        '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
        '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf',
        '/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf',
        '/usr/share/fonts/truetype/freefont/FreeSansBold.ttf',
        '/usr/share/fonts/TTF/DejaVuSans-Bold.ttf',
        'C:/Windows/Fonts/arialbd.ttf',
        'C:/Windows/Fonts/tahomabd.ttf',
    ];
    foreach ($candidates as $f) {
        if (is_file($f) && is_readable($f)) return $found = $f;
    }
    return $found = null;
}

/**
 * تصویر PNG کپچا.
 * تعادل: نویسه‌ها درشت، ضخیم و تیره (خوانا برای انسان) ولی با چرخش، جابه‌جایی
 * عمودی، اعوجاج موجی ملایم و نویز کم‌رنگ (سخت برای تشخیص خودکار).
 */
function captcha_png(string $code): string
{
    $W = 190; $H = 62;
    $S = 2;                       // رسم در مقیاس دوبرابر و سپس کوچک‌سازی
    $w = $W * $S; $h = $H * $S;

    $img = imagecreatetruecolor($w, $h);
    imageantialias($img, true);
    imagefilledrectangle($img, 0, 0, $w, $h, imagecolorallocate($img, 249, 251, 253));

    /* ------------------------------- نویز پس‌زمینه (کم‌رنگ و نازک) */
    for ($i = 0; $i < 550; $i++) {
        $c = imagecolorallocate($img, random_int(206, 232), random_int(214, 236), random_int(222, 240));
        imagefilledellipse($img, random_int(0, $w), random_int(0, $h), 3, 3, $c);
    }
    imagesetthickness($img, 2);
    for ($i = 0; $i < 3; $i++) {
        $c = imagecolorallocate($img, random_int(198, 218), random_int(208, 226), random_int(216, 232));
        imagearc($img, random_int(0, $w), random_int(0, $h), random_int(150, 380),
                 random_int(70, 200), random_int(0, 180), random_int(180, 360), $c);
    }

    /* --------------------------------------- نویسه‌ها: درشت و تیره */
    $font = captcha_font();
    $len  = strlen($code);
    $step = (int)(($w - 26 * $S) / max($len, 1));

    for ($i = 0; $i < $len; $i++) {
        // رنگ‌های تیره و متفاوت تا جداسازی رنگی برای ربات آسان نباشد
        $col = [
            imagecolorallocate($img, random_int(8, 34),  random_int(30, 62),  random_int(72, 108)),
            imagecolorallocate($img, random_int(64, 96), random_int(12, 40),  random_int(52, 86)),
            imagecolorallocate($img, random_int(14, 42), random_int(64, 94),  random_int(48, 78)),
            imagecolorallocate($img, random_int(70, 98), random_int(46, 72),  random_int(10, 36)),
        ][random_int(0, 3)];

        $x = 13 * $S + $i * $step + random_int(-2 * $S, 2 * $S);

        if ($font) {
            $size  = random_int(48, 54);              // اندازه در مقیاس ۲x
            $angle = random_int(-26, 26);
            $y     = random_int(44, 50) * $S;
            // رسم چندباره با جابه‌جایی ۱ پیکسل = ضخیم‌تر و خواناتر
            foreach ([[0, 0], [1, 0], [0, 1], [1, 1]] as [$dx, $dy]) {
                imagettftext($img, $size, $angle, $x + $dx, $y + $dy, $col, $font, $code[$i]);
            }
        } else {
            imagestring($img, 5, (int)($x / $S), random_int(16, 28), $code[$i], $col);
        }
    }

    /* --------------- خطوط عبوری روی متن (ضد تشخیص خودکار) */
    // چند خط مورب سرتاسری با شفافیت، تا شکل نویسه‌ها را بشکند
    for ($i = 0; $i < 4; $i++) {
        imagesetthickness($img, random_int(3, 4));
        $lc = imagecolorallocatealpha($img,
            random_int(30, 95), random_int(50, 115), random_int(80, 145), random_int(38, 58));
        imageline($img,
            0,  random_int(14 * $S, $h - 14 * $S),
            $w, random_int(14 * $S, $h - 14 * $S), $lc);
    }
    // دو خط کوتاه عمودی/مورب روی ناحیه‌ی نویسه‌ها
    for ($i = 0; $i < 2; $i++) {
        imagesetthickness($img, 3);
        $lc = imagecolorallocatealpha($img,
            random_int(45, 110), random_int(65, 130), random_int(95, 160), 55);
        $x1 = random_int(10 * $S, $w - 10 * $S);
        imageline($img, $x1, random_int(6 * $S, 18 * $S),
                        $x1 + random_int(-14 * $S, 14 * $S), random_int($h - 20 * $S, $h - 6 * $S), $lc);
    }
    // دو کمان روی متن
    for ($i = 0; $i < 2; $i++) {
        imagesetthickness($img, random_int(3, 4));
        $ac = imagecolorallocatealpha($img,
            random_int(55, 120), random_int(80, 140), random_int(105, 165), 60);
        imagearc($img, random_int(20 * $S, $w - 20 * $S), random_int(20 * $S, $h - 20 * $S),
                 random_int(140, 300), random_int(50, 130), random_int(0, 200), random_int(200, 360), $ac);
    }

    imagesetthickness($img, 1);
    for ($i = 0; $i < 220; $i++) {
        $c = imagecolorallocate($img, random_int(145, 198), random_int(160, 208), random_int(178, 216));
        imagesetpixel($img, random_int(0, $w - 1), random_int(0, $h - 1), $c);
    }

    /* ------------------------- اعوجاج موجی ملایم (ضد OCR) */
    $bgc = imagecolorallocate($img, 249, 251, 253);

    $tmp = imagecreatetruecolor($w, $h);
    imagefilledrectangle($tmp, 0, 0, $w, $h, $bgc);
    $ay = random_int(3, 5) * $S; $py = random_int(70, 110) * $S; $oy = random_int(0, 62) / 10;
    for ($x = 0; $x < $w; $x++) {
        $dy = (int)round($ay * sin($x / $py * M_PI * 2 + $oy));
        imagecopy($tmp, $img, $x, max(0, $dy), $x, max(0, -$dy), 1, $h - abs($dy));
    }
    imagedestroy($img);

    $out = imagecreatetruecolor($w, $h);
    imagefilledrectangle($out, 0, 0, $w, $h, $bgc);
    $ax = random_int(2, 4) * $S; $px = random_int(60, 100) * $S; $ox = random_int(0, 62) / 10;
    for ($y = 0; $y < $h; $y++) {
        $dx = (int)round($ax * sin($y / $px * M_PI * 2 + $ox));
        imagecopy($out, $tmp, max(0, $dx), $y, max(0, -$dx), $y, $w - abs($dx), 1);
    }
    imagedestroy($tmp);

    /* ---------------------------------- کوچک‌سازی و کادر نهایی */
    $small = imagescale($out, $W, $H, IMG_BICUBIC);
    imagedestroy($out);
    if ($small === false) return '';

    imagerectangle($small, 0, 0, $W - 1, $H - 1, imagecolorallocate($small, 200, 210, 222));

    ob_start();
    imagepng($small, null, 8);
    $bin = ob_get_clean();
    imagedestroy($small);

    return $bin;
}

/** نسخه‌ی SVG برای زمانی که افزونه‌ی GD نصب نیست */
function captcha_svg(string $code): string
{
    $w = 190; $h = 62;
    $s = '<svg xmlns="http://www.w3.org/2000/svg" width="' . $w . '" height="' . $h . '" viewBox="0 0 ' . $w . ' ' . $h . '">'
       . '<rect width="100%" height="100%" fill="#f7f9fc" stroke="#c8d2de"/>';
    for ($i = 0; $i < 6; $i++) {
        $s .= '<path d="M' . random_int(0, 40) . ',' . random_int(0, $h) . ' Q' . random_int(50, 120) . ','
            . random_int(-10, $h + 10) . ' ' . random_int(130, $w) . ',' . random_int(0, $h)
            . '" fill="none" stroke="#b9c6d6" stroke-width="' . random_int(1, 2) . '"/>';
    }
    $len = strlen($code);
    for ($i = 0; $i < $len; $i++) {
        $x = 18 + $i * (int)(($w - 26) / max($len, 1));
        $y = random_int(36, 44);
        $r = random_int(-22, 22);
        $s .= '<text x="' . $x . '" y="' . $y . '" font-family="monospace" font-size="' . random_int(24, 29)
            . '" font-weight="bold" fill="rgb(' . random_int(10, 60) . ',' . random_int(45, 95) . ',' . random_int(90, 135) . ')"'
            . ' transform="rotate(' . $r . ' ' . $x . ' ' . $y . ')">' . htmlspecialchars($code[$i], ENT_XML1) . '</text>';
    }
    return $s . '</svg>';
}

/** ارسال تصویر کپچای تازه به مرورگر */
function captcha_output(): void
{
    $code = captcha_new();

    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Expires: 0');
    header('X-Content-Type-Options: nosniff');

    if (extension_loaded('gd') && function_exists('imagecreatetruecolor')) {
        header('Content-Type: image/png');
        echo captcha_png($code);
    } else {
        header('Content-Type: image/svg+xml');
        echo captcha_svg($code);
    }
    exit;
}
