<?php
/**
 * مدیریت نشان (لوگو) سازمان.
 *
 * نشان پیش‌فرض همراه برنامه است؛ مدیر ارشد می‌تواند از بخش تنظیمات
 * فایل دیگری بارگذاری کند. فایل بارگذاری‌شده در storage نگهداری و
 * از طریق مسیر /brand/logo ارائه می‌شود (هرگز داخل ریشه‌ی وب ذخیره نمی‌شود).
 */

const LOGO_MAX_BYTES  = 2097152;   // ۲ مگابایت
const LOGO_MAX_HEIGHT = 400;       // ارتفاع نهایی پس از بازسازی

function logo_dir(): string { return STORAGE_DIR . '/branding'; }
function logo_upload_path(): string { return logo_dir() . '/logo.png'; }
function logo_default_path(): string { return APP_ROOT . '/public/assets/img/logo.png'; }

/** مسیر فایلی که باید استفاده شود (بارگذاری‌شده یا پیش‌فرض) */
function logo_file(): ?string
{
    $up = logo_upload_path();
    if (is_file($up) && filesize($up) > 0) return $up;
    $def = logo_default_path();
    return is_file($def) ? $def : null;
}

function has_custom_logo(): bool
{
    $up = logo_upload_path();
    return is_file($up) && filesize($up) > 0;
}

/** نشانی نمایش نشان در صفحات */
function logo_url(): ?string
{
    if (has_custom_logo()) {
        return base_url('brand/logo?v=' . filemtime(logo_upload_path()));
    }
    $def = logo_default_path();
    return is_file($def) ? base_url('assets/img/logo.png?v=' . filemtime($def)) : null;
}

/** تگ تصویر نشان؛ اگر نشانی نبود، متن جایگزین برمی‌گردد */
function logo_img(string $class = 'brand-logo', string $alt = ''): string
{
    $u = logo_url();
    $alt = $alt !== '' ? $alt : app_setting('org_title', cfg('org_title', 'نشان سازمان'));
    if (!$u) return '';
    return '<img src="' . e($u) . '" class="' . e($class) . '" alt="' . e($alt) . '">';
}

/** ارائه‌ی فایل نشان بارگذاری‌شده */
function logo_output(): void
{
    $f = logo_file();
    if (!$f) { http_response_code(404); exit; }

    $etag = '"' . md5($f . filemtime($f) . filesize($f)) . '"';
    if (($_SERVER['HTTP_IF_NONE_MATCH'] ?? '') === $etag) { http_response_code(304); exit; }

    header('Content-Type: image/png');
    header('Content-Length: ' . filesize($f));
    header('Cache-Control: public, max-age=86400');
    header('ETag: ' . $etag);
    header('X-Content-Type-Options: nosniff');
    readfile($f);
    exit;
}

/**
 * ذخیره‌ی نشان بارگذاری‌شده.
 * تصویر با GD بازسازی می‌شود تا هر محتوای جاسازی‌شده حذف گردد.
 * @return string|null پیام خطا یا null در صورت موفقیت
 */
function save_logo(array $file): ?string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        return match ($file['error'] ?? 0) {
            UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'حجم فایل بیش از حد مجاز است.',
            UPLOAD_ERR_NO_FILE => 'فایلی انتخاب نشده است.',
            default => 'بارگذاری فایل انجام نشد.',
        };
    }
    if (!is_uploaded_file($file['tmp_name'] ?? '')) return 'فایل معتبر نیست.';
    if (($file['size'] ?? 0) > LOGO_MAX_BYTES) return 'حجم فایل باید کمتر از ۲ مگابایت باشد.';

    if (!extension_loaded('gd')) return 'افزونه GD در سرور فعال نیست.';

    $info = @getimagesize($file['tmp_name']);
    if (!$info) return 'فایل انتخاب‌شده تصویر نیست.';

    [$w, $h, $type] = $info;
    if ($w < 16 || $h < 16)       return 'ابعاد تصویر بسیار کوچک است.';
    if ($w > 4000 || $h > 4000)   return 'ابعاد تصویر بسیار بزرگ است.';

    $src = match ($type) {
        IMAGETYPE_PNG  => @imagecreatefrompng($file['tmp_name']),
        IMAGETYPE_JPEG => @imagecreatefromjpeg($file['tmp_name']),
        IMAGETYPE_GIF  => @imagecreatefromgif($file['tmp_name']),
        IMAGETYPE_WEBP => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($file['tmp_name']) : false,
        default        => false,
    };
    if (!$src) return 'قالب تصویر پشتیبانی نمی‌شود. از PNG، JPG یا WEBP استفاده کنید.';

    // مقیاس‌دهی با حفظ شفافیت
    $scale = min(1, LOGO_MAX_HEIGHT / $h);
    $nw = max(1, (int)round($w * $scale));
    $nh = max(1, (int)round($h * $scale));

    $dst = imagecreatetruecolor($nw, $nh);
    imagealphablending($dst, false);
    imagesavealpha($dst, true);
    imagefill($dst, 0, 0, imagecolorallocatealpha($dst, 0, 0, 0, 127));
    imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $w, $h);
    imagedestroy($src);

    if (!is_dir(logo_dir())) @mkdir(logo_dir(), 0770, true);
    $ok = imagepng($dst, logo_upload_path(), 8);
    imagedestroy($dst);

    if (!$ok) return 'ذخیره‌ی فایل ممکن نشد؛ دسترسی پوشه‌ی storage را بررسی کنید.';
    @chmod(logo_upload_path(), 0640);
    return null;
}

function delete_logo(): void
{
    if (is_file(logo_upload_path())) @unlink(logo_upload_path());
}
