<?php
/**
 * توابع مشترک کار با داده‌های فرم (هم در نمایش، هم در خروجی‌ها استفاده می‌شود).
 */

const STATUS_LABELS = [
    'new'        => 'در انتظار بررسی',
    'reviewing'  => 'در حال بررسی',
    'approved'   => 'تأیید شده',
    'rejected'   => 'رد شده',
    'incomplete' => 'نیازمند اصلاح',
];

const STATUS_CLASS = [
    'new'        => 'st-new',
    'reviewing'  => 'st-rev',
    'approved'   => 'st-ok',
    'rejected'   => 'st-no',
    'incomplete' => 'st-warn',
];

function status_label(?string $s): string { return STATUS_LABELS[$s ?? 'new'] ?? 'نامشخص'; }
function status_class(?string $s): string { return STATUS_CLASS[$s ?? 'new'] ?? 'st-new'; }

function is_blank($v): bool
{
    if (is_array($v)) {
        foreach ($v as $x) if (trim((string)$x) !== '') return false;
        return true;
    }
    return trim((string)$v) === '';
}

/** مقدار خوانا برای یک فیلد */
function field_text(array $f, $v): string
{
    if (is_array($v)) {
        $v = array_filter(array_map('strval', $v), fn($x) => trim($x) !== '');
        return implode('، ', $v);
    }
    $v = trim((string)$v);
    if ($v === '') return '';
    if (in_array($f['type'] ?? '', ['date', 'tel', 'nid', 'postal', 'number'], true)) return fa_num($v);
    return $v;
}

/** ردیف‌های غیرخالی یک بلوک تکرارشونده */
function clean_rows(array $block, $raw): array
{
    $out = [];
    if (!is_array($raw)) return $out;
    foreach ($raw as $row) {
        if (!is_array($row)) continue;
        foreach ($block['columns'] as $c) {
            if (!is_blank($row[$c['name']] ?? '')) { $out[] = $row; break; }
        }
    }
    return $out;
}

/** آیا بلوک اصلاً داده‌ای دارد؟ */
function block_has_data(array $b, $val): bool
{
    if ($b['kind'] === 'fields') {
        foreach ($b['fields'] as $f) if (!is_blank($val[$f['name']] ?? '')) return true;
        return false;
    }
    if ($b['kind'] === 'fixed') {
        foreach ($b['rows'] as $r) {
            foreach ($b['columns'] as $c) if (!is_blank($val[$r['key']][$c['name']] ?? '')) return true;
        }
        return false;
    }
    return count(clean_rows($b, $val)) > 0;
}

function sub_full_name(array $sub): string
{
    return trim(($sub['first_name'] ?? '') . ' ' . ($sub['last_name'] ?? '')) ?: 'بدون نام';
}

function safe_filename(string $s): string
{
    $s = preg_replace('/[\/\\\\:*?"<>|]+/u', '-', $s);
    return trim(preg_replace('/\s+/u', ' ', $s));
}

const LOG_LABELS = [
    'submit'          => 'ثبت فرم',
    'view'            => 'مشاهده فرم',
    'print'           => 'چاپ فرم',
    'export_docx'     => 'خروجی Word',
    'export_xlsx'     => 'خروجی Excel',
    'export_list'     => 'خروجی فهرست',
    'search'          => 'جستجو',
    'login'           => 'ورود',
    'logout'          => 'خروج',
    'login_failed'    => 'ورود ناموفق',
    'login_captcha_failed' => 'کد اعتبارسنجی نادرست',
    'status_change'   => 'تغییر وضعیت',
    'delete'          => 'حذف فرم',
    'settings_update' => 'تغییر تنظیمات',
    'logo_upload'     => 'بارگذاری نشان',
    'logo_remove'     => 'حذف نشان',
    'dev_login'       => 'ورود پنل سازنده',
    'dev_login_failed'=> 'ورود ناموفق پنل سازنده',
    'dev_setup'       => 'ساخت رمز پنل سازنده',
    'dev_passwd'      => 'تغییر رمز پنل سازنده',
    'credit_toggle'   => 'تغییر امضای سازنده',
    'password_change' => 'تغییر رمز',
    'admin_add'       => 'افزودن کاربر',
    'admin_toggle'    => 'فعال/غیرفعال کاربر',
    'admin_reset'     => 'بازنشانی رمز کاربر',
];

function log_action_label(?string $a): string { return LOG_LABELS[$a ?? ''] ?? ($a ?: '—'); }
