<?php
/**
 * راه‌اندازی اولیه برنامه
 */

declare(strict_types=1);

define('APP_ROOT', dirname(__DIR__));
define('APP_DIR', __DIR__);
define('STORAGE_DIR', APP_ROOT . '/storage');

mb_internal_encoding('UTF-8');
date_default_timezone_set('Asia/Tehran');

$configFile = APP_DIR . '/config.php';
if (!is_file($configFile)) {
    http_response_code(500);
    exit('فایل پیکربندی یافت نشد. لطفاً install.sh را اجرا کنید یا config.sample.php را به config.php تغییر نام دهید.');
}
$GLOBALS['CONFIG'] = require $configFile;

define('BASE_PATH_URL', $GLOBALS['CONFIG']['base_path'] ?? '');

if (!empty($GLOBALS['CONFIG']['debug'])) {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
    error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE);
}
ini_set('log_errors', '1');
ini_set('error_log', STORAGE_DIR . '/logs/php-error.log');

require APP_DIR . '/helpers.php';
require APP_DIR . '/db.php';
require APP_DIR . '/form_schema.php';
require APP_DIR . '/formdata.php';
require APP_DIR . '/render.php';
require APP_DIR . '/auth.php';
require APP_DIR . '/captcha.php';
require APP_DIR . '/branding.php';
require APP_DIR . '/dev.php';

if (PHP_SAPI !== 'cli') {
    ob_start('credit_filter');
}

if (PHP_SAPI !== 'cli' && session_status() === PHP_SESSION_NONE) {
    session_name('BMFORM');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => BASE_PATH_URL === '' ? '/' : BASE_PATH_URL,
        'httponly' => true,
        'samesite' => 'Lax',
        'secure'   => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
    ]);
    session_start();
}

/** رندر یک ویو */
function view(string $name, array $vars = []): void {
    extract($vars, EXTR_SKIP);
    require APP_DIR . '/views/' . $name . '.php';
}

/** خروجی JSON */
function json_out($data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function cfg(string $key, $default = null) { return $GLOBALS['CONFIG'][$key] ?? $default; }

/* =============================================================================
 *  امضای سازنده
 *
 *  در فوتر همه‌ی صفحات درج می‌شود. اگر از قالب‌ها برداشته شود، فیلتر خروجی
 *  آن را دوباره پیش از </body> تزریق می‌کند و اسکریپت همراهش هم اگر در
 *  مرورگر حذف یا پنهان شود آن را برمی‌گرداند.
 * ========================================================================== */

const CREDIT_MARK = 'data-credit="rhino"';
const CREDIT_SITE = 'rhino-team.ir';

function credit_html(): string
{
    if (!credit_enabled()) return '';

    $box = '<div class="site-credit" ' . CREDIT_MARK . '>'
         . 'ساخته شده توسط <a href="https://' . CREDIT_SITE . '" target="_blank" rel="noopener">'
         . CREDIT_SITE . '</a></div>';

    $json = json_encode($box, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $sel  = json_encode('[' . CREDIT_MARK . ']', JSON_UNESCAPED_SLASHES);

    $js = <<<JS
<script>
(function () {
  var HTML = {$json}, SEL = {$sel};
  function keep() {
    var el = document.querySelector(SEL);
    if (!el) {
      var box = document.createElement('div');
      box.innerHTML = HTML;
      if (box.firstElementChild && document.body) document.body.appendChild(box.firstElementChild);
      return;
    }
    var c = getComputedStyle(el);
    if (c.display === 'none' || c.visibility === 'hidden' ||
        parseFloat(c.opacity) < 0.4 || parseInt(c.fontSize, 10) < 8) {
      el.setAttribute('style', 'display:block !important;visibility:visible !important;' +
        'opacity:1 !important;font-size:12.5px !important;height:auto !important;' +
        'width:auto !important;position:static !important;clip:auto !important;overflow:visible !important');
    }
  }
  if (window.MutationObserver) {
    new MutationObserver(keep).observe(document.documentElement,
      { childList: true, subtree: true, attributes: true, attributeFilter: ['style', 'class'] });
  }
  setInterval(keep, 3000);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', keep);
  else keep();
})();
</script>
JS;

    return $box . $js;
}

/** اگر امضا در خروجی نبود، پیش از بسته شدن body اضافه می‌شود */
function credit_filter(string $html): string
{
    if ($html === '' || strpos($html, CREDIT_MARK) !== false) return $html;
    if (!credit_enabled()) return $html;

    $pos = strripos($html, '</body>');
    if ($pos === false) return $html;          // پاسخ‌های غیر HTML (فایل، ریدایرکت) دست نمی‌خورند

    return substr($html, 0, $pos) . credit_html() . substr($html, $pos);
}
