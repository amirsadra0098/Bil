<?php
/**
 * احراز هویت مدیران
 */

/**
 * فقط مسیرهای داخلی پذیرفته می‌شوند تا امکان Open Redirect وجود نداشته باشد.
 * هر ورودی مشکوک به داشبورد بازمی‌گردد.
 */
function safe_internal_path(string $uri): string
{
    // حذف بایت تهی و کاراکترهای خط جدید (جلوگیری از تزریق هدر)
    $uri = str_replace([chr(0), chr(13), chr(10)], '', $uri);

    if ($uri === '' || $uri[0] !== '/')                  return base_url('admin');
    if (str_starts_with($uri, '//'))                     return base_url('admin');  // پروتکل‌نسبی
    if (str_starts_with($uri, '/' . chr(92)))              return base_url('admin');  // \evil
    if (!preg_match('#^/[A-Za-z0-9_\-/.?=&%]*$#', $uri)) return base_url('admin');

    return $uri;
}

function current_admin(): ?array
{
    return $_SESSION['admin'] ?? null;
}

function require_admin(): array
{
    $a = current_admin();
    if (!$a) {
        $_SESSION['after_login'] = safe_internal_path($_SERVER['REQUEST_URI'] ?? '');
        redirect(base_url('admin/login'));
    }
    if (!empty($_SESSION['admin_expires']) && time() > $_SESSION['admin_expires']) {
        admin_logout('انقضای نشست');
        redirect(base_url('admin/login?expired=1'));
    }
    $_SESSION['admin_expires'] = time() + 3600 * 4;
    return $a;
}

function is_superadmin(): bool
{
    $a = current_admin();
    return $a && ($a['role'] ?? '') === 'super';
}

/** آیا این IP/کاربر به دلیل تلاش‌های ناموفق قفل شده است؟ */
function login_locked(string $username): bool
{
    $since = date('Y-m-d H:i:s', time() - 900); // ۱۵ دقیقه اخیر
    $st = db()->prepare(
        'SELECT COUNT(*) FROM login_attempts WHERE success = 0 AND created_at > ? AND (username = ? OR ip = ?)'
    );
    $st->execute([$since, $username, client_ip()]);
    return (int)$st->fetchColumn() >= 8;
}

function record_login_attempt(string $username, bool $ok): void
{
    try {
        db()->prepare('INSERT INTO login_attempts (username, ip, success, created_at) VALUES (?, ?, ?, ?)')
            ->execute([mb_substr($username, 0, 80), client_ip(), $ok ? 1 : 0, date('Y-m-d H:i:s')]);
        // پاک‌سازی رکوردهای قدیمی‌تر از ۷ روز
        db()->prepare('DELETE FROM login_attempts WHERE created_at < ?')
            ->execute([date('Y-m-d H:i:s', time() - 7 * 86400)]);
    } catch (Throwable $ex) { /* بی‌اهمیت */ }
}

function admin_login(string $username, string $password): array
{
    if ($username === '' || $password === '') {
        return [false, 'نام کاربری و رمز عبور را وارد کنید.'];
    }
    if (login_locked($username)) {
        return [false, 'به دلیل تلاش‌های ناموفق متعدد، ورود موقتاً مسدود شده است. ۱۵ دقیقه دیگر تلاش کنید.'];
    }

    $st = db()->prepare('SELECT * FROM admins WHERE username = ?');
    $st->execute([$username]);
    $row = $st->fetch();

    if (!$row || !password_verify($password, $row['password_hash']) || (int)$row['is_active'] !== 1) {
        record_login_attempt($username, false);
        log_action('login_failed', 'admin', $row['id'] ?? null, 'نام کاربری: ' . $username);
        return [false, 'نام کاربری یا رمز عبور نادرست است.'];
    }

    record_login_attempt($username, true);
    session_regenerate_id(true);
    $_SESSION['admin'] = [
        'id'           => (int)$row['id'],
        'username'     => $row['username'],
        'display_name' => $row['display_name'] ?: $row['username'],
        'role'         => $row['role'],
    ];
    $_SESSION['admin_expires'] = time() + 3600 * 4;

    db()->prepare('UPDATE admins SET last_login_at = ? WHERE id = ?')
        ->execute([date('Y-m-d H:i:s'), $row['id']]);

    log_action('login', 'admin', $row['id'], 'ورود موفق');
    return [true, ''];
}

function admin_logout(string $reason = ''): void
{
    if (current_admin()) log_action('logout', 'admin', current_admin()['id'], $reason);
    unset($_SESSION['admin'], $_SESSION['admin_expires']);
}

function password_problem(string $p): ?string
{
    if (mb_strlen($p) < 8) return 'رمز عبور باید حداقل ۸ نویسه باشد.';
    if (!preg_match('/[A-Za-z]/', $p) || !preg_match('/\d/', $p)) {
        return 'رمز عبور باید شامل حروف و عدد باشد.';
    }
    return null;
}
