<div class="wrap" style="padding-top:0">
  <p class="muted" style="text-align:center;margin:0">
    <?= e(app_setting('org_title', cfg('org_title', ''))) ?> —
    <?= e(app_setting('sub_title', cfg('sub_title', ''))) ?>
    · اطلاعات این فرم محرمانه است.
  </p>
  <?= credit_html() ?>
</div>
</body>
</html>
