<?php $pageTitle = 'پیگیری وضعیت'; require __DIR__ . '/_top.php'; ?>
<div class="wrap wrap-narrow">
  <div class="card">
    <div class="card-head"><h2>پیگیری وضعیت فرم</h2></div>

    <?php if ($err): ?><div class="alert err"><b>⚠</b><div><?= e($err) ?></div></div><?php endif; ?>

    <?php if ($result): ?>
      <div class="alert ok"><b>✓</b><div>فرم شما یافت شد.</div></div>
      <div class="kv">
        <div><b>کد رهگیری</b><span><?= e($result['tracking_code']) ?></span></div>
        <div><b>نام و نام خانوادگی</b><span><?= e(trim($result['first_name'] . ' ' . $result['last_name'])) ?></span></div>
        <div><b>تاریخ ثبت</b><span><?= e(jdate($result['created_at'], true)) ?></span></div>
        <div><b>وضعیت</b><span><span class="badge <?= e(status_class($result['status'])) ?>"><?= e(status_label($result['status'])) ?></span></span></div>
        <?php if ($result['reviewed_at']): ?>
          <div><b>تاریخ بررسی</b><span><?= e(jdate($result['reviewed_at'], true)) ?></span></div>
        <?php endif; ?>
      </div>
      <div class="btn-row" style="margin-top:16px"><a class="btn ghost" href="<?= e(base_url('track')) ?>">جستجوی دیگر</a></div>
    <?php else: ?>
      <form method="post" action="<?= e(base_url('track')) ?>">
        <?= csrf_field() ?>
        <div class="grid">
          <div class="f w6">
            <label class="lbl" for="tc">کد رهگیری<span class="req">*</span></label>
            <input type="text" id="tc" name="code" required placeholder="BM-05-A1B2C3" style="direction:ltr;text-align:center">
          </div>
          <div class="f w6">
            <label class="lbl" for="ni">کد ملی<span class="req">*</span></label>
            <input type="text" id="ni" name="national_id" required maxlength="10" inputmode="numeric" placeholder="۱۰ رقم">
          </div>
        </div>
        <div class="btn-row" style="margin-top:14px"><button class="btn" type="submit">جستجو</button></div>
      </form>
    <?php endif; ?>
  </div>
</div>
<?php require __DIR__ . '/_bottom.php'; ?>
