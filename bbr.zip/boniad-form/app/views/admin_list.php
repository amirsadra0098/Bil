<?php
$pageTitle = 'فرم‌های ثبت‌شده'; $adminPage = 'submissions';
require __DIR__ . '/_admin_top.php';
$qs = function (array $over = []) use ($q, $status, $from, $to, $sort) {
    return http_build_query(array_merge(compact('q', 'status', 'from', 'to', 'sort'), $over));
};
?>

<div class="page-head">
  <h1>فرم‌های ثبت‌شده</h1>
  <span class="badge st-new"><?= e(fa_num($total)) ?> مورد</span>
  <div class="spacer"></div>
  <a class="btn gold sm" href="<?= e(base_url('admin/export-list?' . $qs())) ?>">⬇ خروجی اکسل فهرست</a>
</div>

<div class="card">
  <form method="get" action="<?= e(base_url('admin/submissions')) ?>" class="filters">
    <div class="fx grow">
      <label class="lbl" for="q">جستجو (نام، نام خانوادگی، کد ملی، کد رهگیری، تلفن، محل خدمت)</label>
      <input type="text" id="q" name="q" value="<?= e($q) ?>" placeholder="مثلاً: احمدی یا ۰۰۱۲۳۴۵۶۷۸">
    </div>
    <div class="fx">
      <label class="lbl" for="st">وضعیت</label>
      <select id="st" name="status">
        <option value="">همه</option>
        <?php foreach (STATUS_LABELS as $k => $v): ?>
          <option value="<?= e($k) ?>"<?= $status === $k ? ' selected' : '' ?>><?= e($v) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="fx">
      <label class="lbl" for="from">از تاریخ</label>
      <div class="date-wrap"><input type="text" class="date-input" id="from" name="from" value="<?= e($from) ?>" placeholder="۱۴۰۳/۰۱/۰۱" autocomplete="off"></div>
    </div>
    <div class="fx">
      <label class="lbl" for="to">تا تاریخ</label>
      <div class="date-wrap"><input type="text" class="date-input" id="to" name="to" value="<?= e($to) ?>" placeholder="۱۴۰۳/۱۲/۲۹" autocomplete="off"></div>
    </div>
    <div class="fx">
      <label class="lbl" for="sort">ترتیب</label>
      <select id="sort" name="sort">
        <option value="new"<?= $sort === 'DESC' ? ' selected' : '' ?>>جدیدترین</option>
        <option value="old"<?= $sort === 'ASC' ? ' selected' : '' ?>>قدیمی‌ترین</option>
      </select>
    </div>
    <div class="fx">
      <button class="btn" type="submit">جستجو</button>
    </div>
    <?php if ($q !== '' || $status !== '' || $from !== '' || $to !== ''): ?>
      <div class="fx"><a class="btn ghost" href="<?= e(base_url('admin/submissions')) ?>">حذف فیلترها</a></div>
    <?php endif; ?>
  </form>
</div>

<div class="card" style="padding:0;overflow:hidden">
  <?php if (!$rows): ?>
    <div class="empty" style="margin:0;border-radius:0;padding:40px">موردی مطابق جستجوی شما یافت نشد.</div>
  <?php else: ?>
    <div class="table-wrap" style="border:0">
      <table class="tbl" style="min-width:1000px">
        <thead><tr>
          <th class="c" style="width:44px">#</th>
          <th>کد رهگیری</th><th>نام و نام خانوادگی</th><th>نام پدر</th>
          <th>کد ملی</th><th>تلفن همراه</th><th>محل خدمت / پست</th>
          <th>وضعیت</th><th>تاریخ ثبت</th><th style="width:210px"></th>
        </tr></thead>
        <tbody>
        <?php $i = ($page - 1) * 20; foreach ($rows as $r): $i++; ?>
          <tr>
            <td class="c muted"><?= e(fa_num($i)) ?></td>
            <td class="nowrap" style="direction:ltr;text-align:right"><b><?= e($r['tracking_code']) ?></b></td>
            <td class="nowrap"><?= e(trim($r['first_name'] . ' ' . $r['last_name']) ?: '—') ?></td>
            <td class="nowrap"><?= e($r['father_name'] ?: '—') ?></td>
            <td class="nowrap"><?= e(fa_num($r['national_id']) ?: '—') ?></td>
            <td class="nowrap"><?= e(fa_num($r['mobile']) ?: '—') ?></td>
            <td><?= e(str_limit($r['org_name'], 28) ?: '—') ?><?php if ($r['position']): ?><br><span class="muted"><?= e(str_limit($r['position'], 28)) ?></span><?php endif; ?></td>
            <td><span class="badge <?= e(status_class($r['status'])) ?>"><?= e(status_label($r['status'])) ?></span></td>
            <td class="nowrap"><?= e(jdate($r['created_at'], true)) ?></td>
            <td class="nowrap">
              <a class="btn ghost xs" href="<?= e(base_url('admin/view?id=' . $r['id'])) ?>">مشاهده</a>
              <a class="btn ghost xs" href="<?= e(base_url('admin/export?type=docx&id=' . $r['id'])) ?>">Word</a>
              <a class="btn ghost xs" href="<?= e(base_url('admin/export?type=xlsx&id=' . $r['id'])) ?>">Excel</a>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<?php if ($pages > 1): ?>
  <div class="pager">
    <?php if ($page > 1): ?><a href="?<?= e($qs(['page' => $page - 1])) ?>">قبلی</a><?php endif; ?>
    <?php
    $start = max(1, $page - 3); $end = min($pages, $page + 3);
    if ($start > 1) echo '<a href="?' . e($qs(['page' => 1])) . '">۱</a><span>…</span>';
    for ($p = $start; $p <= $end; $p++) {
        echo $p === $page
            ? '<span class="cur">' . e(fa_num($p)) . '</span>'
            : '<a href="?' . e($qs(['page' => $p])) . '">' . e(fa_num($p)) . '</a>';
    }
    if ($end < $pages) echo '<span>…</span><a href="?' . e($qs(['page' => $pages])) . '">' . e(fa_num($pages)) . '</a>';
    ?>
    <?php if ($page < $pages): ?><a href="?<?= e($qs(['page' => $page + 1])) ?>">بعدی</a><?php endif; ?>
  </div>
<?php endif; ?>

<?php require __DIR__ . '/_admin_bottom.php'; ?>
