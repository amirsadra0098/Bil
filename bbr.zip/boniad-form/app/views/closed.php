<?php $pageTitle = 'فرم غیرفعال'; require __DIR__ . '/_top.php'; ?>
<div class="wrap wrap-narrow">
  <div class="card receipt">
    <div class="tick" style="background:var(--warn-bg);color:var(--warn)">!</div>
    <h2 style="color:var(--navy-800)">در حال حاضر امکان ثبت فرم وجود ندارد</h2>
    <p class="muted">فرم توسط مدیر سامانه موقتاً غیرفعال شده است. لطفاً بعداً مراجعه کنید.</p>
    <div class="btn-row" style="justify-content:center;margin-top:18px">
      <a class="btn ghost" href="<?= e(base_url('track')) ?>">پیگیری وضعیت</a>
    </div>
  </div>
</div>
<?php require __DIR__ . '/_bottom.php'; ?>
