<?php
$org   = app_setting('org_title', cfg('org_title', 'بنیاد مسکن انقلاب اسلامی'));
$stit  = app_setting('sub_title', cfg('sub_title', 'مدیریت حراست'));
$ftit  = app_setting('form_title', cfg('form_title', 'فرم اطلاعات فردی'));
$title = $pageTitle ?? $ftit;
?><!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="robots" content="noindex, nofollow">
<title><?= e($title . ' | ' . $org) ?></title>
<link rel="stylesheet" href="<?= e(base_url('assets/css/app.css')) ?>">
<link rel="icon" type="image/png" href="<?= e(base_url('assets/img/favicon.png')) ?>">
</head>
<body>

<header class="topbar">
  <div class="topbar-in">
    <?= logo_img('brand-logo') ?>
    <div class="brand">
      <h1><?= e($org) ?></h1>
      <span><?= e($stit . ' — ' . $ftit) ?></span>
    </div>
    <div class="spacer"></div>
    <nav class="topbar-links">
      <a href="<?= e(base_url('')) ?>">تکمیل فرم</a>
      <a href="<?= e(base_url('track')) ?>">پیگیری وضعیت</a>
      <a href="<?= e(base_url('admin')) ?>">ورود کارکنان</a>
    </nav>
  </div>
</header>
