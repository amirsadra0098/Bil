</div>
<div class="wrap" style="padding-top:0"><?= credit_html() ?></div>
<script src="<?= e(base_url('assets/js/jalali.js')) ?>"></script>
<script>
document.querySelectorAll('.date-input').forEach(function(el){ if(window.attachDatePicker) attachDatePicker(el); });
document.addEventListener('submit', function(e){
  var f = e.target;
  if (f.dataset && f.dataset.confirm && !window.confirm(f.dataset.confirm)) e.preventDefault();
});

/* ---------------- دکمه چشم روی همه‌ی فیلدهای رمز عبور ---------------- */
(function () {
  var SVG = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor"'
          + ' stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
          + '<path d="M1.6 12S5.5 5 12 5s10.4 7 10.4 7-3.9 7-10.4 7S1.6 12 1.6 12Z"/>'
          + '<circle cx="12" cy="12" r="3.2"/>'
          + '<path class="eye-off" d="M3 3l18 18" style="display:none"/></svg>';

  function enhance(inp) {
    if (inp.dataset.pwReady) return;
    inp.dataset.pwReady = '1';

    var wrap = document.createElement('div');
    wrap.className = 'pw-wrap';
    inp.parentNode.insertBefore(wrap, inp);
    wrap.appendChild(inp);

    var small = inp.offsetHeight > 0 && inp.offsetHeight < 34;
    if (small) wrap.classList.add('sm');
    inp.style.paddingRight = (small ? 27 : 42) + 'px';

    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'pw-eye';
    btn.innerHTML = SVG;
    btn.setAttribute('aria-pressed', 'false');
    btn.setAttribute('aria-label', 'نمایش رمز عبور');
    btn.title = 'نمایش رمز عبور';
    wrap.appendChild(btn);

    btn.addEventListener('click', function () {
      var show = inp.type === 'password';
      inp.type = show ? 'text' : 'password';
      btn.setAttribute('aria-pressed', show ? 'true' : 'false');
      btn.setAttribute('aria-label', show ? 'پنهان کردن رمز عبور' : 'نمایش رمز عبور');
      btn.title = btn.getAttribute('aria-label');
      btn.classList.toggle('on', show);
      var off = btn.querySelector('.eye-off');
      if (off) off.style.display = show ? '' : 'none';
      inp.focus();
      try { var v = inp.value; inp.value = ''; inp.value = v; } catch (e) {}
    });

    // پس از ارسال فرم، رمز دوباره پنهان شود
    if (inp.form) {
      inp.form.addEventListener('submit', function () {
        inp.type = 'password';
        btn.classList.remove('on');
        btn.setAttribute('aria-pressed', 'false');
        var off = btn.querySelector('.eye-off');
        if (off) off.style.display = 'none';
      });
    }
  }

  document.querySelectorAll('input[type="password"]').forEach(enhance);
})();
</script>
</body>
</html>
