<?php $pageTitle = 'تنظیمات'; $adminPage = 'settings'; require __DIR__ . '/_admin_top.php'; ?>

<div class="page-head"><h1>تنظیمات</h1></div>

<?php if ($msg): ?>
  <div class="alert <?= $msg[0] === 'err' ? 'err' : 'ok' ?>"><b><?= $msg[0] === 'err' ? '⚠' : '✓' ?></b><div><?= e($msg[1]) ?></div></div>
<?php endif; ?>

<?php if (is_superadmin()): ?>
<div class="card">
  <div class="card-head"><h2>نشان (لوگو) سازمان</h2></div>
  <div style="display:flex;gap:18px;align-items:flex-start;flex-wrap:wrap">
    <?= logo_img('logo-preview', 'نشان فعلی') ?>
    <div style="flex:1;min-width:260px">
      <p class="muted" style="margin-top:0">
        <?= has_custom_logo() ? 'نشان بارگذاری‌شده توسط شما در حال استفاده است.' : 'در حال حاضر نشان پیش‌فرض برنامه استفاده می‌شود.' ?>
        این نشان در سربرگ فرم، صفحه ورود، رسید، صفحه چاپ و خروجی Word نمایش داده می‌شود.
      </p>
      <form method="post" action="<?= e(base_url('admin/settings')) ?>" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <input type="hidden" name="do" value="logo">
        <div class="grid">
          <div class="f w12">
            <label class="lbl" for="lg">فایل نشان</label>
            <input type="file" id="lg" name="logo" accept="image/png,image/jpeg,image/webp,image/gif" required>
            <span class="hint">PNG با پس‌زمینه شفاف بهترین نتیجه را می‌دهد. حداکثر ۲ مگابایت.</span>
          </div>
        </div>
        <div class="btn-row" style="margin-top:12px">
          <button class="btn" type="submit">بارگذاری نشان</button>
        </div>
      </form>
      <?php if (has_custom_logo()): ?>
        <form method="post" action="<?= e(base_url('admin/settings')) ?>" style="margin-top:10px"
              data-confirm="نشان بارگذاری‌شده حذف شود و نشان پیش‌فرض برگردد؟">
          <?= csrf_field() ?>
          <input type="hidden" name="do" value="logo">
          <input type="hidden" name="remove" value="1">
          <button class="btn danger sm" type="submit">حذف نشان و بازگشت به پیش‌فرض</button>
        </form>
      <?php endif; ?>
    </div>
  </div>
</div>

<div class="card">
  <div class="card-head"><h2>تنظیمات عمومی سامانه</h2></div>
  <form method="post" action="<?= e(base_url('admin/settings')) ?>">
    <?= csrf_field() ?>
    <input type="hidden" name="do" value="general">
    <div class="grid">
      <div class="f w6">
        <label class="lbl" for="ot">نام سازمان</label>
        <input type="text" id="ot" name="org_title" value="<?= e(app_setting('org_title', '')) ?>">
      </div>
      <div class="f w3">
        <label class="lbl" for="st2">نام واحد</label>
        <input type="text" id="st2" name="sub_title" value="<?= e(app_setting('sub_title', '')) ?>">
      </div>
      <div class="f w3">
        <label class="lbl" for="ft">عنوان فرم</label>
        <input type="text" id="ft" name="form_title" value="<?= e(app_setting('form_title', '')) ?>">
      </div>
      <div class="f w12">
        <label class="lbl" for="it">متن راهنمای بالای فرم</label>
        <textarea id="it" name="intro_text" rows="2"><?= e(app_setting('intro_text', '')) ?></textarea>
      </div>
      <div class="f w12">
        <div class="opts">
          <label class="opt<?= app_setting('form_open', '1') === '1' ? ' sel' : '' ?>">
            <input type="checkbox" name="form_open" value="1"<?= app_setting('form_open', '1') === '1' ? ' checked' : '' ?>>
            <span>فرم برای عموم باز باشد</span>
          </label>
        </div>
        <span class="hint">در صورت غیرفعال کردن، کاربران پیام «امکان ثبت وجود ندارد» می‌بینند.</span>
      </div>
    </div>
    <div class="btn-row" style="margin-top:14px"><button class="btn" type="submit">ذخیره تنظیمات</button></div>
  </form>
</div>
<?php endif; ?>

<div class="card">
  <div class="card-head"><h2>تغییر رمز عبور من</h2></div>
  <form method="post" action="<?= e(base_url('admin/settings')) ?>">
    <?= csrf_field() ?>
    <input type="hidden" name="do" value="password">
    <div class="grid">
      <div class="f w4">
        <label class="lbl" for="c1">رمز عبور فعلی</label>
        <input type="password" id="c1" name="current" required autocomplete="current-password" style="direction:ltr">
      </div>
      <div class="f w4">
        <label class="lbl" for="c2">رمز عبور جدید</label>
        <input type="password" id="c2" name="new" required autocomplete="new-password" style="direction:ltr">
        <span class="hint">حداقل ۸ نویسه، شامل حروف و عدد.</span>
      </div>
      <div class="f w4">
        <label class="lbl" for="c3">تکرار رمز جدید</label>
        <input type="password" id="c3" name="repeat" required autocomplete="new-password" style="direction:ltr">
      </div>
    </div>
    <div class="btn-row" style="margin-top:14px"><button class="btn" type="submit">تغییر رمز عبور</button></div>
  </form>
</div>

<div class="card">
  <div class="card-head"><h2>اطلاعات سامانه</h2></div>
  <div class="kv">
    <div><b>پایگاه داده</b><span style="direction:ltr;text-align:right"><?= e(db_driver()) ?></span></div>
    <div><b>نسخه PHP</b><span style="direction:ltr;text-align:right"><?= e(PHP_VERSION) ?></span></div>
    <div><b>تاریخ امروز</b><span><?= e(jdate_long(date('Y-m-d'))) ?></span></div>
    <div><b>محدودیت ثبت در ساعت</b><span><?= e(fa_num((int)cfg('rate_limit_per_hour', 8))) ?> فرم از هر IP</span></div>
  </div>
</div>

<?php require __DIR__ . '/_admin_bottom.php'; ?>
