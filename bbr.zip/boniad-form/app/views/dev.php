<?php $org = app_setting('org_title', cfg('org_title', '')); ?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow, noarchive">
<title>پنل سازنده</title>
<link rel="stylesheet" href="<?= e(base_url('assets/css/app.css')) ?>">
<link rel="icon" type="image/png" href="<?= e(base_url('assets/img/favicon.png')) ?>">
</head>
<body class="login-page">

<?php if (!$loggedIn): ?>

  <form class="login-box" method="post" action="<?= e(base_url(dev_path())) ?>" autocomplete="off">
    <?= csrf_field() ?>
    <div class="emblem">🦏</div>
    <h1>پنل سازنده</h1>
    <p class="sub">rhino-team.ir</p>

    <?php if ($err): ?><div class="alert err"><b>⚠</b><div><?= e($err) ?></div></div><?php endif; ?>

    <?php if ($needsSetup): ?>
      <div class="alert info"><b>i</b><div>هنوز رمزی تنظیم نشده است. یک رمز برای خودتان بسازید.</div></div>
      <input type="hidden" name="do" value="setup">
      <div style="margin-bottom:13px">
        <label class="lbl" for="p1">رمز جدید</label>
        <input type="password" id="p1" name="p1" required minlength="8" autofocus style="direction:ltr">
      </div>
      <div style="margin-bottom:18px">
        <label class="lbl" for="p2">تکرار رمز</label>
        <input type="password" id="p2" name="p2" required minlength="8" style="direction:ltr">
      </div>
      <button class="btn" type="submit" style="width:100%">ثبت رمز</button>

    <?php else: ?>
      <input type="hidden" name="do" value="login">
      <div style="margin-bottom:13px">
        <label class="lbl" for="p">رمز</label>
        <input type="password" id="p" name="password" required autofocus style="direction:ltr">
      </div>
      <div style="margin-bottom:18px">
        <label class="lbl" for="cap">کد اعتبارسنجی</label>
        <div class="cap-row">
          <img id="capImg" class="cap-img" src="<?= e(base_url('admin/captcha?t=' . time())) ?>"
               alt="کد اعتبارسنجی" width="190" height="62">
          <button type="button" class="cap-reload" id="capReload" title="کد جدید">⟳</button>
          <input type="text" id="cap" name="captcha" required maxlength="8" autocomplete="off"
                 spellcheck="false" placeholder="کد تصویر"
                 style="direction:ltr;text-align:center;text-transform:uppercase;letter-spacing:3px">
        </div>
      </div>
      <button class="btn" type="submit" style="width:100%">ورود</button>
    <?php endif; ?>
  </form>

  <script>
  (function () {
    var b = document.getElementById('capReload'), i = document.getElementById('capImg');
    if (b && i) b.addEventListener('click', function () {
      i.src = <?= json_encode(base_url('admin/captcha'), JSON_UNESCAPED_SLASHES) ?> + '?t=' + Date.now();
      document.getElementById('cap').value = '';
    });
  })();
  </script>

<?php else: ?>

  <div class="wrap wrap-narrow" style="padding-top:26px">
    <div class="card">
      <div class="card-head">
        <h2>پنل سازنده</h2>
        <div class="spacer"></div>
        <form method="post" action="<?= e(base_url(dev_path())) ?>" style="margin:0">
          <?= csrf_field() ?><input type="hidden" name="do" value="logout">
          <button class="btn ghost sm" type="submit">خروج</button>
        </form>
      </div>

      <?php if ($msg): ?><div class="alert ok"><b>✓</b><div><?= e($msg) ?></div></div><?php endif; ?>
      <?php if ($err): ?><div class="alert err"><b>⚠</b><div><?= e($err) ?></div></div><?php endif; ?>

      <div class="block">
        <header><h3>امضای سازنده در فوتر</h3><div class="spacer"></div></header>
        <div class="block-body">
          <p class="muted" style="margin-top:0">
            وضعیت فعلی:
            <b style="color:<?= $creditOn ? 'var(--ok)' : 'var(--err)' ?>">
              <?= $creditOn ? 'نمایش داده می‌شود' : 'مخفی است' ?>
            </b>
          </p>
          <form method="post" action="<?= e(base_url(dev_path())) ?>">
            <?= csrf_field() ?><input type="hidden" name="do" value="credit">
            <div class="opts" style="margin-bottom:14px">
              <label class="opt<?= $creditOn ? ' sel' : '' ?>">
                <input type="radio" name="on" value="1"<?= $creditOn ? ' checked' : '' ?>><span>نمایش بده</span>
              </label>
              <label class="opt<?= $creditOn ? '' : ' sel' ?>">
                <input type="radio" name="on" value=""<?= $creditOn ? '' : ' checked' ?>><span>مخفی کن</span>
              </label>
            </div>
            <button class="btn" type="submit">ذخیره</button>
          </form>
        </div>
      </div>

      <div class="block">
        <header><h3>تغییر رمز این پنل</h3><div class="spacer"></div></header>
        <div class="block-body">
          <form method="post" action="<?= e(base_url(dev_path())) ?>">
            <?= csrf_field() ?><input type="hidden" name="do" value="passwd">
            <div class="grid">
              <div class="f w6">
                <label class="lbl" for="n1">رمز جدید</label>
                <input type="password" id="n1" name="p1" required minlength="8" style="direction:ltr">
              </div>
              <div class="f w6">
                <label class="lbl" for="n2">تکرار رمز</label>
                <input type="password" id="n2" name="p2" required minlength="8" style="direction:ltr">
              </div>
            </div>
            <div class="btn-row" style="margin-top:12px"><button class="btn ghost" type="submit">تغییر رمز</button></div>
          </form>
        </div>
      </div>

      <p class="muted" style="margin:0">
        مسیر این صفحه: <code style="direction:ltr;display:inline-block"><?= e('/' . dev_path()) ?></code>
        — در هیچ صفحه‌ای لینک نشده است. برای تغییر آن مقدار <code>dev_path</code> را در
        <code style="direction:ltr;display:inline-block">app/config.php</code> عوض کنید.
      </p>
    </div>
  </div>

  <script src="<?= e(base_url('assets/js/app.js')) ?>"></script>

<?php endif; ?>

</body>
</html>
