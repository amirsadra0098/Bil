<?php $pageTitle = 'خطا'; require __DIR__ . '/_top.php'; ?>
<div class="wrap wrap-narrow">
  <div class="card receipt">
    <div class="tick" style="background:var(--err-bg);color:var(--err)"><?= e($code) ?></div>
    <h2 style="color:var(--navy-800)"><?= e($msg) ?></h2>
    <div class="btn-row" style="justify-content:center;margin-top:18px">
      <a class="btn ghost" href="<?= e(base_url('')) ?>">بازگشت به صفحه اصلی</a>
    </div>
  </div>
</div>
<?php require __DIR__ . '/_bottom.php'; ?>
