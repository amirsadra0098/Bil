<?php $pageTitle = 'گزارش رویدادها'; $adminPage = 'logs'; require __DIR__ . '/_admin_top.php'; ?>

<div class="page-head">
  <h1>گزارش رویدادها</h1>
  <span class="badge st-new"><?= e(fa_num($total)) ?> رویداد</span>
  <div class="spacer"></div>
</div>

<div class="card">
  <form method="get" action="<?= e(base_url('admin/logs')) ?>" class="filters">
    <div class="fx grow">
      <label class="lbl" for="ac">نوع رویداد</label>
      <select id="ac" name="action">
        <option value="">همه رویدادها</option>
        <?php foreach (LOG_LABELS as $k => $v): ?>
          <option value="<?= e($k) ?>"<?= $act === $k ? ' selected' : '' ?>><?= e($v) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="fx"><button class="btn" type="submit">اعمال</button></div>
    <?php if ($act !== ''): ?><div class="fx"><a class="btn ghost" href="<?= e(base_url('admin/logs')) ?>">حذف فیلتر</a></div><?php endif; ?>
  </form>
</div>

<div class="card" style="padding:0;overflow:hidden">
  <?php if (!$rows): ?>
    <div class="empty" style="margin:0;border-radius:0;padding:40px">رویدادی یافت نشد.</div>
  <?php else: ?>
    <div class="table-wrap" style="border:0">
      <table class="tbl" style="min-width:860px">
        <thead><tr>
          <th class="c" style="width:60px">#</th><th>کاربر</th><th>رویداد</th>
          <th>توضیحات</th><th>IP</th><th>مرورگر</th><th>زمان</th>
        </tr></thead>
        <tbody>
        <?php foreach ($rows as $l): ?>
          <tr>
            <td class="c muted"><?= e(fa_num($l['id'])) ?></td>
            <td class="nowrap"><?= e($l['actor'] ?: '—') ?></td>
            <td class="nowrap">
              <span class="badge <?= $l['action'] === 'login_failed' || $l['action'] === 'delete' ? 'st-no' : ($l['action'] === 'submit' ? 'st-ok' : 'st-new') ?>">
                <?= e(log_action_label($l['action'])) ?>
              </span>
            </td>
            <td><?= e($l['details'] ?: '—') ?><?php if ($l['entity'] === 'submission' && $l['entity_id']): ?>
              <a class="muted" href="<?= e(base_url('admin/view?id=' . (int)$l['entity_id'])) ?>">(مشاهده)</a><?php endif; ?></td>
            <td class="nowrap" style="direction:ltr;text-align:right"><?= e($l['ip']) ?></td>
            <td class="muted" style="max-width:200px;font-size:11px;direction:ltr;text-align:right"><?= e(str_limit($l['user_agent'], 46)) ?></td>
            <td class="nowrap"><?= e(jdate($l['created_at'], true)) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<?php if ($pages > 1): ?>
  <div class="pager">
    <?php for ($p = max(1, $page - 4); $p <= min($pages, $page + 4); $p++): ?>
      <?php if ($p === $page): ?><span class="cur"><?= e(fa_num($p)) ?></span>
      <?php else: ?><a href="?<?= e(http_build_query(['action' => $act, 'page' => $p])) ?>"><?= e(fa_num($p)) ?></a><?php endif; ?>
    <?php endfor; ?>
  </div>
<?php endif; ?>

<?php require __DIR__ . '/_admin_bottom.php'; ?>
