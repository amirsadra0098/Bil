<?php
$org  = app_setting('org_title', cfg('org_title', ''));
$stit = app_setting('sub_title', cfg('sub_title', ''));
$me   = current_admin();
$cur  = $adminPage ?? '';
$nav  = [
    'dashboard'   => ['داشبورد', 'admin'],
    'submissions' => ['فرم‌های ثبت‌شده', 'admin/submissions'],
    'logs'        => ['گزارش رویدادها', 'admin/logs'],
    'users'       => ['کاربران', 'admin/users'],
    'settings'    => ['تنظیمات', 'admin/settings'],
];
$fl = flash();
?><!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?= e(($pageTitle ?? 'پنل مدیریت') . ' | ' . $org) ?></title>
<link rel="stylesheet" href="<?= e(base_url('assets/css/app.css')) ?>">
<link rel="icon" type="image/png" href="<?= e(base_url('assets/img/favicon.png')) ?>">
</head>
<body>

<header class="topbar no-print">
  <div class="topbar-in">
    <?= logo_img('brand-logo') ?>
    <div class="brand">
      <h1>پنل مدیریت — <?= e($stit) ?></h1>
      <span><?= e($org) ?></span>
    </div>
    <div class="spacer"></div>
    <div class="topbar-links">
      <span style="color:#bcd2e6;font-size:13px;padding:6px 0"><?= e($me['display_name'] ?? '') ?><?= ($me['role'] ?? '') === 'super' ? ' (مدیر ارشد)' : '' ?></span>
      <a href="<?= e(base_url('')) ?>" target="_blank">مشاهده فرم</a>
      <a href="<?= e(base_url('admin/logout')) ?>">خروج</a>
    </div>
  </div>
</header>

<nav class="admin-nav no-print">
  <div class="admin-nav-in">
    <?php foreach ($nav as $k => $n): ?>
      <?php if ($k === 'users' && ($me['role'] ?? '') !== 'super') continue; ?>
      <a href="<?= e(base_url($n[1])) ?>" class="<?= $cur === $k ? 'active' : '' ?>"><?= e($n[0]) ?></a>
    <?php endforeach; ?>
  </div>
</nav>

<div class="wrap">
<?php if ($fl): ?>
  <div class="alert <?= $fl['type'] === 'err' ? 'err' : 'ok' ?>"><b><?= $fl['type'] === 'err' ? '⚠' : '✓' ?></b><div><?= e($fl['msg']) ?></div></div>
<?php endif; ?>
