<?php $org = app_setting('org_title', cfg('org_title', '')); ?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?= e('ورود به پنل مدیریت | ' . $org) ?></title>
<link rel="stylesheet" href="<?= e(base_url('assets/css/app.css')) ?>">
<link rel="icon" type="image/png" href="<?= e(base_url('assets/img/favicon.png')) ?>">
</head>
<body class="login-page">
  <form class="login-box" method="post" action="<?= e(base_url('admin/login')) ?>" autocomplete="off">
    <?= csrf_field() ?>
    <?= logo_img('login-logo') ?>
    <h1>ورود به پنل مدیریت</h1>
    <p class="sub"><?= e($org) ?> — <?= e(app_setting('sub_title', '')) ?></p>

    <?php if (!empty($expired)): ?>
      <div class="alert warn"><b>⏱</b><div>نشست شما منقضی شد. دوباره وارد شوید.</div></div>
    <?php endif; ?>
    <?php if (!empty($err)): ?>
      <div class="alert err"><b>⚠</b><div><?= e($err) ?></div></div>
    <?php endif; ?>

    <div style="margin-bottom:13px">
      <label class="lbl" for="u">نام کاربری</label>
      <input type="text" id="u" name="username" required autofocus autocomplete="username" style="direction:ltr">
    </div>
    <div style="margin-bottom:13px">
      <label class="lbl" for="p">رمز عبور</label>
      <div class="pw-wrap">
        <input type="password" id="p" name="password" required autocomplete="current-password"
               data-pw-ready="1" style="direction:ltr">
        <button type="button" class="pw-eye" id="pwEye" aria-pressed="false"
                aria-label="نمایش رمز عبور" title="نمایش رمز عبور">
          <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor"
               stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <path class="eye-open" d="M1.6 12S5.5 5 12 5s10.4 7 10.4 7-3.9 7-10.4 7S1.6 12 1.6 12Z"/>
            <circle class="eye-open" cx="12" cy="12" r="3.2"/>
            <path class="eye-off" d="M3 3l18 18" style="display:none"/>
          </svg>
        </button>
      </div>
    </div>

    <div style="margin-bottom:18px">
      <label class="lbl" for="cap">
        کد اعتبارسنجی
        <span class="cap-timer" id="capTimer" title="زمان باقی‌مانده تا نوسازی خودکار"></span>
      </label>
      <div class="cap-row">
        <img id="capImg" class="cap-img" src="<?= e(base_url('admin/captcha?t=' . time())) ?>"
             alt="کد اعتبارسنجی" width="190" height="62">
        <button type="button" class="cap-reload" id="capReload" title="دریافت کد جدید" aria-label="دریافت کد جدید">⟳</button>
        <input type="text" id="cap" name="captcha" required maxlength="8" inputmode="text" autocapitalize="characters"
               autocomplete="off" spellcheck="false" placeholder="کد تصویر"
               style="direction:ltr;text-align:center;text-transform:uppercase;letter-spacing:3px">
      </div>
      <span class="hint">کد هر ۲ دقیقه به‌صورت خودکار تغییر می‌کند. اگر خوانا نیست روی ⟳ بزنید.</span>
    </div>

    <button class="btn" type="submit" style="width:100%">ورود</button>
    <p class="muted" style="text-align:center;margin:16px 0 0">
      <a href="<?= e(base_url('')) ?>">بازگشت به فرم</a>
    </p>
  </form>

<script>
/* ------------------------------- نمایش / پنهان کردن رمز عبور */
(function () {
  var btn = document.getElementById('pwEye');
  var inp = document.getElementById('p');
  if (!btn || !inp) return;
  btn.addEventListener('click', function () {
    var show = inp.type === 'password';
    inp.type = show ? 'text' : 'password';
    btn.setAttribute('aria-pressed', show ? 'true' : 'false');
    btn.setAttribute('aria-label', show ? 'پنهان کردن رمز عبور' : 'نمایش رمز عبور');
    btn.title = show ? 'پنهان کردن رمز عبور' : 'نمایش رمز عبور';
    btn.classList.toggle('on', show);
    btn.querySelector('.eye-off').style.display = show ? '' : 'none';
    inp.focus();
    // مکان‌نما به انتهای متن برود
    try { var v = inp.value; inp.value = ''; inp.value = v; } catch (e) {}
  });
  // هنگام ارسال فرم، رمز دوباره پنهان شود
  inp.form.addEventListener('submit', function () { inp.type = 'password'; });
})();

(function () {
  var CYCLE = <?= (int)CAPTCHA_CYCLE ?>;          // ثانیه
  var img    = document.getElementById('capImg');
  var input  = document.getElementById('cap');
  var timer  = document.getElementById('capTimer');
  var reload = document.getElementById('capReload');
  var base   = <?= json_encode(base_url('admin/captcha'), JSON_UNESCAPED_SLASHES) ?>;
  var left   = CYCLE;

  function fa(n) { return String(n).replace(/[0-9]/g, function (c) { return '۰۱۲۳۴۵۶۷۸۹'[+c]; }); }

  function refresh(clearInput) {
    img.classList.add('loading');
    img.src = base + '?t=' + Date.now();
    left = CYCLE;
    if (clearInput) { input.value = ''; }
    tick();
  }
  img.addEventListener('load',  function () { img.classList.remove('loading'); });
  img.addEventListener('error', function () { img.classList.remove('loading'); });

  function tick() {
    var m = Math.floor(left / 60), s = left % 60;
    timer.textContent = fa(m) + ':' + fa(s < 10 ? '0' + s : s);
    timer.classList.toggle('soon', left <= 20);
  }

  setInterval(function () {
    left--;
    if (left <= 0) refresh(true);
    else tick();
  }, 1000);

  reload.addEventListener('click', function () { refresh(true); input.focus(); });

  // اگر کاربر مدتی از صفحه دور بوده، هنگام بازگشت کد تازه بگیرد
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden && left < CYCLE - 5) refresh(false);
  });

  tick();
})();
</script>
</body>
</html>
