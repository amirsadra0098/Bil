<?php
$pageTitle = 'مشاهده فرم'; $adminPage = 'submissions';
require __DIR__ . '/_admin_top.php';
?>

<div class="page-head">
  <a class="btn ghost sm" href="<?= e(base_url('admin/submissions')) ?>">→ بازگشت</a>
  <h1><?= e(sub_full_name($sub)) ?></h1>
  <span class="badge <?= e(status_class($sub['status'])) ?>"><?= e(status_label($sub['status'])) ?></span>
  <div class="spacer"></div>
  <div class="btn-row">
    <a class="btn gold sm" href="<?= e(base_url('admin/export?type=docx&id=' . $sub['id'])) ?>">⬇ خروجی Word</a>
    <a class="btn gold sm" href="<?= e(base_url('admin/export?type=xlsx&id=' . $sub['id'])) ?>">⬇ خروجی Excel</a>
    <a class="btn ghost sm" href="<?= e(base_url('admin/print?id=' . $sub['id'])) ?>" target="_blank">🖨 چاپ</a>
  </div>
</div>

<div class="card">
  <div class="kv">
    <div><b>کد رهگیری</b><span style="direction:ltr;text-align:right"><b><?= e($sub['tracking_code']) ?></b></span></div>
    <div><b>کد ملی</b><span><?= e(fa_num($sub['national_id']) ?: '—') ?></span></div>
    <div><b>تلفن همراه</b><span><?= e(fa_num($sub['mobile']) ?: '—') ?></span></div>
    <div><b>تاریخ ثبت</b><span><?= e(jdate($sub['created_at'], true)) ?> (<?= e(jdate_long($sub['created_at'])) ?>)</span></div>
    <div><b>آدرس IP</b><span style="direction:ltr;text-align:right"><?= e($sub['ip']) ?></span></div>
    <div><b>آخرین بررسی</b><span><?= $sub['reviewed_at'] ? e(jdate($sub['reviewed_at'], true) . ' — ' . $sub['reviewer_name']) : '<span class="muted">—</span>' ?></span></div>
  </div>
</div>

<div class="card no-print">
  <div class="card-head"><h2>بررسی و وضعیت</h2></div>
  <form method="post" action="<?= e(base_url('admin/status')) ?>">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= (int)$sub['id'] ?>">
    <div class="grid">
      <div class="f w3">
        <label class="lbl" for="stx">وضعیت</label>
        <select id="stx" name="status">
          <?php foreach (STATUS_LABELS as $k => $v): ?>
            <option value="<?= e($k) ?>"<?= $sub['status'] === $k ? ' selected' : '' ?>><?= e($v) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="f w6">
        <label class="lbl" for="nt">یادداشت کنترل‌کننده</label>
        <textarea id="nt" name="admin_note" rows="2"><?= e($sub['admin_note'] ?? '') ?></textarea>
      </div>
      <div class="f w3" style="display:flex;align-items:flex-end">
        <button class="btn" type="submit" style="width:100%">ذخیره وضعیت</button>
      </div>
    </div>
  </form>

  <?php if (is_superadmin()): ?>
    <form method="post" action="<?= e(base_url('admin/delete')) ?>" data-confirm="آیا از حذف قطعی این فرم مطمئن هستید؟ این عمل بازگشت‌پذیر نیست." style="margin-top:14px;border-top:1px solid var(--line-2);padding-top:14px">
      <?= csrf_field() ?>
      <input type="hidden" name="id" value="<?= (int)$sub['id'] ?>">
      <button class="btn danger sm" type="submit">حذف قطعی این فرم</button>
      <span class="muted">فقط مدیر ارشد. عملیات در گزارش رویدادها ثبت می‌شود.</span>
    </form>
  <?php endif; ?>
</div>

<div class="card">
  <div class="card-head"><h2>محتوای کامل فرم</h2></div>
  <?= render_ro_form($data) ?>
</div>

<?php require __DIR__ . '/_admin_bottom.php'; ?>
