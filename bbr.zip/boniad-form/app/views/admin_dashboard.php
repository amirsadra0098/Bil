<?php $pageTitle = 'داشبورد'; $adminPage = 'dashboard'; require __DIR__ . '/_admin_top.php'; ?>

<div class="page-head">
  <h1>داشبورد</h1>
  <div class="spacer"></div>
  <span class="muted">امروز: <?= e(jdate_long(date('Y-m-d'))) ?></span>
</div>

<div class="stats">
  <div class="stat"><div class="k">کل فرم‌های ثبت‌شده</div><div class="v"><?= e(fa_num($stats['total'])) ?></div></div>
  <div class="stat g"><div class="k">ثبت‌شده امروز</div><div class="v"><?= e(fa_num($stats['today'])) ?></div></div>
  <div class="stat w"><div class="k">۷ روز اخیر</div><div class="v"><?= e(fa_num($stats['week'])) ?></div></div>
  <div class="stat r"><div class="k">در انتظار بررسی</div><div class="v"><?= e(fa_num($stats['pending'])) ?></div></div>
</div>

<div class="card">
  <div class="card-head"><h2>روند ثبت فرم در ۱۴ روز گذشته</h2></div>
  <?php $max = max(1, max(array_column($chart, 'n'))); ?>
  <div class="chart">
    <?php foreach ($chart as $c): ?>
      <div class="bar" title="<?= e($c['label'] . ' — ' . fa_num($c['n']) . ' فرم') ?>">
        <b class="muted" style="font-size:10.5px"><?= $c['n'] ? e(fa_num($c['n'])) : '' ?></b>
        <i style="height:<?= (int)round($c['n'] / $max * 100) ?>%"></i>
        <span><?= e($c['short']) ?></span>
      </div>
    <?php endforeach; ?>
  </div>
</div>

<div class="card">
  <div class="card-head">
    <h2>آخرین فرم‌های ثبت‌شده</h2>
    <div class="spacer"></div>
    <a class="btn ghost sm" href="<?= e(base_url('admin/submissions')) ?>">مشاهده همه</a>
  </div>
  <?php if (!$latest): ?>
    <div class="empty">هنوز فرمی ثبت نشده است.</div>
  <?php else: ?>
    <div class="table-wrap">
      <table class="tbl">
        <thead><tr>
          <th>کد رهگیری</th><th>نام و نام خانوادگی</th><th>کد ملی</th>
          <th>محل خدمت</th><th>وضعیت</th><th>تاریخ ثبت</th><th></th>
        </tr></thead>
        <tbody>
        <?php foreach ($latest as $r): ?>
          <tr>
            <td class="nowrap" style="direction:ltr;text-align:right"><?= e($r['tracking_code']) ?></td>
            <td><?= e(trim($r['first_name'] . ' ' . $r['last_name']) ?: '—') ?></td>
            <td class="nowrap"><?= e(fa_num($r['national_id'])) ?></td>
            <td><?= e(str_limit($r['org_name'], 34) ?: '—') ?></td>
            <td><span class="badge <?= e(status_class($r['status'])) ?>"><?= e(status_label($r['status'])) ?></span></td>
            <td class="nowrap"><?= e(jdate($r['created_at'], true)) ?></td>
            <td class="c"><a class="btn ghost xs" href="<?= e(base_url('admin/view?id=' . $r['id'])) ?>">مشاهده</a></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<div class="card">
  <div class="card-head">
    <h2>آخرین رویدادها</h2>
    <div class="spacer"></div>
    <a class="btn ghost sm" href="<?= e(base_url('admin/logs')) ?>">گزارش کامل</a>
  </div>
  <?php if (!$logs): ?>
    <div class="empty">رویدادی ثبت نشده است.</div>
  <?php else: ?>
    <div class="table-wrap">
      <table class="tbl" style="min-width:560px">
        <thead><tr><th>کاربر</th><th>رویداد</th><th>توضیح</th><th>IP</th><th>زمان</th></tr></thead>
        <tbody>
        <?php foreach ($logs as $l): ?>
          <tr>
            <td class="nowrap"><?= e($l['actor']) ?></td>
            <td class="nowrap"><?= e(log_action_label($l['action'])) ?></td>
            <td><?= e(str_limit($l['details'], 60)) ?></td>
            <td class="nowrap" style="direction:ltr;text-align:right"><?= e($l['ip']) ?></td>
            <td class="nowrap"><?= e(jdate($l['created_at'], true)) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/_admin_bottom.php'; ?>
