<?php $org = app_setting('org_title', cfg('org_title', '')); ?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e(sub_full_name($sub) . ' - ' . $sub['tracking_code']) ?></title>
<link rel="stylesheet" href="<?= e(base_url('assets/css/app.css')) ?>">
<style>
  @page { size: A4; margin: 12mm 10mm; }
  body { background: #fff; }
  .sheet { max-width: 900px; margin: 0 auto; padding: 18px; }
  .ph { display:flex; align-items:center; gap:14px; border-bottom:2px solid var(--navy-700); padding-bottom:10px; margin-bottom:14px; }
  .ph h1 { font-size:16px; margin:0; color:var(--navy-800); }
  .ph .meta { margin-inline-start:auto; text-align:left; font-size:11.5px; color:var(--ink-2); line-height:1.9; }
</style>
</head>
<body>
<div class="sheet">
  <div class="btn-row no-print" style="margin-bottom:14px">
    <button class="btn" onclick="window.print()">🖨 چاپ</button>
    <a class="btn ghost" href="<?= e(base_url('admin/view?id=' . $sub['id'])) ?>">بازگشت</a>
  </div>

  <div class="ph">
    <?= logo_img('print-logo') ?>
    <div>
      <h1><?= e($org) ?></h1>
      <div class="muted"><?= e(app_setting('sub_title', '')) ?> — <?= e(app_setting('form_title', '')) ?></div>
    </div>
    <div class="meta">
      کد رهگیری: <b style="direction:ltr;display:inline-block"><?= e($sub['tracking_code']) ?></b><br>
      تاریخ ثبت: <?= e(jdate($sub['created_at'], true)) ?><br>
      وضعیت: <?= e(status_label($sub['status'])) ?>
    </div>
  </div>

  <?= render_ro_form($data) ?>

  <div style="margin-top:26px;display:flex;gap:30px;font-size:12px">
    <div style="flex:1;border-top:1px solid var(--line);padding-top:8px">
      نام و نام خانوادگی تکمیل‌کننده: <?= e($data['pledge']['filler_name'] ?? '') ?><br>
      تاریخ: <?= e(fa_num($data['pledge']['filler_date'] ?? '')) ?><br>امضا:
    </div>
    <div style="flex:1;border-top:1px solid var(--line);padding-top:8px">
      نام و نام خانوادگی کنترل‌کننده: <?= e($sub['reviewer_name'] ?? '') ?><br>
      تاریخ: <?= e($sub['reviewed_at'] ? jdate($sub['reviewed_at']) : '') ?><br>امضا:
    </div>
  </div>

  <?php if (!empty($sub['admin_note'])): ?>
    <div class="sub-title" style="margin-top:18px">یادداشت کنترل‌کننده</div>
    <p style="font-size:12px"><?= nl2br(e($sub['admin_note'])) ?></p>
  <?php endif; ?>
</div>
<script>window.addEventListener('load', function(){ if (location.search.indexOf('auto=1') > -1) window.print(); });</script>
</body>
</html>
