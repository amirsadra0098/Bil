<?php $pageTitle = 'تکمیل فرم'; require __DIR__ . '/_top.php'; ?>

<div class="wrap">

  <?php if (!empty($errors['_'])): ?>
    <div class="alert err"><b>⚠</b><div><?= e($errors['_']) ?></div></div>
  <?php elseif ($errors): ?>
    <div class="alert err"><b>⚠</b><div>لطفاً خطاهای مشخص‌شده را اصلاح کنید.</div></div>
  <?php endif; ?>

  <div id="draftBar" class="alert warn" hidden>
    <b>💾</b>
    <div style="flex:1">
      یک پیش‌نویس ذخیره‌شده از این فرم وجود دارد (<span class="when"></span>).
      <div class="btn-row" style="margin-top:8px">
        <button type="button" class="btn sm restore">بازیابی پیش‌نویس</button>
        <button type="button" class="btn ghost sm discard">شروع از نو</button>
      </div>
    </div>
  </div>

  <div class="card" style="padding:16px 20px">
    <div class="card-head" style="margin:0;border:0;padding:0">
      <h2>راهنمای تکمیل</h2>
      <div class="spacer"></div>
      <span class="muted" id="autosave"></span>
    </div>
    <p class="muted" style="margin:6px 0 0">
      <?= e(app_setting('intro_text', 'لطفاً کلیه بخش‌ها را با دقت و بر اساس مدارک رسمی تکمیل نمایید.')) ?>
      اطلاعات شما به‌صورت خودکار در همین مرورگر ذخیره می‌شود و در صورت بسته شدن صفحه قابل بازیابی است.
      فیلدهای دارای <span style="color:var(--err)">*</span> الزامی هستند.
    </p>
  </div>

  <div class="stepper-wrap">
    <div class="progress-line"><i style="width:0"></i></div>
    <div class="stepper">
      <?php foreach ($steps as $i => $s): ?>
        <button type="button" class="step-chip<?= $i === 0 ? ' active' : '' ?>">
          <span class="n"><?= e($s['num']) ?></span><b><?= e($s['title']) ?></b>
        </button>
      <?php endforeach; ?>
    </div>
  </div>

  <form id="mainForm" method="post" action="<?= e(base_url('submit')) ?>" autocomplete="off" novalidate>
    <?= csrf_field() ?>
    <div class="hp" aria-hidden="true">
      <label>وب‌سایت<input type="text" name="website" tabindex="-1" autocomplete="off"></label>
    </div>

    <?php foreach ($steps as $i => $s): ?>
      <section class="step card" data-step="<?= $i ?>"<?= $i === 0 ? '' : ' hidden' ?>>
        <div class="card-head">
          <h2><?= e($s['num'] . ') ' . $s['title']) ?></h2>
          <div class="spacer"></div>
          <span class="muted"><?= e($s['desc'] ?? '') ?></span>
        </div>
        <?php foreach ($s['blocks'] as $b) echo render_block($b, $old, $errors); ?>

        <?php if ($s['id'] === 'pledge'): ?>
          <div class="alert info" style="margin-top:4px">
            <b>📌</b>
            <div>
              اینجانب <b id="pledgeName">..................</b> متعهد می‌شوم هرگونه تغییر در اطلاعات مندرج در فرم را
              در اسرع وقت به آگاهی حراست برسانم و صحت تمامی اطلاعات فوق را تأیید می‌نمایم.
            </div>
          </div>
        <?php endif; ?>
      </section>
    <?php endforeach; ?>

    <div class="form-nav">
      <button type="button" class="btn ghost" id="btnPrev">→ مرحله قبل</button>
      <span class="muted" id="stepCounter"></span>
      <div class="spacer"></div>
      <button type="button" class="btn" id="btnNext">مرحله بعد ←</button>
      <button type="submit" class="btn ok" id="btnSend" hidden>ثبت نهایی فرم ✓</button>
    </div>
  </form>
</div>

<script src="<?= e(base_url('assets/js/jalali.js')) ?>"></script>
<script src="<?= e(base_url('assets/js/app.js')) ?>"></script>
<?php require __DIR__ . '/_bottom.php'; ?>
