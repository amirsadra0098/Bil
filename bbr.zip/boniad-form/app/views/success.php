<?php $pageTitle = 'ثبت موفق'; require __DIR__ . '/_top.php'; ?>
<div class="wrap wrap-narrow">
  <div class="card receipt">
    <?= logo_img('login-logo') ?>
    <div class="tick">✓</div>
    <h2 style="color:var(--navy-800)">فرم شما با موفقیت ثبت شد</h2>
    <p class="muted">کد رهگیری زیر را نزد خود نگه دارید؛ برای پیگیری وضعیت به آن نیاز دارید.</p>

    <div class="code-box"><?= e($s['code']) ?></div>

    <div class="kv" style="margin-top:18px;text-align:right">
      <div><b>نام و نام خانوادگی</b><span><?= e($s['name'] ?: '—') ?></span></div>
      <div><b>تاریخ ثبت</b><span><?= e($s['date']) ?></span></div>
    </div>

    <div class="btn-row no-print" style="justify-content:center;margin-top:22px">
      <button class="btn" onclick="window.print()">چاپ رسید</button>
      <a class="btn ghost" href="<?= e(base_url('track')) ?>">پیگیری وضعیت</a>
      <a class="btn ghost" href="<?= e(base_url('')) ?>">فرم جدید</a>
    </div>
  </div>
</div>
<?php require __DIR__ . '/_bottom.php'; ?>
