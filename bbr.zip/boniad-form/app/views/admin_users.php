<?php $pageTitle = 'کاربران'; $adminPage = 'users'; require __DIR__ . '/_admin_top.php'; ?>

<div class="page-head"><h1>کاربران پنل</h1></div>

<?php if ($msg): ?>
  <div class="alert <?= $msg[0] === 'err' ? 'err' : 'ok' ?>"><b><?= $msg[0] === 'err' ? '⚠' : '✓' ?></b><div><?= e($msg[1]) ?></div></div>
<?php endif; ?>

<div class="card">
  <div class="card-head"><h2>افزودن کاربر جدید</h2></div>
  <form method="post" action="<?= e(base_url('admin/users')) ?>">
    <?= csrf_field() ?>
    <input type="hidden" name="do" value="add">
    <div class="grid">
      <div class="f w3">
        <label class="lbl" for="un">نام کاربری</label>
        <input type="text" id="un" name="username" required style="direction:ltr" placeholder="hesari.karbar">
      </div>
      <div class="f w3">
        <label class="lbl" for="dn">نام نمایشی</label>
        <input type="text" id="dn" name="display_name" placeholder="مثلاً: کارشناس حراست">
      </div>
      <div class="f w3">
        <label class="lbl" for="pw">رمز عبور</label>
        <input type="password" id="pw" name="password" required style="direction:ltr">
        <span class="hint">حداقل ۸ نویسه شامل حروف و عدد.</span>
      </div>
      <div class="f w3">
        <label class="lbl" for="rl">نقش</label>
        <select id="rl" name="role">
          <option value="operator">کارشناس (بدون حذف)</option>
          <option value="super">مدیر ارشد</option>
        </select>
      </div>
    </div>
    <div class="btn-row" style="margin-top:14px"><button class="btn" type="submit">افزودن کاربر</button></div>
  </form>
</div>

<div class="card" style="padding:0;overflow:hidden">
  <div class="table-wrap" style="border:0">
    <table class="tbl" style="min-width:820px">
      <thead><tr>
        <th class="c" style="width:50px">#</th><th>نام کاربری</th><th>نام نمایشی</th>
        <th>نقش</th><th>وضعیت</th><th>آخرین ورود</th><th style="width:300px">عملیات</th>
      </tr></thead>
      <tbody>
      <?php foreach ($users as $u): ?>
        <tr>
          <td class="c muted"><?= e(fa_num($u['id'])) ?></td>
          <td class="nowrap" style="direction:ltr;text-align:right"><b><?= e($u['username']) ?></b></td>
          <td><?= e($u['display_name']) ?></td>
          <td><span class="badge <?= $u['role'] === 'super' ? 'st-warn' : 'st-new' ?>"><?= $u['role'] === 'super' ? 'مدیر ارشد' : 'کارشناس' ?></span></td>
          <td><span class="badge <?= (int)$u['is_active'] === 1 ? 'st-ok' : 'st-no' ?>"><?= (int)$u['is_active'] === 1 ? 'فعال' : 'غیرفعال' ?></span></td>
          <td class="nowrap"><?= $u['last_login_at'] ? e(jdate($u['last_login_at'], true)) : '<span class="muted">—</span>' ?></td>
          <td>
            <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
              <?php if ((int)$u['id'] !== (int)current_admin()['id']): ?>
                <form method="post" action="<?= e(base_url('admin/users')) ?>" data-confirm="وضعیت این کاربر تغییر کند؟">
                  <?= csrf_field() ?>
                  <input type="hidden" name="do" value="toggle"><input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
                  <button class="btn ghost xs" type="submit"><?= (int)$u['is_active'] === 1 ? 'غیرفعال کردن' : 'فعال کردن' ?></button>
                </form>
              <?php endif; ?>
              <form method="post" action="<?= e(base_url('admin/users')) ?>" style="display:flex;gap:5px" data-confirm="رمز عبور این کاربر بازنشانی شود؟">
                <?= csrf_field() ?>
                <input type="hidden" name="do" value="reset"><input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
                <input type="password" name="password" placeholder="رمز جدید" required style="min-height:28px;padding:3px 8px;font-size:12px;width:120px;direction:ltr">
                <button class="btn ghost xs" type="submit">بازنشانی</button>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require __DIR__ . '/_admin_bottom.php'; ?>
