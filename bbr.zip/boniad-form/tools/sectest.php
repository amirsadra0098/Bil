<?php
/**
 * آزمون امنیتی خودکار — به سامانه‌ی در حال اجرا حمله می‌کند و نتیجه را گزارش می‌دهد.
 *
 * اجرا:
 *   php tools/sectest.php http://127.0.0.1:8099 admin Test1234
 */

if (PHP_SAPI !== 'cli') exit('CLI only');

require __DIR__ . '/../app/bootstrap.php';

$BASE  = rtrim($argv[1] ?? 'http://127.0.0.1:8099', '/');
$USER  = $argv[2] ?? 'admin';
$PASS  = $argv[3] ?? 'Test1234';
$JAR   = sys_get_temp_dir() . '/sectest_' . getmypid() . '.jar';
@unlink($JAR);

$pass = 0; $fail = 0; $warn = 0;
function ok_($m)   { global $pass; $pass++; echo "  ✔ $m\n"; }
function bad_($m)  { global $fail; $fail++; echo "  ✘ $m\n"; }
function warn_($m) { global $warn; $warn++; echo "  ! $m\n"; }
function head($t)  { echo "\n[$t]\n"; }

/* ------------------------------------------------------------ HTTP ساده */

function http(string $url, array $opt = []): array
{
    global $JAR;
    $jar = $opt['jar'] ?? $JAR;
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HEADER         => true,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_COOKIEJAR      => $jar,
        CURLOPT_COOKIEFILE     => $jar,
        CURLOPT_TIMEOUT        => 25,
        CURLOPT_ENCODING       => '',
    ]);
    if (isset($opt['post'])) {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS,
            is_array($opt['post']) ? http_build_query($opt['post']) : $opt['post']);
    }
    if (!empty($opt['method'])) curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $opt['method']);
    if (!empty($opt['headers'])) curl_setopt($ch, CURLOPT_HTTPHEADER, $opt['headers']);

    $raw  = curl_exec($ch);
    $info = curl_getinfo($ch);
    $err  = curl_error($ch);
    curl_close($ch);
    if ($raw === false) return ['code' => 0, 'head' => '', 'body' => '', 'err' => $err, 'loc' => ''];

    $hs   = substr($raw, 0, $info['header_size']);
    $body = substr($raw, $info['header_size']);
    preg_match('/^location:\s*(.+)$/mi', $hs, $m);
    return ['code' => $info['http_code'], 'head' => $hs, 'body' => $body,
            'err' => $err, 'loc' => trim($m[1] ?? ''), 'type' => $info['content_type'] ?? ''];
}

function csrf_of(string $html): string
{
    return preg_match('/name="_csrf" value="([a-f0-9]+)"/', $html, $m) ? $m[1] : '';
}

/** نشانه‌های نشت خطای پایگاه داده */
const DB_ERR_SIGNS = [
    'SQLSTATE', 'SQL syntax', 'syntax error', 'PDOException', 'Warning:', 'Fatal error',
    'unrecognized token', 'no such column', 'Unknown column', 'near "', 'ORA-', 'pg_query',
    'You have an error in your', 'Call to a member function', 'Stack trace', '/var/www/', 'D:\\\\',
];
function leaks(string $body): ?string
{
    foreach (DB_ERR_SIGNS as $s) if (stripos($body, $s) !== false) return $s;
    return null;
}

/* ---------------------------------------------------- محموله‌های حمله */

$SQLI = [
    "' OR '1'='1",
    "' OR 1=1 --",
    "admin'--",
    "\" OR \"\"=\"",
    "1' UNION SELECT 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19 --",
    "'; DROP TABLE submissions; --",
    "'; DELETE FROM submissions; --",
    "' OR (SELECT COUNT(*) FROM admins) > 0 --",
    "1 AND (SELECT 1 FROM (SELECT SLEEP(3))a) --",
    "' AND 1=CAST((SELECT password_hash FROM admins LIMIT 1) AS INT) --",
    "%' OR '%'='",
    "\\' OR 1=1 --",
    "1;SELECT PG_SLEEP(3)--",
    "' || (SELECT username FROM admins LIMIT 1) || '",
    "0x27204f5220313d31",
    "' AND EXTRACTVALUE(1,CONCAT(0x5c,(SELECT username FROM admins LIMIT 1))) --",
];

$XSS = [
    '<script>window.__x=1</script>',
    '"><script>alert(1)</script>',
    "'><img src=x onerror=alert(1)>",
    'javascript:alert(1)',
    '<svg/onload=alert(1)>',
    '</textarea><script>alert(1)</script>',
    '"onmouseover="alert(1)',
    '<iframe src=javascript:alert(1)>',
];

$TRAVERSAL = [
    '../../../../etc/passwd',
    '....//....//etc/passwd',
    '/etc/passwd',
    'php://filter/convert.base64-encode/resource=../app/config.php',
    '..%2f..%2f..%2fetc%2fpasswd',
    'C:\\Windows\\win.ini',
];

echo "\n══════════════════════════════════════════════════════════\n";
echo "  آزمون امنیتی سامانه — $BASE\n";
echo "══════════════════════════════════════════════════════════\n";

/* ================================================== ۰) وضعیت اولیه */
$before = [
    'subs'   => (int)db()->query('SELECT COUNT(*) FROM submissions')->fetchColumn(),
    'admins' => (int)db()->query('SELECT COUNT(*) FROM admins')->fetchColumn(),
    'logs'   => (int)db()->query('SELECT COUNT(*) FROM audit_logs')->fetchColumn(),
];
echo "\nوضعیت اولیه: {$before['subs']} فرم، {$before['admins']} کاربر\n";

/* ================================================== ۱) ورود بدون احراز هویت */
head('کنترل دسترسی — مسیرهای مدیریتی بدون ورود');
$protected = ['admin', 'admin/submissions', 'admin/view?id=1', 'admin/print?id=1',
              'admin/export?id=1&type=docx', 'admin/export-list', 'admin/logs',
              'admin/settings', 'admin/users'];
foreach ($protected as $r) {
    $res = http("$BASE/$r");
    if ($res['code'] === 302 && str_contains($res['loc'], 'admin/login')) {
        ok_("مسیر /$r بدون ورود مسدود است");
    } else {
        bad_("مسیر /$r بدون ورود پاسخ " . $res['code'] . " داد!");
    }
}
foreach (['admin/status', 'admin/delete'] as $r) {
    $res = http("$BASE/$r", ['post' => ['id' => 1]]);
    if ($res['code'] === 302 && str_contains($res['loc'], 'admin/login')) ok_("POST /$r بدون ورود مسدود است");
    else bad_("POST /$r بدون ورود پاسخ " . $res['code'] . " داد!");
}

/* ================================================== ۲) کپچا و ورود */
head('صفحه ورود — کپچا و محافظت از رمز');
$login = http("$BASE/admin/login");
$csrf  = csrf_of($login['body']);
$csrf ? ok_('توکن CSRF در فرم ورود وجود دارد') : bad_('توکن CSRF در فرم ورود نیست');

$r = http("$BASE/admin/login", ['post' => ['_csrf' => $csrf, 'username' => $USER, 'password' => $PASS]]);
str_contains($r['body'], 'کد اعتبارسنجی') && $r['code'] === 200
    ? ok_('ورود بدون کد اعتبارسنجی رد شد')
    : bad_('ورود بدون کد اعتبارسنجی انجام شد!');

http("$BASE/admin/captcha?t=" . time());
$csrf = csrf_of(http("$BASE/admin/login")['body']);
http("$BASE/admin/captcha?t=" . (time() + 1));
$r = http("$BASE/admin/login", ['post' => ['_csrf' => $csrf, 'username' => $USER, 'password' => $PASS, 'captcha' => 'ZZZZZ']]);
db()->exec('DELETE FROM login_attempts');
$r['code'] === 200 && !str_contains($r['loc'], '/admin')
    ? ok_('ورود با کد اعتبارسنجی اشتباه رد شد')
    : bad_('کد اعتبارسنجی اشتباه پذیرفته شد!');

/* ورود واقعی: کد را از نشست سرور می‌خوانیم */
function captcha_code_from_session(?string $jarFile = null): ?string
{
    global $JAR;
    $jar = @file_get_contents($jarFile ?: $JAR) ?: '';
    if (!preg_match('/BMFORM\s+(\S+)\s*$/m', $jar, $m)) return null;
    $sid  = trim($m[1]);
    $path = ini_get('session.save_path') ?: sys_get_temp_dir();
    foreach (explode(';', $path) as $seg) {
        $seg = trim($seg);
        if ($seg === '' || is_numeric($seg)) continue;
        $f = rtrim($seg, '/\\') . '/sess_' . $sid;
        if (is_file($f) && preg_match('/code";s:5:"([A-Z0-9]{5})"/', (string)file_get_contents($f), $mm)) return $mm[1];
    }
    return null;
}

$csrf = csrf_of(http("$BASE/admin/login")['body']);
http("$BASE/admin/captcha?t=" . (time() + 2));
$code = captcha_code_from_session();
if (!$code) { echo "\n  ! کد کپچا از نشست خوانده نشد؛ آزمون‌های نیازمند ورود رد می‌شوند.\n"; }
$r = http("$BASE/admin/login", ['post' => ['_csrf' => $csrf, 'username' => $USER, 'password' => $PASS, 'captcha' => (string)$code]]);
$logged = ($r['code'] === 302 && str_contains($r['loc'], '/admin'));
$logged ? ok_('ورود با اطلاعات صحیح موفق بود') : bad_('ورود با اطلاعات صحیح انجام نشد (آزمون‌های بعدی نامعتبرند)');

/* ================================================== ۳) SQL Injection */
head('SQL Injection — جستجو و فیلترهای پنل');
$sqliFail = 0;
foreach ($SQLI as $payload) {
    $t0  = microtime(true);
    $res = http("$BASE/admin/submissions?q=" . urlencode($payload));
    $dt  = microtime(true) - $t0;
    $sig = leaks($res['body']);
    if ($res['code'] !== 200)      { bad_("q=«" . mb_substr($payload, 0, 28) . "» → HTTP {$res['code']}"); $sqliFail++; }
    elseif ($sig !== null)         { bad_("q=«" . mb_substr($payload, 0, 28) . "» → نشت خطا: $sig"); $sqliFail++; }
    elseif ($dt > 2.5)             { bad_("q=«" . mb_substr($payload, 0, 28) . "» → تأخیر " . round($dt, 1) . "s (time-based)"); $sqliFail++; }
}
$sqliFail === 0 ? ok_(count($SQLI) . ' محموله SQLi روی جستجو: همه بی‌اثر') : null;

$sqliFail = 0;
foreach ($SQLI as $payload) {
    foreach (['status', 'from', 'to', 'sort', 'page'] as $param) {
        $res = http("$BASE/admin/submissions?$param=" . urlencode($payload));
        if ($res['code'] !== 200 || leaks($res['body'])) {
            bad_("$param=«" . mb_substr($payload, 0, 20) . "» → HTTP {$res['code']} " . (leaks($res['body']) ?? ''));
            $sqliFail++;
        }
    }
}
$sqliFail === 0 ? ok_('همه پارامترهای فیلتر (status/from/to/sort/page) در برابر SQLi مقاوم‌اند') : null;

$sqliFail = 0;
foreach ($SQLI as $payload) {
    foreach (["$BASE/admin/logs?action=" . urlencode($payload),
              "$BASE/admin/view?id=" . urlencode($payload),
              "$BASE/admin/export?type=docx&id=" . urlencode($payload),
              "$BASE/admin/export-list?q=" . urlencode($payload)] as $u) {
        $res = http($u);
        if (!in_array($res['code'], [200, 302, 404], true) || leaks($res['body'])) {
            bad_(parse_url($u, PHP_URL_PATH) . " → HTTP {$res['code']} " . (leaks($res['body']) ?? ''));
            $sqliFail++;
        }
    }
}
$sqliFail === 0 ? ok_('مسیرهای logs / view / export در برابر SQLi مقاوم‌اند') : null;

head('SQL Injection — ورود و پیگیری عمومی');
$sqliFail = 0;
$anon = sys_get_temp_dir() . '/sectest_anon_' . getmypid() . '.jar';
foreach ($SQLI as $payload) {
    @unlink($anon);                                   // هر تلاش با نشست تازه و ناشناس
    $c = csrf_of(http("$BASE/admin/login", ['jar' => $anon])['body']);
    http("$BASE/admin/captcha?t=" . random_int(1, 1000000), ['jar' => $anon]);
    $cc = captcha_code_from_session($anon);           // کپچای درست می‌دهیم تا واقعاً به لایه‌ی رمز برسد
    $res = http("$BASE/admin/login", ['jar' => $anon, 'post' => [
        '_csrf' => $c, 'username' => $payload, 'password' => $payload, 'captcha' => (string)$cc]]);
    $dash = http("$BASE/admin", ['jar' => $anon]);    // تأیید مستقل: آیا واقعاً وارد شد؟
    if ($dash['code'] !== 302) { bad_("ورود با «" . mb_substr($payload, 0, 24) . "» موفق شد!"); $sqliFail++; }
    elseif (leaks($res['body'])) { bad_("نشت خطا در ورود با «" . mb_substr($payload, 0, 24) . "»"); $sqliFail++; }
    db()->exec('DELETE FROM login_attempts');         // تا قفل ورود، آزمون بعدی را مختل نکند
}
@unlink($anon);
$sqliFail === 0 ? ok_(count($SQLI) . ' محموله SQLi روی فرم ورود: هیچ‌کدام وارد نشدند و خطایی نشت نکرد') : null;

$sqliFail = 0;
foreach ($SQLI as $payload) {
    $c   = csrf_of(http("$BASE/track")['body']);
    $res = http("$BASE/track", ['post' => ['_csrf' => $c, 'code' => $payload, 'national_id' => $payload]]);
    if ($res['code'] !== 200 || leaks($res['body']) || str_contains($res['body'], 'فرم شما یافت شد')) {
        bad_("پیگیری با «" . mb_substr($payload, 0, 24) . "» → HTTP {$res['code']}");
        $sqliFail++;
    }
}
$sqliFail === 0 ? ok_('SQLi روی صفحه پیگیری: همه رد شدند') : null;

head('SQL Injection — ثبت فرم عمومی (همه فیلدها)');
$fields = [];
foreach (form_steps() as $step) {
    foreach ($step['blocks'] as $b) {
        if ($b['kind'] === 'fields') {
            foreach ($b['fields'] as $f) $fields[] = "f[{$b['name']}][{$f['name']}]";
        } elseif ($b['kind'] === 'fixed') {
            foreach ($b['rows'] as $r) foreach ($b['columns'] as $c) $fields[] = "f[{$b['name']}][{$r['key']}][{$c['name']}]";
        } else {
            foreach ($b['columns'] as $c) $fields[] = "f[{$b['name']}][0][{$c['name']}]";
        }
    }
}
echo "  (تعداد کل فیلدهای فرم: " . count($fields) . ")\n";

$c   = csrf_of(http("$BASE/")['body']);
$post = ['_csrf' => $c];
foreach ($fields as $n) $post[$n] = "' OR 1=1 --<script>alert(1)</script>";
$post['f[personal][first_name]'] = 'رابرت';
$post['f[personal][last_name]']  = 'جدولی';
$post['f[personal][father_name]'] = 'حسن';
$post['f[recruit][method]'] = "Rob'); DROP TABLE submissions;--";
$post['f[personal][national_id]'] = '2530000026';
$post['f[personal][marital]']     = 'مجرد';
$post['f[personal][birth_place]'] = 'تهران';
$post['f[personal][issue_place]'] = 'تهران';
$post['f[personal][religion]']    = 'اسلام';
$post['f[personal][id_type]']     = 'اصلی';
$post['f[personal][dual_nationality]'] = 'ندارم';
$post['f[contact][mobile]']       = '09120000000';
$post['f[pledge][accept]']        = 'می‌پذیرم';
$post['f[pledge][filler_name]']   = "<img src=x onerror=alert(1)>";
$post['f[pledge][filler_date]']   = '1403/05/12';
$res = http("$BASE/submit", ['post' => $post]);
$after = (int)db()->query('SELECT COUNT(*) FROM submissions')->fetchColumn();
in_array($res['code'], [302, 200], true) && !leaks($res['body'])
    ? ok_('ثبت فرم با محموله در تمام ' . count($fields) . ' فیلد بدون خطا پردازش شد')
    : bad_('ثبت فرم با محموله خطا داد: HTTP ' . $res['code'] . ' ' . (leaks($res['body']) ?? ''));

/* ================================================== ۴) سلامت پایگاه داده */
head('سلامت پایگاه داده پس از حملات');
try {
    $now = [
        'subs'   => (int)db()->query('SELECT COUNT(*) FROM submissions')->fetchColumn(),
        'admins' => (int)db()->query('SELECT COUNT(*) FROM admins')->fetchColumn(),
        'logs'   => (int)db()->query('SELECT COUNT(*) FROM audit_logs')->fetchColumn(),
    ];
    $now['admins'] === $before['admins']
        ? ok_("جدول admins سالم است ({$now['admins']} کاربر)")
        : bad_("تعداد کاربران تغییر کرد: {$before['admins']} → {$now['admins']}");
    $now['subs'] >= $before['subs']
        ? ok_("جدول submissions سالم است ({$now['subs']} رکورد؛ هیچ رکوردی حذف نشد)")
        : bad_("رکوردهای فرم حذف شدند: {$before['subs']} → {$now['subs']}");
    ok_('همه‌ی جدول‌ها همچنان قابل کوئری هستند');
} catch (Throwable $ex) {
    bad_('پایگاه داده آسیب دیده است: ' . $ex->getMessage());
}

/* بررسی اینکه محموله عیناً به‌عنوان داده ذخیره شده (نه اجرا) */
$row = db()->query('SELECT data FROM submissions ORDER BY id DESC LIMIT 1')->fetchColumn();
if ($row && str_contains((string)$row, 'DROP TABLE')) {
    ok_('محموله‌ی SQL به‌صورت متن خام ذخیره شد (به‌عنوان داده، نه دستور)');
}

/* ================================================== ۵) XSS */
head('XSS — بازتاب ورودی در صفحات');
$xssFail = 0;
foreach ($XSS as $p) {
    foreach (["$BASE/admin/submissions?q=" . urlencode($p),
              "$BASE/admin/logs?action=" . urlencode($p)] as $u) {
        $res = http($u);
        $b   = $res['body'];
        if (str_contains($b, '<script>window.__x=1</script>')
            || preg_match('/<img[^>]+onerror\s*=/i', $b)
            || preg_match('/<svg[^>]*onload\s*=/i', $b)
            || str_contains($b, '"><script>')) {
            bad_('بازتاب اجراشدنی XSS در ' . parse_url($u, PHP_URL_PATH) . ' با «' . mb_substr($p, 0, 24) . '»');
            $xssFail++;
        }
    }
}
$xssFail === 0 ? ok_(count($XSS) . ' محموله XSS در جستجو و لاگ: همه فرار داده شدند') : null;

$res = http("$BASE/admin/submissions?q=" . urlencode('<script>window.__x=1</script>'));
str_contains($res['body'], '&lt;script&gt;')
    ? ok_('ورودی خطرناک به‌صورت موجودیت HTML نمایش داده می‌شود')
    : warn_('نتوانستم فرار HTML را در خروجی تأیید کنم');

// صفحه نمایش فرمی که با محموله ثبت شد
$id  = (int)db()->query('SELECT id FROM submissions ORDER BY id DESC LIMIT 1')->fetchColumn();
$res = http("$BASE/admin/view?id=$id");
(!preg_match('/<img[^>]+onerror/i', $res['body']) && !str_contains($res['body'], '<script>alert'))
    ? ok_('صفحه مشاهده فرم، محتوای مخرب ذخیره‌شده را اجرا نمی‌کند (Stored XSS)')
    : bad_('Stored XSS در صفحه مشاهده فرم!');
$res = http("$BASE/admin/print?id=$id");
(!preg_match('/<img[^>]+onerror/i', $res['body']) && !str_contains($res['body'], '<script>alert'))
    ? ok_('صفحه چاپ نیز محتوای مخرب را فرار می‌دهد')
    : bad_('Stored XSS در صفحه چاپ!');

/* ================================================== ۶) CSRF */
head('CSRF');
$csrfFail = 0;
foreach ([['submit', ['f[personal][first_name]' => 'x']],
          ['admin/status', ['id' => $id, 'status' => 'approved']],
          ['admin/delete', ['id' => $id]],
          ['admin/settings', ['do' => 'general', 'org_title' => 'HACKED']],
          ['admin/users', ['do' => 'add', 'username' => 'hacker', 'password' => 'Passw0rd1']],
          ['track', ['code' => 'x', 'national_id' => '1']]] as [$r, $data]) {
    $res = http("$BASE/$r", ['post' => $data]);
    if ($res['code'] === 419) ok_("POST /$r بدون توکن CSRF رد شد");
    else { bad_("POST /$r بدون توکن CSRF پاسخ {$res['code']} داد!"); $csrfFail++; }
}
$t = (string)db()->query('SELECT v FROM settings WHERE k = ' . "'org_title'")->fetchColumn();
$t !== 'HACKED' ? ok_('تنظیمات از طریق CSRF تغییر نکرد') : bad_('تنظیمات با CSRF تغییر کرد!');
$n = (int)db()->query("SELECT COUNT(*) FROM admins WHERE username = 'hacker'")->fetchColumn();
$n === 0 ? ok_('کاربر مدیر از طریق CSRF ساخته نشد') : bad_('کاربر مدیر با CSRF ساخته شد!');

/* ================================================== ۷) Path traversal / LFI */
head('Path Traversal و File Inclusion');
$tFail = 0;
foreach ($TRAVERSAL as $p) {
    foreach (["$BASE/" . ltrim($p, '/'),
              "$BASE/admin/view?id=" . urlencode($p),
              "$BASE/assets/css/" . urlencode($p)] as $u) {
        $res = http($u);
        if (str_contains($res['body'], 'root:x:') || str_contains($res['body'], '[fonts]')
            || str_contains($res['body'], "'password' =>") || str_contains($res['body'], 'app_key')) {
            bad_("نشت فایل با «" . mb_substr($p, 0, 30) . "» در " . parse_url($u, PHP_URL_PATH));
            $tFail++;
        }
    }
}
$tFail === 0 ? ok_(count($TRAVERSAL) . ' محموله Path Traversal: هیچ فایلی نشت نکرد') : null;

foreach (['app/config.php', 'app/../app/config.php', 'storage/logs/php-error.log',
          '../app/config.php', 'app/migrate.php', 'tools/selftest.php'] as $p) {
    $res = http("$BASE/$p");
    if ($res['code'] === 200 && (str_contains($res['body'], 'app_key') || str_contains($res['body'], '<?php'))) {
        bad_("فایل حساس /$p از وب قابل خواندن است!");
    }
}
ok_('فایل‌های داخلی برنامه از طریق وب قابل دسترسی نیستند');

$res = http("$BASE/admin/../app/config.php");
!str_contains($res['body'], 'app_key') ? ok_('پیکربندی از راه traversal قابل خواندن نیست') : bad_('config.php نشت کرد!');

/* ================================================== ۸) اجرای CLI از وب */
head('اسکریپت‌های CLI');
foreach (['app/migrate.php', 'tools/selftest.php', 'tools/sectest.php'] as $p) {
    $res = http("$BASE/$p");
    ($res['code'] !== 200 || !str_contains($res['body'], 'جدول'))
        ? ok_("/$p از طریق وب اجرا نمی‌شود")
        : bad_("/$p از طریق وب اجرا شد!");
}

/* ================================================== ۹) اعتبارسنجی داده */
head('اعتبارسنجی ورودی فرم عمومی');
$c = csrf_of(http("$BASE/")['body']);
$res = http("$BASE/submit", ['post' => [
    '_csrf' => $c,
    'f[personal][first_name]' => 'تست', 'f[personal][last_name]' => 'تست',
    'f[personal][father_name]' => 'تست', 'f[personal][national_id]' => '1234567890',
    'f[personal][birth_date]' => '1370/01/01', 'f[personal][marital]' => 'مجرد',
    'f[personal][birth_place]' => 'تهران', 'f[personal][issue_place]' => 'تهران',
    'f[personal][religion]' => 'اسلام', 'f[personal][id_type]' => 'اصلی',
    'f[personal][dual_nationality]' => 'ندارم',
    'f[contact][mobile]' => '09120000000', 'f[pledge][accept]' => 'می‌پذیرم',
    'f[pledge][filler_name]' => 'تست', 'f[pledge][filler_date]' => '1403/01/01',
]]);
$page = http("$BASE/")['body'];
str_contains($page, 'کد ملی وارد شده معتبر نیست')
    ? ok_('کد ملی نامعتبر در سمت سرور رد شد')
    : bad_('کد ملی نامعتبر پذیرفته شد!');

$c = csrf_of(http("$BASE/")['body']);
$res = http("$BASE/submit", ['post' => [
    '_csrf' => $c,
    'f[personal][first_name]' => 'تست', 'f[personal][last_name]' => 'تست',
    'f[personal][father_name]' => 'تست', 'f[personal][national_id]' => '2530000034',
    'f[personal][birth_date]' => '1370/01/01', 'f[personal][marital]' => 'هرچیزی',
    'f[personal][id_type]' => 'مقدار جعلی',
    'f[personal][birth_place]' => 'تهران', 'f[personal][issue_place]' => 'تهران',
    'f[personal][religion]' => 'اسلام', 'f[personal][dual_nationality]' => 'ندارم',
    'f[contact][mobile]' => '12345', 'f[pledge][accept]' => 'می‌پذیرم',
    'f[pledge][filler_name]' => 'تست', 'f[pledge][filler_date]' => '1403/01/01',
]]);
$page = http("$BASE/")['body'];
(str_contains($page, 'تلفن همراه') && str_contains($page, 'وضعیت تأهل'))
    ? ok_('مقادیر خارج از فهرست مجاز (radio/select) و موبایل نامعتبر رد شدند')
    : warn_('اعتبارسنجی مقادیر خارج از فهرست را نتوانستم تأیید کنم');

head('اجباری بودن حروف فارسی در نام‌ها');
$c = csrf_of(http("$BASE/")['body']);
$base = [
    '_csrf' => $c,
    'f[personal][national_id]' => '2530000050', 'f[personal][birth_date]' => '1370/01/01',
    'f[personal][marital]' => 'مجرد', 'f[contact][mobile]' => '09120000000',
    'f[personal][birth_place]' => 'تهران', 'f[personal][issue_place]' => 'تهران',
    'f[personal][religion]' => 'اسلام', 'f[personal][id_type]' => 'اصلی',
    'f[personal][dual_nationality]' => 'ندارم',
    'f[pledge][accept]' => 'می‌پذیرم', 'f[pledge][filler_name]' => 'تست',
    'f[pledge][filler_date]' => '1403/01/01',
];
http("$BASE/submit", ['post' => $base + [
    'f[personal][first_name]' => 'Ali', 'f[personal][last_name]' => 'Ahmadi',
    'f[personal][father_name]' => 'Hasan']]);
$page = http("$BASE/")['body'];
str_contains($page, 'باید فقط با حروف فارسی نوشته شود')
    ? ok_('نام لاتین در سمت سرور رد شد')
    : bad_('نام لاتین پذیرفته شد!');

$before = (int)db()->query('SELECT COUNT(*) FROM submissions')->fetchColumn();
$c = csrf_of(http("$BASE/")['body']);
http("$BASE/submit", ['post' => ['_csrf' => $c] + array_slice($base, 1) + [
    'f[personal][first_name]' => 'كريم', 'f[personal][last_name]' => 'رضايي',
    'f[personal][father_name]' => 'محمد']]);
$row = db()->query('SELECT data FROM submissions ORDER BY id DESC LIMIT 1')->fetchColumn();
$d = json_decode((string)$row, true);
((int)db()->query('SELECT COUNT(*) FROM submissions')->fetchColumn() > $before
  && ($d['personal']['first_name'] ?? '') === 'کریم' && ($d['personal']['last_name'] ?? '') === 'رضایی')
    ? ok_('نویسه‌های عربی (ي/ك) خودکار به فارسی تبدیل و ذخیره شدند')
    : bad_('یکسان‌سازی نویسه‌های عربی انجام نشد');

/* نام لاتین داخل جدول تکرارشونده و بلوک ثابت هم باید رد شود */
$c = csrf_of(http("$BASE/")['body']);
http("$BASE/submit", ['post' => [
    '_csrf' => $c,
    'f[personal][first_name]' => 'سمانه', 'f[personal][last_name]' => 'رضایی',
    'f[personal][father_name]' => 'اکبر', 'f[personal][national_id]' => '2530000069',
    'f[personal][birth_date]' => '1370/01/01', 'f[personal][marital]' => 'متأهل',
    'f[spouses][current][father_name]' => 'کریم', 'f[spouses][current][national_id]' => '2530000026',
    'f[spouses][current][birth_date]' => '1372/01/01', 'f[spouses][current][birth_place]' => 'تهران',
    'f[spouses][current][religion]' => 'اسلام', 'f[spouses][current][dual_nationality]' => 'ندارد',
    'f[spouses][current][marriage_date]' => '1395/01/01',
    'f[personal][birth_place]' => 'تهران', 'f[personal][issue_place]' => 'تهران',
    'f[personal][religion]' => 'اسلام', 'f[personal][id_type]' => 'اصلی',
    'f[personal][dual_nationality]' => 'ندارم',
    'f[contact][mobile]' => '09120000000',
    'f[spouses][current][full_name]' => 'Zahra Karimi',
    'f[family][0][full_name]' => 'Akbar Rezaei',
    'f[pledge][accept]' => 'می‌پذیرم', 'f[pledge][filler_name]' => 'سمانه رضایی',
    'f[pledge][filler_date]' => '1403/01/01',
]]);
$page = http("$BASE/")['body'];
$n = substr_count($page, 'باید فقط با حروف فارسی نوشته شود');
$n >= 2
    ? ok_("نام لاتین در بلوک ثابت (همسر) و جدول تکرارشونده (خانواده) هم رد شد ($n خطا)")
    : bad_("اعتبارسنجی فارسی در بلوک‌های ثابت/تکرارشونده کار نکرد ($n خطا)");

head('پنل خصوصی سازنده');
$r = http("$BASE/dev");
(str_contains($r['body'], 'name="do" value="login"') || str_contains($r['body'], 'value="setup"'))
    ? ok_('پنل سازنده بدون ورود فقط فرم ورود نشان می‌دهد')
    : bad_('پنل سازنده بدون ورود باز است!');
!str_contains($r['body'], 'do" value="credit"')
    ? ok_('کلید امضا برای کاربر ناشناس نمایش داده نمی‌شود')
    : bad_('کلید امضا بدون ورود در دسترس است!');

$before = app_setting('credit_enabled', '1');
$c = csrf_of($r['body']);
http("$BASE/dev", ['post' => ['_csrf' => $c, 'do' => 'credit', 'on' => '']]);
$fresh = (string)db()->query("SELECT v FROM settings WHERE k = 'credit_enabled'")->fetchColumn();
($fresh === '' || $fresh === $before)
    ? ok_('کاربر ناشناس نتوانست امضای سازنده را خاموش کند')
    : bad_('امضای سازنده بدون ورود خاموش شد!');

foreach (['dev', 'DEV', 'dev/'] as $u) {
    $x = http("$BASE/$u");
    if ($x['code'] === 200 && str_contains($x['body'], 'do" value="credit"')) {
        bad_("مسیر /$u بدون ورود پنل کامل را نشان داد!");
    }
}
ok_('نسخه‌های مختلف مسیر پنل هم محافظت شده‌اند');

/* ================================================== ۱۰) سطح دسترسی */
head('تفکیک سطح دسترسی (کارشناس در برابر مدیر ارشد)');
$c = csrf_of(http("$BASE/admin/users")['body']);
if ($c) {
    http("$BASE/admin/users", ['post' => ['_csrf' => $c, 'do' => 'add', 'username' => 'sec_operator',
        'display_name' => 'اپراتور آزمون', 'password' => 'Operator123', 'role' => 'operator']]);
    $exists = (int)db()->query("SELECT COUNT(*) FROM admins WHERE username = 'sec_operator'")->fetchColumn();
    $exists ? ok_('کاربر کارشناس آزمایشی ساخته شد') : warn_('ساخت کاربر آزمایشی انجام نشد');

    if ($exists) {
        db()->exec('DELETE FROM login_attempts');
        @unlink($JAR);
        $c2 = csrf_of(http("$BASE/admin/login")['body']);
        http("$BASE/admin/captcha?t=" . random_int(1, 1000000));
        $code2 = captcha_code_from_session();
        $r = http("$BASE/admin/login", ['post' => ['_csrf' => $c2, 'username' => 'sec_operator',
              'password' => 'Operator123', 'captcha' => (string)$code2]]);
        if ($r['code'] === 302) {
            $res = http("$BASE/admin/users");
            ($res['code'] === 403 || str_contains($res['body'], 'دسترسی فقط برای مدیر ارشد'))
                ? ok_('کارشناس به صفحه کاربران دسترسی ندارد')
                : bad_('کارشناس به مدیریت کاربران دسترسی دارد!');

            $subCount = (int)db()->query('SELECT COUNT(*) FROM submissions')->fetchColumn();
            $c3 = csrf_of(http("$BASE/admin/submissions")['body']);
            http("$BASE/admin/delete", ['post' => ['_csrf' => $c3, 'id' => $id]]);
            $after = (int)db()->query('SELECT COUNT(*) FROM submissions')->fetchColumn();
            $after === $subCount ? ok_('کارشناس نتوانست فرم را حذف کند') : bad_('کارشناس فرم را حذف کرد!');
        } else { warn_('ورود با کاربر کارشناس انجام نشد؛ آزمون سطح دسترسی ناقص ماند'); }
    }
} else { warn_('صفحه کاربران در دسترس نبود'); }

/* ================================================== ۱۱) نشست و هدرها */
head('نشست، هدرها و نشت اطلاعات');
$fresh = sys_get_temp_dir() . '/sectest_fresh_' . getmypid() . '.jar';
@unlink($fresh);
$res = http("$BASE/admin/login", ['jar' => $fresh]);   // نشست تازه تا هدر Set-Cookie صادر شود
str_contains(strtolower($res['head']), 'httponly')
    ? ok_('کوکی نشست دارای پرچم HttpOnly است')
    : warn_('پرچم HttpOnly روی کوکی دیده نشد');
str_contains(strtolower($res['head']), 'samesite')
    ? ok_('کوکی نشست دارای SameSite است')
    : warn_('SameSite روی کوکی دیده نشد');

$res = http("$BASE/nonexistent-page-" . random_int(1000, 9999));
($res['code'] === 404 && !leaks($res['body']))
    ? ok_('صفحه ۴۰۴ بدون افشای مسیر یا خطای داخلی نمایش داده می‌شود')
    : warn_('صفحه ۴۰۴: HTTP ' . $res['code'] . ' ' . (leaks($res['body']) ?? ''));

$res = http("$BASE/admin/captcha?t=1");
str_contains(strtolower($res['head']), 'no-store')
    ? ok_('تصویر کپچا کش نمی‌شود')
    : bad_('تصویر کپچا کش می‌شود (قابل استفاده مجدد)');

/* --- تثبیت نشست (Session Fixation) --- */
$fx = sys_get_temp_dir() . '/sectest_fix_' . getmypid() . '.jar';
@unlink($fx);
$c = csrf_of(http("$BASE/admin/login", ['jar' => $fx])['body']);
$sidBefore = preg_match('/BMFORM\s+(\S+)\s*$/m', (string)@file_get_contents($fx), $m1) ? trim($m1[1]) : '';
http("$BASE/admin/captcha?t=" . random_int(1, 1000000), ['jar' => $fx]);
$cc = captcha_code_from_session($fx);
db()->exec('DELETE FROM login_attempts');
http("$BASE/admin/login", ['jar' => $fx, 'post' => ['_csrf' => $c, 'username' => $USER, 'password' => $PASS, 'captcha' => (string)$cc]]);
$sidAfter = preg_match('/BMFORM\s+(\S+)\s*$/m', (string)@file_get_contents($fx), $m2) ? trim($m2[1]) : '';
($sidBefore !== '' && $sidAfter !== '' && $sidBefore !== $sidAfter)
    ? ok_('شناسه نشست پس از ورود بازتولید می‌شود (ضد Session Fixation)')
    : bad_('شناسه نشست پس از ورود تغییر نکرد (Session Fixation)');

/* --- Open Redirect --- */
$orFail = 0;
foreach (['//evil.example.com/', 'https://evil.example.com/', '/\evil.example.com',
          "/admin

Set-Cookie:%20x=1"] as $bad) {
    $res = http("$BASE/admin/submissions?next=" . urlencode($bad));
    $loc = strtolower($res['loc']);
    if ($loc !== '' && (str_contains($loc, 'evil.example.com'))) { bad_("Open Redirect با «$bad»"); $orFail++; }
    if (preg_match('/set-cookie:\s*x=1/i', $res['head'])) { bad_("تزریق هدر با «$bad»"); $orFail++; }
}
$orFail === 0 ? ok_('Open Redirect و تزریق هدر: هیچ‌کدام موفق نبودند') : null;

/* --- بایت تهی و تزریق هدر در نام فایل خروجی --- */
$idx = (int)db()->query('SELECT id FROM submissions ORDER BY id DESC LIMIT 1')->fetchColumn();
$res = http("$BASE/admin/export?id=$idx&type=docx%00.php");
$ct  = strtolower($res['type'] ?? '');
(str_contains($ct, 'wordprocessingml') || $res['code'] === 302)
    ? ok_('پارامتر type فقط از فهرست سفید پذیرفته می‌شود (بایت تهی بی‌اثر)')
    : warn_('نوع خروجی: ' . $ct);
!preg_match('/



.*content-disposition/is', $res['head'])
    ? ok_('هدر نام فایل قابل تزریق نیست')
    : bad_('تزریق هدر در نام فایل!');

/* --- محدودیت حجم ورودی (DoS) --- */
$c = csrf_of(http("$BASE/")['body']);
$big = ['_csrf' => $c];
for ($i = 0; $i < 300; $i++) {                       // ۳۰۰ ردیف در یک جدول تکرارشونده
    $big["f[family][$i][full_name]"] = str_repeat('الف', 400);
}
$big['f[personal][first_name]'] = 'حجیم'; $big['f[personal][last_name]'] = 'تست';
$big['f[personal][father_name]'] = 'تست'; $big['f[personal][national_id]'] = '2530000042';
$big['f[personal][birth_date]'] = '1370/01/01'; $big['f[personal][marital]'] = 'مجرد';
$big['f[personal][birth_place]'] = 'تهران'; $big['f[personal][issue_place]'] = 'تهران';
$big['f[personal][religion]'] = 'اسلام'; $big['f[personal][id_type]'] = 'اصلی';
$big['f[personal][dual_nationality]'] = 'ندارم';
$big['f[contact][mobile]'] = '09120000000'; $big['f[pledge][accept]'] = 'می‌پذیرم';
$big['f[pledge][filler_name]'] = 'تست'; $big['f[pledge][filler_date]'] = '1403/01/01';
$t0 = microtime(true);
$res = http("$BASE/submit", ['post' => $big]);
$dt = microtime(true) - $t0;
$last = (string)db()->query('SELECT data FROM submissions ORDER BY id DESC LIMIT 1')->fetchColumn();
$rows = count(json_decode($last, true)['family'] ?? []);
($rows <= 60 && $dt < 10)
    ? ok_("ورودی حجیم مهار شد (۳۰۰ ردیف → $rows ردیف ذخیره شد، " . round($dt, 1) . "s)")
    : bad_("ورودی حجیم مهار نشد: $rows ردیف در " . round($dt, 1) . "s");
$fieldLen = mb_strlen(json_decode($last, true)['family'][0]['full_name'] ?? '');
$fieldLen <= 300 ? ok_("طول هر فیلد محدود شد ($fieldLen نویسه)") : bad_("طول فیلد محدود نشد ($fieldLen)");

/* ================================================== ۱۲) محدودیت تلاش ورود */
head('محافظت در برابر حدس رمز');
@unlink($JAR);
$blocked = false;
for ($i = 0; $i < 11; $i++) {
    $c = csrf_of(http("$BASE/admin/login")['body']);
    http("$BASE/admin/captcha?t=" . random_int(1, 1000000));
    $cc = captcha_code_from_session();
    $r  = http("$BASE/admin/login", ['post' => ['_csrf' => $c, 'username' => $USER,
          'password' => 'wrong' . $i, 'captcha' => (string)$cc]]);
    if (str_contains($r['body'], 'مسدود')) { $blocked = true; break; }
}
$blocked ? ok_('پس از تلاش‌های ناموفق متوالی، ورود موقتاً مسدود شد (' . ($i + 1) . ' تلاش)')
         : bad_('محدودیت تلاش ورود فعال نشد!');

/* ================================================== پاک‌سازی */
db()->prepare('DELETE FROM admins WHERE username = ?')->execute(['sec_operator']);
db()->exec('DELETE FROM login_attempts');
@unlink($JAR);

echo "\n" . str_repeat('═', 58) . "\n";
printf("  موفق: %d    ناموفق: %d    هشدار: %d\n", $pass, $fail, $warn);
echo str_repeat('═', 58) . "\n\n";
exit($fail === 0 ? 0 : 1);
