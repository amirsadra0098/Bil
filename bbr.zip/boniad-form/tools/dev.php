<?php
/**
 * مدیریت پنل سازنده از خط فرمان.
 *
 * رمز همیشه از ورودی استاندارد خوانده می‌شود، نه از آرگومان‌ها،
 * تا در فهرست پردازه‌ها (ps) و تاریخچه‌ی شل دیده نشود.
 *
 *   echo -n 'pass' | php tools/dev.php verify      → کد خروج ۰ یعنی درست
 *   echo -n 'pass' | php tools/dev.php set-pass
 *   php tools/dev.php status                       → on | off | nopass
 *   php tools/dev.php credit-on
 *   php tools/dev.php credit-off
 */

if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }

require __DIR__ . '/../app/bootstrap.php';

function read_secret(): string
{
    $s = stream_get_contents(STDIN);
    return trim((string)$s, "\r\n");
}

$cmd = $argv[1] ?? 'status';

switch ($cmd) {

    case 'verify':
        if (dev_hash() === '') { fwrite(STDERR, "nopass\n"); exit(2); }
        exit(password_verify(read_secret(), dev_hash()) ? 0 : 1);

    case 'set-pass':
        $p = read_secret();
        if (mb_strlen($p) < 8) { fwrite(STDERR, "too-short\n"); exit(1); }
        dev_set_password($p);
        log_action('dev_passwd', 'dev', null, 'تغییر رمز پنل سازنده از خط فرمان');
        echo "ok\n";
        exit(0);

    case 'credit-on':
    case 'credit-off':
        $on = ($cmd === 'credit-on') ? '1' : '0';
        set_setting('credit_enabled', $on);
        log_action('credit_toggle', 'dev', null,
            'امضای سازنده از خط فرمان: ' . ($on === '1' ? 'روشن' : 'خاموش'));
        echo ($on === '1' ? "on\n" : "off\n");
        exit(0);

    case 'status':
        if (dev_hash() === '') { echo "nopass\n"; exit(0); }
        echo credit_enabled() ? "on\n" : "off\n";
        exit(0);

    default:
        fwrite(STDERR, "unknown command: $cmd\n");
        exit(1);
}
