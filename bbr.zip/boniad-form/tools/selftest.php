<?php
/**
 * آزمون خودکار سامانه: اسکیما، ذخیره، رندر و خروجی Word/Excel.
 * اجرا:  php tools/selftest.php
 */

if (PHP_SAPI !== 'cli') exit('CLI only');

require __DIR__ . '/../app/bootstrap.php';
require __DIR__ . '/../app/export/build.php';

$pass = 0; $fail = 0;
function t(string $name, callable $fn) {
    global $pass, $fail;
    try {
        $r = $fn();
        if ($r === true || $r === null) { echo "  ✔ $name\n"; $pass++; }
        else { echo "  ✘ $name  →  $r\n"; $fail++; }
    } catch (Throwable $ex) {
        echo "  ✘ $name  →  " . $ex->getMessage() . ' @ ' . basename($ex->getFile()) . ':' . $ex->getLine() . "\n";
        $fail++;
    }
}

echo "\n== آزمون سامانه ثبت فرم ==\n\n";

/* ------------------------------------------------------------- اسکیما */
echo "[اسکیما]\n";
t('ساختار مراحل معتبر است', function () {
    $names = [];
    foreach (form_steps() as $s) {
        foreach (['id', 'num', 'title', 'blocks'] as $k) if (!isset($s[$k])) return "کلید $k در مرحله {$s['id']} نیست";
        foreach ($s['blocks'] as $b) {
            if (!isset($b['kind'], $b['name'])) return 'بلوک بدون kind/name';
            if (in_array($b['name'], $names, true)) return 'نام تکراری بلوک: ' . $b['name'];
            $names[] = $b['name'];
            foreach (block_fields($b) as $f) {
                if (!isset($f['name'], $f['label'], $f['type'])) return 'فیلد ناقص در ' . $b['name'];
                if (in_array($f['type'], ['select', 'radio', 'checks'], true) && empty($f['options'])) {
                    return 'فیلد ' . $b['name'] . '.' . $f['name'] . ' گزینه ندارد';
                }
            }
        }
    }
    return true;
});
t('تعداد مراحل ۸ است', fn() => count(form_steps()) === 8 ?: 'تعداد: ' . count(form_steps()));

/* ------------------------------------------------------------- تاریخ */
echo "\n[تاریخ شمسی]\n";
t('تبدیل 2024-03-20 → 1403/01/01', function () {
    [$y, $m, $d] = g2j(2024, 3, 20);
    return sprintf('%d/%02d/%02d', $y, $m, $d) === '1403/01/01' ?: "$y/$m/$d";
});
t('رفت و برگشت ۱۰۰۰ روز', function () {
    for ($i = 0; $i < 1000; $i++) {
        $ts = strtotime("2015-01-01 +$i days");
        [$jy, $jm, $jd] = g2j((int)date('Y', $ts), (int)date('n', $ts), (int)date('j', $ts));
        [$gy, $gm, $gd] = j2g($jy, $jm, $jd);
        if (sprintf('%04d-%02d-%02d', $gy, $gm, $gd) !== date('Y-m-d', $ts)) return date('Y-m-d', $ts);
    }
    return true;
});

/* -------------------------------------------------------- اعتبارسنجی */
echo "\n[اعتبارسنجی]\n";
t('کد ملی صحیح پذیرفته شود', fn() => valid_national_id('0084575948') ?: 'رد شد');
t('کد ملی غلط رد شود', fn() => !valid_national_id('1234567890') ?: 'پذیرفته شد');
t('کد ملی تکراری رد شود', fn() => !valid_national_id('1111111111') ?: 'پذیرفته شد');
t('موبایل صحیح', fn() => valid_mobile('۰۹۱۲۳۴۵۶۷۸۹') ?: 'رد شد');
t('موبایل غلط', fn() => !valid_mobile('021334455') ?: 'پذیرفته شد');

/* --------------------------------------------------------- داده نمونه */
function sample_data(): array
{
    return [
        'personal' => [
            'first_name' => 'محمدرضا', 'last_name' => 'احمدی', 'father_name' => 'حسن',
            'birth_cert_no' => '۱۲۳۴', 'national_id' => '0084575948', 'birth_date' => '1368/04/12',
            'birth_place' => 'تهران', 'issue_place' => 'تهران', 'prev_last_name' => '', 'nickname' => '',
            'id_type' => 'اصلی', 'duplicate_issue_date' => '', 'duplicate_reason' => '',
            'religion' => 'اسلام - شیعه', 'marital' => 'متأهل', 'dual_nationality' => 'ندارم', 'dual_country' => '',
        ],
        'appearance' => ['height' => '178', 'weight' => '76', 'face_color' => 'گندمی', 'hair_color' => 'مشکی', 'eye_color' => 'قهوه‌ای', 'special_mark' => 'ندارد'],
        'edu_passport' => ['last_degree' => 'لیسانس', 'field_of_study' => 'مهندسی عمران', 'passport_type_no' => '', 'passport_issue_date' => '', 'military_status' => 'خدمت کرده', 'military_place' => 'تهران', 'exemption_type' => ''],
        'workplace' => ['org_name' => 'بنیاد مسکن انقلاب اسلامی', 'general_dept' => 'اداره کل استان تهران', 'deputy' => 'معاونت عمران', 'dept' => 'اداره فنی', 'position' => 'کارشناس', 'employment_status' => 'رسمی', 'job_group' => '۱۲', 'transferred_from' => ''],
        'contact' => ['mobile' => '09123456789', 'mobile2' => '', 'work_phone' => '02188001122', 'home_phone' => '', 'email' => 'test@example.com'],
        'spouses' => [
            'current' => ['full_name' => 'زهرا کریمی', 'father_name' => 'علی', 'national_id' => '0084575948', 'birth_date' => '1370/02/03', 'birth_place' => 'تهران', 'marriage_date' => '1395/06/10', 'education' => 'لیسانس', 'job' => 'معلم', 'work_address' => 'تهران، خیابان ولیعصر', 'dual_nationality' => 'ندارد'],
            'previous' => [], 'second' => [],
        ],
        'residence' => [
            'current'  => ['from' => '1396/01/01', 'to' => '', 'address' => 'تهران، منطقه ۵، خیابان نمونه، پلاک ۱۲', 'postal_code' => '1234567890', 'house_status' => 'شخصی'],
            'previous' => ['from' => '1390/01/01', 'to' => '1395/12/29', 'address' => 'کرج، مهرشهر', 'postal_code' => '', 'house_status' => 'استیجاری'],
        ],
        'family' => [
            ['full_name' => 'حسن احمدی', 'father_name' => 'رضا', 'relation' => 'پدر', 'age' => '68', 'job' => 'بازنشسته', 'address' => 'تهران'],
            ['full_name' => 'فاطمه رستمی', 'father_name' => 'محمود', 'relation' => 'مادر', 'age' => '62', 'job' => 'خانه‌دار', 'address' => 'تهران'],
        ],
        'education' => [['place' => 'دبیرستان شهید بهشتی', 'field' => 'ریاضی فیزیک', 'class_from' => 'اول', 'class_to' => 'چهارم', 'date_from' => '1383/07/01', 'date_to' => '1387/03/31', 'address' => 'تهران']],
        'courses' => [['name' => 'ایمنی کارگاه', 'field' => 'HSE', 'institute' => 'سازمان فنی و حرفه‌ای', 'from' => '1398/02/01', 'to' => '1398/03/01', 'address' => 'تهران']],
        'languages' => [['lang' => 'انگلیسی', 'level' => 'متوسط', 'institute' => 'کیش', 'from' => '', 'to' => '', 'address' => '']],
        'jobs' => [['title' => 'کارشناس فنی', 'role' => 'نظارت', 'from' => '1392/01/01', 'to' => '1396/01/01', 'leave_reason' => 'انتقال', 'workplace' => 'شرکت الف، تهران']],
        'foreign_orgs' => ['self' => [], 'spouse' => [], 'relatives' => []],
        'recruit' => ['method' => 'از طریق آزمون استخدامی سال ۱۳۹۶'],
        'referrers' => [['full_name' => 'علی محمدی', 'job' => 'رئیس اداره', 'relation' => 'همکار', 'address' => 'تهران - ۰۲۱۸۸۰۰۱۱۲۲']],
        'relatives_in_org' => [],
        'travels' => [['person' => 'خود', 'country' => 'عراق', 'city' => 'کربلا', 'duration' => '۷ روز', 'from' => '1397/08/01', 'to' => '1397/08/08', 'reason' => 'زیارت', 'companions' => 'همسر']],
        'friends' => [
            ['full_name' => 'رضا نوری', 'job' => 'کارشناس', 'workplace' => 'اداره کل - ۰۲۱۸۸۱۱۲۲۳۳'],
            ['full_name' => 'سعید کاظمی', 'job' => 'مهندس', 'workplace' => 'شرکت ب'],
        ],
        'weapons' => [], 'parties' => [],
        'sacrifice' => [], 'sacrifice_relatives' => [['full_name' => 'محمود احمدی', 'relation' => 'عمو', 'kind' => ['شهید'], 'address' => 'تهران']],
        'detentions' => [], 'foreign_relatives' => [], 'migrants' => [], 'criminal_records' => [], 'groupings' => [],
        'pledge' => ['filler_name' => 'محمدرضا احمدی', 'filler_date' => '1403/05/12', 'accept' => 'می‌پذیرم', 'signature' => ''],
    ];
}

/* --------------------------------------------------------- پایگاه داده */
echo "\n[پایگاه داده]\n";
$subId = null;
t('درج فرم نمونه', function () use (&$subId) {
    $d = sample_data();
    $code = tracking_code();
    db()->prepare('INSERT INTO submissions (tracking_code, first_name, last_name, father_name, national_id, mobile, birth_date, org_name, position, status, data, ip, user_agent, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
        ->execute([$code, 'محمدرضا', 'احمدی', 'حسن', '0084575948', '09123456789', '1368/04/12',
                   'بنیاد مسکن انقلاب اسلامی', 'کارشناس', 'new', json_encode($d, JSON_UNESCAPED_UNICODE),
                   '127.0.0.1', 'selftest', date('Y-m-d H:i:s'), date('Y-m-d H:i:s')]);
    $subId = (int)db()->lastInsertId(db_driver() === 'pgsql' ? 'submissions_id_seq' : null);
    return $subId > 0 ?: 'شناسه دریافت نشد';
});
t('جستجو با نام خانوادگی', function () {
    $st = db()->prepare('SELECT COUNT(*) FROM submissions WHERE last_name ' . like_op() . ' ?');
    $st->execute(['%احمدی%']);
    return (int)$st->fetchColumn() > 0 ?: 'یافت نشد';
});
t('جستجو با کد ملی', function () {
    $st = db()->prepare('SELECT COUNT(*) FROM submissions WHERE national_id = ?');
    $st->execute(['0084575948']);
    return (int)$st->fetchColumn() > 0 ?: 'یافت نشد';
});
t('ترتیب از جدید به قدیم', function () {
    $rows = db()->query('SELECT created_at FROM submissions ORDER BY created_at DESC, id DESC LIMIT 5')->fetchAll();
    for ($i = 1; $i < count($rows); $i++) {
        if ($rows[$i]['created_at'] > $rows[$i - 1]['created_at']) return 'ترتیب نادرست';
    }
    return true;
});

/* ------------------------------------------------------------- رندر */
echo "\n[رندر HTML]\n";
t('رندر همه‌ی بلوک‌های فرم', function () {
    $html = '';
    foreach (form_steps() as $s) foreach ($s['blocks'] as $b) $html .= render_block($b, [], []);
    if (mb_strlen($html) < 5000) return 'خروجی کوتاه: ' . mb_strlen($html);
    if (substr_count($html, '<div class="block') < 20) return 'تعداد بلوک کم';
    return true;
});
t('رندر فقط‌خواندنی فرم پرشده', function () {
    $html = render_ro_form(sample_data());
    return (str_contains($html, 'محمدرضا') && str_contains($html, 'زهرا کریمی')) ?: 'داده در خروجی نیست';
});
t('فرار از HTML در مقادیر', function () {
    $b = schema_block('recruit');
    $html = render_block($b, ['recruit' => ['method' => '<script>x</script>']], []);
    return !str_contains($html, '<script>') ?: 'XSS!';
});

/* ------------------------------------------------------------ خروجی */
echo "\n[خروجی Word / Excel]\n";
$out = __DIR__ . '/../storage/logs';

t('ساخت فایل docx', function () use ($out) {
    if (!class_exists('ZipArchive')) return 'افزونه zip فعال نیست';
    $sub = ['id' => 1, 'tracking_code' => 'BM-05-TEST01', 'first_name' => 'محمدرضا', 'last_name' => 'احمدی',
            'national_id' => '0084575948', 'status' => 'new', 'created_at' => date('Y-m-d H:i:s')];
    $bin = submission_docx($sub, sample_data());
    file_put_contents($out . '/test.docx', $bin);
    if (strlen($bin) < 3000) return 'حجم کم: ' . strlen($bin);
    $z = new ZipArchive();
    if ($z->open($out . '/test.docx') !== true) return 'zip باز نشد';
    $xml = $z->getFromName('word/document.xml');
    $z->close();
    if (!$xml) return 'document.xml نیست';
    if (simplexml_load_string($xml) === false) return 'XML نامعتبر';
    if (!str_contains($xml, 'احمدی')) return 'محتوا در سند نیست';
    return true;
});

t('ساخت فایل xlsx', function () use ($out) {
    if (!class_exists('ZipArchive')) return 'افزونه zip فعال نیست';
    $sub = ['id' => 1, 'tracking_code' => 'BM-05-TEST01', 'first_name' => 'محمدرضا', 'last_name' => 'احمدی',
            'national_id' => '0084575948', 'status' => 'new', 'created_at' => date('Y-m-d H:i:s')];
    $bin = submission_xlsx($sub, sample_data());
    file_put_contents($out . '/test.xlsx', $bin);
    $z = new ZipArchive();
    if ($z->open($out . '/test.xlsx') !== true) return 'zip باز نشد';
    foreach (['xl/workbook.xml', 'xl/styles.xml', 'xl/worksheets/sheet1.xml', '[Content_Types].xml'] as $part) {
        $x = $z->getFromName($part);
        if ($x === false) return "بخش $part نیست";
        if (simplexml_load_string($x) === false) return "XML نامعتبر در $part";
    }
    $z->close();
    return true;
});

t('خروجی اکسل فهرست', function () use ($out) {
    if (!class_exists('ZipArchive')) return 'افزونه zip فعال نیست';
    $rows = db()->query('SELECT * FROM submissions ORDER BY created_at DESC LIMIT 50')->fetchAll();
    $bin = submissions_list_xlsx($rows);
    file_put_contents($out . '/test-list.xlsx', $bin);
    $z = new ZipArchive();
    if ($z->open($out . '/test-list.xlsx') !== true) return 'zip باز نشد';
    $x = $z->getFromName('xl/worksheets/sheet1.xml');
    $z->close();
    return simplexml_load_string($x) !== false ?: 'XML نامعتبر';
});

/* ------------------------------------------------------------ نتیجه */
echo "\n" . str_repeat('─', 46) . "\n";
echo $fail === 0
    ? "  همه‌ی آزمون‌ها موفق بودند ($pass مورد)\n\n"
    : "  موفق: $pass    ناموفق: $fail\n\n";
exit($fail === 0 ? 0 : 1);
