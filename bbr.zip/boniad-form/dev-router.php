<?php
// روتر توسعه برای php -S -t public (در نصب واقعی استفاده نمی‌شود)
$p = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
if ($p !== '/' && is_file(__DIR__ . '/public' . $p)) return false;
require __DIR__ . '/public/index.php';
