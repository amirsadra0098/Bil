#!/usr/bin/env bash
# =============================================================================
#  Personal Information Form System - Ubuntu Installer
#  Nginx + PHP-FPM + (MySQL | MariaDB | PostgreSQL | SQLite) [+ phpMyAdmin]
#
#  Usage:  sudo bash install.sh
#          sudo bash install.sh --db mysql --port 8080 --ssl
# =============================================================================

set -euo pipefail

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# =============================================================================
#  Run password
#  Running this installer requires a password. Only a salted SHA-512 hash of it
#  is stored below (openssl passwd -6). The plain password is never in this file,
#  so reading the script does not reveal it.
#  To change it:  openssl passwd -6   then paste the new hash into INSTALL_PW_HASH.
# =============================================================================
INSTALL_PW_HASH='$6$293fb1534739ac2d$4WvkiD0fpE3bk8/.ZJldwqZdQ8OVRlJqxDbIrj9PBCdmZcmRVG7q2emYdvmIje5TeLI446vaHP2vKeyagxZv.0'

require_run_password() {
  # --help never asks for a password
  for a in "$@"; do [[ "$a" == "-h" || "$a" == "--help" ]] && return 0; done

  command -v openssl >/dev/null 2>&1 || { echo "openssl is required." >&2; exit 1; }

  local salt try input calc
  salt="$(printf '%s' "$INSTALL_PW_HASH" | awk -F'$' '{print $3}')"
  [[ -n "$salt" ]] || { echo "Installer password hash is misconfigured." >&2; exit 1; }

  for try in 1 2 3; do
    if [[ -r /dev/tty ]]; then read -r -s -p "Enter installer password: " input < /dev/tty
    else read -r -s -p "Enter installer password: " input; fi
    echo
    calc="$(openssl passwd -6 -salt "$salt" "$input" 2>/dev/null)"
    input=""
    if [[ "$calc" == "$INSTALL_PW_HASH" ]]; then
      return 0
    fi
    echo "Wrong password ($((3 - try)) attempt(s) left)." >&2
    sleep 2
  done
  echo "Too many wrong attempts. Aborting." >&2
  exit 1
}

require_run_password "$@"


# ---------------------------------------------------------------- defaults
DB_ENGINE=""
APP_PORT="8080"
APP_DIR="/var/www/boniad-form"
APP_USER="www-data"
DB_NAME="boniad_form"
DB_USER="boniad_form"
DB_PASS=""
ADMIN_USER="admin"
ADMIN_PASS=""
DEV_PASS=""
DEV_PATH="dev"
DEV_MODE="no"
INSTALL_PMA="auto"          # auto | yes | no
SECURE_PMA="no"
USE_SSL="no"
ASSUME_YES="no"
DO_UNINSTALL="no"
APT_MIRROR="auto"           # auto | ir | arvan | iranserver | keep | <URL>
PMA_FILE=""
PMA_ROOT="/usr/share/phpmyadmin"
SITE_NAME="boniad-form"

C_R=$'\e[0m'; C_B=$'\e[1m'; C_G=$'\e[32m'; C_Y=$'\e[33m'; C_E=$'\e[31m'; C_C=$'\e[36m'

say()  { echo -e "${C_C}>${C_R} $*"; }
ok()   { echo -e "${C_G}[ OK ]${C_R} $*"; }
warn() { echo -e "${C_Y}[WARN]${C_R} $*"; }
die()  { echo -e "\n${C_E}[FAIL]${C_R} $*\n" >&2; exit 1; }
hr()   { echo -e "${C_C}------------------------------------------------------------${C_R}"; }
bye()  { echo; echo "  Installation cancelled. Nothing was changed."; echo; exit 0; }

trap 'die "Aborted at line $LINENO."' ERR

# --------------------------------------------------------------- arguments
while [[ $# -gt 0 ]]; do
  case "$1" in
    --db)             DB_ENGINE="${2:-}"; shift 2 ;;
    --port)           APP_PORT="${2:-}"; shift 2 ;;
    --dir)            APP_DIR="${2:-}"; shift 2 ;;
    --db-name)        DB_NAME="${2:-}"; shift 2 ;;
    --db-user)        DB_USER="${2:-}"; shift 2 ;;
    --db-pass)        DB_PASS="${2:-}"; shift 2 ;;
    --admin-user)     ADMIN_USER="${2:-}"; shift 2 ;;
    --admin-pass)     ADMIN_PASS="${2:-}"; shift 2 ;;
    --dev-pass)       DEV_PASS="${2:-}"; shift 2 ;;
    --dev-path)       DEV_PATH="${2:-dev}"; shift 2 ;;
    --dev)            DEV_MODE="yes"; shift ;;
    --phpmyadmin)     INSTALL_PMA="yes"; shift ;;
    --no-phpmyadmin)  INSTALL_PMA="no"; shift ;;
    --secure-pma)     SECURE_PMA="yes"; shift ;;
    --ssl)            USE_SSL="yes"; shift ;;
    --mirror)         APT_MIRROR="${2:-auto}"; shift 2 ;;
    --pma-file)       PMA_FILE="${2:-}"; shift 2 ;;
    --no-fonts)       shift ;;                      # kept for compatibility
    -y|--yes)         ASSUME_YES="yes"; shift ;;
    --uninstall)      DO_UNINSTALL="yes"; shift ;;
    -h|--help)
      cat <<'USAGE'
Usage: sudo bash install.sh [options]

  --db <mysql|mariadb|pgsql|sqlite>  Database engine (asked interactively if omitted)
  --port <number>                    Web port (default 8080)
  --dir <path>                       Install path (default /var/www/boniad-form)
  --db-name / --db-user / --db-pass  Database settings
  --admin-user / --admin-pass        Admin panel account (random password if omitted)
  --dev-pass <password>              Password for the private builder panel
                                     (used to show/hide the footer credit).
                                     Asked interactively if omitted.
  --dev-path <name>                  URL of that panel (default: dev  ->  /dev)
  --dev                              Builder mode: asks for your password, then lets
                                     you turn the footer credit on or off.
                                     Does NOT install anything.
  --phpmyadmin | --no-phpmyadmin     Install phpMyAdmin or skip it
  --secure-pma                       Protect /phpmyadmin with an extra HTTP password
  --ssl                              Generate a self-signed certificate and enable HTTPS
  --mirror <auto|ir|iranserver|keep|URL>
                                     APT mirror. "auto" falls back to an Iranian
                                     mirror when the official one is unreachable.
  --pma-file <path>                  Install phpMyAdmin from a local tar.gz (no download)
  -y, --yes                          Run without prompts
  --uninstall                        Remove the service (database and files are kept)
  -h, --help                         Show this help

Examples:
  sudo bash install.sh --dev
  sudo bash install.sh
  sudo bash install.sh --db mysql --port 8080 --ssl --mirror ir -y
  sudo bash install.sh --db mysql --pma-file /root/phpMyAdmin.tar.gz -y
USAGE
      exit 0 ;;
    *) die "Unknown option: $1  (try --help)" ;;
  esac
done

# ----------------------------------------------------------- prerequisites
[[ $EUID -eq 0 ]] || die "This script must run as root:  sudo bash install.sh"
if [[ "$DEV_MODE" != "yes" ]]; then
  command -v apt-get >/dev/null 2>&1 || die "This script supports Ubuntu/Debian only."
  [[ -d "$SRC_DIR/app" && -d "$SRC_DIR/public" ]] || die "Could not find 'app' and 'public' next to install.sh"
fi

# =============================================================================
#  Builder mode:  sudo bash install.sh --dev
#  Asks for the builder password, then toggles the footer credit.
# =============================================================================
if [[ "$DEV_MODE" == "yes" ]]; then
  DEV_TOOL="$APP_DIR/tools/dev.php"
  [[ -f "$DEV_TOOL" ]] || DEV_TOOL="$SRC_DIR/tools/dev.php"
  [[ -f "$DEV_TOOL" ]] || die "Could not find tools/dev.php
   Is the app installed at $APP_DIR ?  Use --dir <path> to point at it."

  RUN_AS=()
  id -u "$APP_USER" >/dev/null 2>&1 && RUN_AS=(sudo -u "$APP_USER")

  STATE="$("${RUN_AS[@]}" php "$DEV_TOOL" status 2>/dev/null || echo error)"

  hr
  echo -e "${C_B}   Builder panel - rhino-team.ir${C_R}"
  hr
  echo

  if [[ "$STATE" == "nopass" ]]; then
    echo "  No builder password is set yet. Create one now."
    echo
    read -r -s -p "  New password (min 8 chars): " P1; echo
    read -r -s -p "  Repeat it: " P2; echo
    [[ "$P1" == "$P2" ]] || die "Passwords do not match."
    printf '%s' "$P1" | "${RUN_AS[@]}" php "$DEV_TOOL" set-pass >/dev/null       || die "Password must be at least 8 characters."
    ok "Password saved."
    STATE="$("${RUN_AS[@]}" php "$DEV_TOOL" status)"
  else
    [[ "$STATE" == "on" || "$STATE" == "off" ]] || die "Cannot read app settings. Is the database running?"
    read -r -s -p "  Your password: " DP; echo
    if ! printf '%s' "$DP" | "${RUN_AS[@]}" php "$DEV_TOOL" verify; then
      die "Wrong password."
    fi
    unset DP
    ok "Signed in."
  fi

  echo
  if [[ "$STATE" == "on" ]]; then
    echo "  Footer credit is currently:  SHOWN"
  else
    echo "  Footer credit is currently:  HIDDEN"
  fi
  echo
  echo "    1) Show the footer credit"
  echo "    2) Hide the footer credit"
  echo "    3) Change builder password"
  echo
  echo "    0) Exit"
  echo
  read -r -p "  Your choice [0]: " DCH
  case "${DCH:-0}" in
    1) "${RUN_AS[@]}" php "$DEV_TOOL" credit-on  >/dev/null; ok "Footer credit is now SHOWN." ;;
    2) "${RUN_AS[@]}" php "$DEV_TOOL" credit-off >/dev/null; ok "Footer credit is now HIDDEN." ;;
    3) read -r -s -p "  New password (min 8 chars): " N1; echo
       read -r -s -p "  Repeat it: " N2; echo
       [[ "$N1" == "$N2" ]] || die "Passwords do not match."
       printf '%s' "$N1" | "${RUN_AS[@]}" php "$DEV_TOOL" set-pass >/dev/null          || die "Password must be at least 8 characters."
       unset N1 N2
       ok "Password changed." ;;
    0|q|Q|exit|quit) bye ;;
    *) die "Invalid choice: '${DCH}'. Pick 0-3." ;;
  esac
  echo
  exit 0
fi

OS_NAME="$( { . /etc/os-release 2>/dev/null && echo "${PRETTY_NAME:-}"; } || true )"
[[ -n "$OS_NAME" ]] || OS_NAME="unknown"

# =============================================================================
#  Uninstall
# =============================================================================
if [[ "$DO_UNINSTALL" == "yes" ]]; then
  hr; say "Removing service..."
  rm -f "/etc/nginx/sites-enabled/$SITE_NAME" "/etc/nginx/sites-available/$SITE_NAME"
  systemctl reload nginx 2>/dev/null || true
  rm -f /usr/local/bin/boniad-backup /etc/cron.d/boniad-backup
  warn "$APP_DIR and the database were NOT deleted, so your data stays safe."
  warn "Delete them manually if you really want to:  rm -rf $APP_DIR"
  ok "Service removed."
  exit 0
fi

# =============================================================================
#  Database selection
# =============================================================================
clear || true
hr
echo -e "${C_B}   Personal Information Form System - Server Installer${C_R}"
echo -e "   OS: $OS_NAME"
hr
echo

if [[ -z "$DB_ENGINE" ]]; then
  cat <<'MENU'
  Which database should be installed?

    1) MySQL       <- Recommended (installs phpMyAdmin too)
                      Stable, graphical admin tool, easy backups, handles
                      many people filling the form at the same time.
    2) MariaDB     Drop-in MySQL replacement, slightly lighter (phpMyAdmin included)
    3) PostgreSQL  Stronger with JSON data, but no real benefit at this scale
    4) SQLite      No separate service, single file. Testing or very few users only.

    0) Exit        Quit without changing anything

MENU
  read -r -p "  Your choice [1]: " choice
  case "${choice:-1}" in
    1) DB_ENGINE="mysql" ;;
    2) DB_ENGINE="mariadb" ;;
    3) DB_ENGINE="pgsql" ;;
    4) DB_ENGINE="sqlite" ;;
    0|q|Q|exit|quit) bye ;;
    *) die "Invalid choice: '${choice}'. Run again and pick 0-4." ;;
  esac
fi

case "$DB_ENGINE" in
  mysql|mariadb|pgsql|sqlite) ;;
  postgres|postgresql) DB_ENGINE="pgsql" ;;
  *) die "Invalid database engine: $DB_ENGINE" ;;
esac

if [[ "$INSTALL_PMA" == "auto" ]]; then
  if [[ "$DB_ENGINE" == "mysql" || "$DB_ENGINE" == "mariadb" ]]; then INSTALL_PMA="yes"; else INSTALL_PMA="no"; fi
fi

PDO_DRIVER="$DB_ENGINE"
[[ "$DB_ENGINE" == "mariadb" ]] && PDO_DRIVER="mysql"

# --------------------------------------------- builder panel password
if [[ -z "$DEV_PASS" && "$ASSUME_YES" != "yes" ]]; then
  echo
  hr
  echo "  Builder panel (only you use this)"
  echo
  echo "  A private page at /$DEV_PATH lets you show or hide the"
  echo "  \"Built by rhino-team.ir\" line in the footer."
  echo "  Choose a password for it. Leave empty to set it later"
  echo "  on first visit to that page."
  echo
  read -r -s -p "  Builder password (min 8 chars, hidden): " DEV_PASS; echo
  if [[ -n "$DEV_PASS" ]]; then
    read -r -s -p "  Repeat it: " DEV_PASS2; echo
    if [[ "$DEV_PASS" != "$DEV_PASS2" ]]; then
      warn "Passwords do not match - you can set it later at /$DEV_PATH"
      DEV_PASS=""
    elif [[ ${#DEV_PASS} -lt 8 ]]; then
      warn "Too short - you can set it later at /$DEV_PATH"
      DEV_PASS=""
    fi
  fi
  hr
fi

[[ -n "$DB_PASS"    ]] || DB_PASS="$(openssl rand -base64 18 | tr -d '/+=' | cut -c1-20)"
[[ -n "$ADMIN_PASS" ]] || ADMIN_PASS="$(openssl rand -base64 12 | tr -d '/+=' | cut -c1-10)Aa1"
APP_KEY="$(openssl rand -hex 32)"
PMA_DB_USER="pmaadmin"
PMA_DB_PASS="$(openssl rand -base64 18 | tr -d '/+=' | cut -c1-20)"
PMA_HTTP_USER="pma"
PMA_HTTP_PASS="$(openssl rand -base64 12 | tr -d '/+=' | cut -c1-12)"

SERVER_IP="$( { hostname -I 2>/dev/null || true; } | awk '{print $1}' )"
[[ -n "$SERVER_IP" ]] || SERVER_IP="127.0.0.1"

echo
hr
echo -e "  ${C_B}Installation summary${C_R}"
echo "   Database   : $DB_ENGINE"
echo "   Install to : $APP_DIR"
echo "   Port       : $APP_PORT"
echo "   phpMyAdmin : $INSTALL_PMA"
echo "   HTTPS      : $USE_SSL"
echo "   APT mirror : $APT_MIRROR"
echo "   Final URL  : http://$SERVER_IP:$APP_PORT"
hr
if [[ "$ASSUME_YES" != "yes" ]]; then
  echo "    [Y] Continue     [N] Exit"
  read -r -p "  Proceed with installation? [Y/n]: " go
  case "${go:-Y}" in
    [Yy]|"") ;;
    *) bye ;;
  esac
fi
echo

export DEBIAN_FRONTEND=noninteractive

# =============================================================================
#  1) APT mirror + base packages
# =============================================================================
reachable() { curl -fsS --max-time 10 -o /dev/null "$1" 2>/dev/null; }

CODENAME="$( { . /etc/os-release 2>/dev/null && echo "${VERSION_CODENAME:-}"; } || true )"
[[ -n "$CODENAME" ]] || CODENAME="noble"
IR_MIRRORS=( "https://mirror.arvancloud.ir/ubuntu" "https://mirror.iranserver.com/ubuntu" )

case "$APT_MIRROR" in
  keep)        MIRROR_URL="" ;;
  auto)        MIRROR_URL="auto" ;;
  ir|arvan)    MIRROR_URL="https://mirror.arvancloud.ir/ubuntu" ;;
  iranserver)  MIRROR_URL="https://mirror.iranserver.com/ubuntu" ;;
  http*)       MIRROR_URL="$APT_MIRROR" ;;
  *) die "Invalid --mirror value: $APT_MIRROR" ;;
esac

if [[ "$MIRROR_URL" == "auto" ]]; then
  say "Checking the official Ubuntu repository..."
  if reachable "http://archive.ubuntu.com/ubuntu/dists/$CODENAME/Release"; then
    ok "Official repository is reachable"
    MIRROR_URL=""
  else
    warn "Official Ubuntu repository is unreachable - trying Iranian mirrors..."
    MIRROR_URL=""
    for m in "${IR_MIRRORS[@]}"; do
      printf "   %-32s " "$(echo "$m" | cut -d/ -f3)"
      if reachable "$m/dists/$CODENAME/Release"; then echo "reachable"; MIRROR_URL="$m"; break
      else echo "unreachable"; fi
    done
    [[ -n "$MIRROR_URL" ]] || die "Neither the official repository nor the Iranian mirrors are reachable.
   Check the server's internet connection, or pass your own mirror:
     sudo bash install.sh --mirror https://mirror.example.ir/ubuntu"
  fi
fi

if [[ -n "$MIRROR_URL" ]]; then
  say "Switching APT to $MIRROR_URL"
  STAMP="$(date +%Y%m%d-%H%M%S)"
  if [[ -f /etc/apt/sources.list.d/ubuntu.sources ]]; then
    cp -a /etc/apt/sources.list.d/ubuntu.sources "/etc/apt/sources.list.d/ubuntu.sources.bak-$STAMP"
    sed -i -E "s#^URIs:.*#URIs: $MIRROR_URL#" /etc/apt/sources.list.d/ubuntu.sources
  fi
  if [[ -s /etc/apt/sources.list ]]; then
    cp -a /etc/apt/sources.list "/etc/apt/sources.list.bak-$STAMP"
    sed -i -E "s#https?://[a-z0-9.-]*archive[.]ubuntu[.]com/ubuntu#$MIRROR_URL#g; s#https?://security[.]ubuntu[.]com/ubuntu#$MIRROR_URL#g" /etc/apt/sources.list
  fi
  ok "Previous repository files backed up with suffix .bak-$STAMP"
fi

say "Updating package lists..."
if ! apt-get update -qq; then
  die "apt-get update failed.
   Try a different mirror:      sudo bash install.sh --mirror iranserver
   Or your organisation mirror: sudo bash install.sh --mirror https://mirror.example.ir/ubuntu"
fi

say "Installing Nginx and PHP..."
if ! apt-get install -y -qq sudo nginx php-fpm php-cli php-mbstring php-xml php-zip \
                            php-curl php-gd curl unzip openssl ca-certificates >/dev/null; then
  die "Installing base packages failed. Check the apt output above."
fi

PHPVER="$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;')"
FPM_SOCK="/run/php/php${PHPVER}-fpm.sock"
ok "PHP $PHPVER installed"

# =============================================================================
#  2) Database
# =============================================================================
DB_HOST="127.0.0.1"
DB_PORT="3306"

case "$DB_ENGINE" in
  mysql|mariadb)
    if [[ "$DB_ENGINE" == "mysql" ]]; then
      say "Installing MySQL Server..."
      if ! apt-get install -y -qq mysql-server >/dev/null 2>&1; then
        warn "Package mysql-server is not available; installing MariaDB instead."
        apt-get install -y -qq mariadb-server >/dev/null
        DB_ENGINE="mariadb"
      fi
    else
      say "Installing MariaDB Server..."
      apt-get install -y -qq mariadb-server >/dev/null
    fi
    apt-get install -y -qq "php${PHPVER}-mysql" >/dev/null 2>&1 || apt-get install -y -qq php-mysql >/dev/null

    systemctl enable --now mysql 2>/dev/null || systemctl enable --now mariadb 2>/dev/null || true
    sleep 2

    say "Creating database and user..."
    mysql <<SQL
CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';
ALTER USER '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';
GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'localhost';
CREATE USER IF NOT EXISTS '${PMA_DB_USER}'@'localhost' IDENTIFIED BY '${PMA_DB_PASS}';
ALTER USER '${PMA_DB_USER}'@'localhost' IDENTIFIED BY '${PMA_DB_PASS}';
GRANT ALL PRIVILEGES ON *.* TO '${PMA_DB_USER}'@'localhost' WITH GRANT OPTION;
FLUSH PRIVILEGES;
SQL
    ok "Database '${DB_NAME}' is ready"
    ;;

  pgsql)
    say "Installing PostgreSQL..."
    apt-get install -y -qq postgresql postgresql-contrib >/dev/null
    apt-get install -y -qq "php${PHPVER}-pgsql" >/dev/null 2>&1 || apt-get install -y -qq php-pgsql >/dev/null
    systemctl enable --now postgresql
    DB_PORT="5432"
    sleep 2
    say "Creating database and user..."
    sudo -u postgres psql -v ON_ERROR_STOP=0 <<SQL >/dev/null
DO \$\$ BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = '${DB_USER}') THEN
    CREATE ROLE ${DB_USER} LOGIN PASSWORD '${DB_PASS}';
  ELSE
    ALTER ROLE ${DB_USER} WITH PASSWORD '${DB_PASS}';
  END IF;
END \$\$;
SQL
    sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname='${DB_NAME}'" | grep -q 1 || \
      sudo -u postgres createdb -O "${DB_USER}" -E UTF8 "${DB_NAME}"
    sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE ${DB_NAME} TO ${DB_USER};" >/dev/null
    ok "Database '${DB_NAME}' is ready"
    ;;

  sqlite)
    say "Installing SQLite..."
    apt-get install -y -qq sqlite3 >/dev/null
    apt-get install -y -qq "php${PHPVER}-sqlite3" >/dev/null 2>&1 || apt-get install -y -qq php-sqlite3 >/dev/null
    DB_NAME="${APP_DIR}/storage/db/form.sqlite"
    ok "SQLite is ready"
    ;;
esac

# =============================================================================
#  3) Deploy application files
# =============================================================================
say "Copying application files to $APP_DIR ..."
mkdir -p "$APP_DIR"
rm -rf "$APP_DIR/app" "$APP_DIR/public" "$APP_DIR/tools"
cp -r "$SRC_DIR/app" "$SRC_DIR/public" "$APP_DIR/"
[[ -d "$SRC_DIR/tools" ]] && cp -r "$SRC_DIR/tools" "$APP_DIR/" || true
rm -f "$APP_DIR/app/config.php"
[[ -f "$SRC_DIR/README.md" ]] && cp "$SRC_DIR/README.md" "$APP_DIR/" || true
mkdir -p "$APP_DIR/storage/logs" "$APP_DIR/storage/db" "$APP_DIR/storage/backup" "$APP_DIR/storage/branding"

cat > "$APP_DIR/app/config.php" <<PHPCONF
<?php
return [
    'org_title'  => 'بنیاد مسکن انقلاب اسلامی',
    'form_title' => 'فرم اطلاعات فردی',
    'sub_title'  => 'مدیریت حراست',
    'base_path'  => '',
    'dev_path'   => '${DEV_PATH}',
    'app_key'    => '${APP_KEY}',
    'db' => [
        'driver'   => '${PDO_DRIVER}',
        'host'     => '${DB_HOST}',
        'port'     => ${DB_PORT},
        'database' => '${DB_NAME}',
        'username' => '${DB_USER}',
        'password' => '${DB_PASS}',
    ],
    'rate_limit_per_hour' => 8,
    'debug' => false,
];
PHPCONF

chown -R "$APP_USER":"$APP_USER" "$APP_DIR"
find "$APP_DIR" -type d -exec chmod 750 {} \;
find "$APP_DIR" -type f -exec chmod 640 {} \;
chmod -R 770 "$APP_DIR/storage"
chmod 640 "$APP_DIR/app/config.php"
ok "Files deployed"

# ------------------------------------------------------------ syntax check
say "Checking PHP files for syntax errors..."
SYNTAX_FAIL=0
while IFS= read -r -d '' f; do
  if ! php -l "$f" >/dev/null 2>&1; then
    echo -e "${C_E}   Syntax error in: $f${C_R}"
    php -l "$f" || true
    SYNTAX_FAIL=1
  fi
done < <(find "$APP_DIR/app" "$APP_DIR/public" -name '*.php' -print0)
[[ $SYNTAX_FAIL -eq 0 ]] || die "Some PHP files contain syntax errors."
ok "All PHP files are valid"

# =============================================================================
#  4) Create tables and the admin account
# =============================================================================
say "Creating database tables..."
MIGRATE_ARGS=( --admin-user="$ADMIN_USER" --admin-pass="$ADMIN_PASS" )
[[ -n "$DEV_PASS" ]] && MIGRATE_ARGS+=( --dev-pass="$DEV_PASS" )
sudo -u "$APP_USER" php "$APP_DIR/app/migrate.php" "${MIGRATE_ARGS[@]}"
ok "Database schema ready"

if [[ "$DB_ENGINE" == "sqlite" ]]; then
  chown -R "$APP_USER":"$APP_USER" "$APP_DIR/storage"
  chmod -R 770 "$APP_DIR/storage/db"
fi

# =============================================================================
#  5) Fonts (shipped with the app, no download needed)
# =============================================================================
FONT_DIR="$APP_DIR/public/assets/fonts"
if compgen -G "$FONT_DIR/*.woff2" >/dev/null; then
  chown -R "$APP_USER":"$APP_USER" "$FONT_DIR"
  chmod 640 "$FONT_DIR"/* 2>/dev/null || true
  ok "Vazirmatn font bundled with the app (no internet required)"
else
  warn "Font files are missing from the app folder; system fonts will be used."
fi

# =============================================================================
#  6) phpMyAdmin
# =============================================================================
PMA_ENABLED="no"
if [[ "$INSTALL_PMA" == "yes" ]]; then
  say "Installing phpMyAdmin..."
  TMPZ="/tmp/pma.tar.gz"
  PMA_GOT=0
  if [[ -n "$PMA_FILE" ]]; then
    if [[ -f "$PMA_FILE" ]]; then
      cp "$PMA_FILE" "$TMPZ"; PMA_GOT=1
      say "Using local archive: $PMA_FILE"
    else
      warn "phpMyAdmin archive not found: $PMA_FILE"
    fi
  fi
  if [[ $PMA_GOT -eq 0 ]] && curl -fsSL --max-time 120 -o "$TMPZ" \
       "https://www.phpmyadmin.net/downloads/phpMyAdmin-latest-all-languages.tar.gz"; then
    PMA_GOT=1
  fi
  if [[ $PMA_GOT -eq 1 ]]; then
    rm -rf "$PMA_ROOT"; mkdir -p "$PMA_ROOT"
    tar -xzf "$TMPZ" --strip-components=1 -C "$PMA_ROOT"
    rm -f "$TMPZ"
    BLOWFISH="$(openssl rand -hex 16)"
    cat > "$PMA_ROOT/config.inc.php" <<PMACONF
<?php
\$cfg['blowfish_secret'] = '${BLOWFISH}';
\$i = 1;
\$cfg['Servers'][\$i]['auth_type']  = 'cookie';
\$cfg['Servers'][\$i]['host']       = '127.0.0.1';
\$cfg['Servers'][\$i]['compress']   = false;
\$cfg['Servers'][\$i]['AllowNoPassword'] = false;
\$cfg['UploadDir']   = '';
\$cfg['SaveDir']     = '';
\$cfg['TempDir']     = '${PMA_ROOT}/tmp';
\$cfg['DefaultLang'] = 'fa';
\$cfg['LoginCookieValidity'] = 3600;
PMACONF
    mkdir -p "$PMA_ROOT/tmp"
    chown -R "$APP_USER":"$APP_USER" "$PMA_ROOT/tmp" "$PMA_ROOT/config.inc.php"
    chmod 700 "$PMA_ROOT/tmp"
    PMA_ENABLED="yes"
    ok "phpMyAdmin installed"

    if [[ "$SECURE_PMA" == "yes" ]]; then
      apt-get install -y -qq apache2-utils >/dev/null
      htpasswd -bc /etc/nginx/.pma_htpasswd "$PMA_HTTP_USER" "$PMA_HTTP_PASS" >/dev/null 2>&1
      chown root:"$APP_USER" /etc/nginx/.pma_htpasswd; chmod 640 /etc/nginx/.pma_htpasswd
      ok "phpMyAdmin protected with an extra HTTP password"
    fi
  else
    warn "Downloading phpMyAdmin failed. Trying the apt package..."
    if apt-get install -y -qq phpmyadmin >/dev/null 2>&1; then
      PMA_ROOT="/usr/share/phpmyadmin"; PMA_ENABLED="yes"; ok "phpMyAdmin installed from apt"
    else
      warn "phpMyAdmin was not installed. The system works fine without it."
      warn "Install it later with:  sudo bash install.sh --pma-file /path/to/phpMyAdmin.tar.gz"
    fi
  fi
fi

# =============================================================================
#  7) Self-signed certificate
# =============================================================================
SSL_DIR="/etc/ssl/boniad-form"
if [[ "$USE_SSL" == "yes" ]]; then
  say "Generating self-signed certificate for $SERVER_IP ..."
  mkdir -p "$SSL_DIR"
  openssl req -x509 -nodes -newkey rsa:2048 -days 3650 \
    -keyout "$SSL_DIR/server.key" -out "$SSL_DIR/server.crt" \
    -subj "/C=IR/O=Boniad Maskan/CN=$SERVER_IP" \
    -addext "subjectAltName=IP:$SERVER_IP,DNS:localhost" >/dev/null 2>&1
  chmod 600 "$SSL_DIR/server.key"
  ok "Certificate created (browsers will show a warning - that is expected)"
fi

# =============================================================================
#  8) Nginx
# =============================================================================
say "Configuring Nginx..."

PMA_BLOCK=""
if [[ "$PMA_ENABLED" == "yes" ]]; then
  PMA_AUTH=""
  if [[ "$SECURE_PMA" == "yes" ]]; then
    PMA_AUTH="        auth_basic \"phpMyAdmin\";
        auth_basic_user_file /etc/nginx/.pma_htpasswd;"
  fi
  PMA_BLOCK="
    location ^~ /phpmyadmin {
        alias ${PMA_ROOT};
        index index.php;
${PMA_AUTH}

        location ~ ^/phpmyadmin/(.+\.php)\$ {
            alias ${PMA_ROOT}/\$1;
            fastcgi_pass unix:${FPM_SOCK};
            fastcgi_index index.php;
            include fastcgi_params;
            fastcgi_param SCRIPT_FILENAME \$request_filename;
        }
        location ~* ^/phpmyadmin/(.+\.(jpg|jpeg|gif|css|png|js|ico|html|xml|txt|woff2?|svg|map))\$ {
            alias ${PMA_ROOT}/\$1;
        }
    }
"
fi

SSL_LISTEN=""
if [[ "$USE_SSL" == "yes" ]]; then
  SSL_LISTEN="    listen ${APP_PORT} ssl;
    ssl_certificate     ${SSL_DIR}/server.crt;
    ssl_certificate_key ${SSL_DIR}/server.key;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers off;"
else
  SSL_LISTEN="    listen ${APP_PORT};"
fi

cat > "/etc/nginx/sites-available/${SITE_NAME}" <<NGINX
server {
${SSL_LISTEN}
    server_name _;

    root ${APP_DIR}/public;
    index index.php;

    charset utf-8;
    client_max_body_size 12m;
    client_body_timeout 120s;

    access_log /var/log/nginx/${SITE_NAME}.access.log;
    error_log  /var/log/nginx/${SITE_NAME}.error.log;

    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "same-origin" always;

    gzip on;
    gzip_types text/css application/javascript application/json image/svg+xml;
    gzip_min_length 512;

    location / {
        try_files \$uri \$uri/ /index.php\$is_args\$args;
    }

    location ~ ^/index\.php(/|\$) {
        fastcgi_pass unix:${FPM_SOCK};
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        fastcgi_param PATH_INFO \$fastcgi_path_info;
        fastcgi_read_timeout 120;
        fastcgi_buffers 16 16k;
        fastcgi_buffer_size 32k;
    }

    location ~* \.(css|js|woff2?|png|jpg|jpeg|svg|ico)\$ {
        expires 7d;
        access_log off;
        try_files \$uri =404;
    }

    location ~ /\. { deny all; }
    location ~ \.php\$ { return 404; }
${PMA_BLOCK}
}
NGINX

ln -sf "/etc/nginx/sites-available/${SITE_NAME}" "/etc/nginx/sites-enabled/${SITE_NAME}"
if [[ "$APP_PORT" == "80" && -e /etc/nginx/sites-enabled/default ]]; then
  rm -f /etc/nginx/sites-enabled/default
fi

nginx -t >/dev/null 2>&1 || { nginx -t; die "Nginx configuration is invalid."; }
systemctl enable --now nginx >/dev/null 2>&1 || true
systemctl reload nginx
systemctl enable --now "php${PHPVER}-fpm" >/dev/null 2>&1 || true
systemctl restart "php${PHPVER}-fpm"
ok "Nginx configured"

# =============================================================================
#  9) Firewall
# =============================================================================
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -qi "^Status: active"; then
  ufw allow "${APP_PORT}/tcp" >/dev/null 2>&1 || true
  ok "Port ${APP_PORT} opened in the firewall"
fi

# =============================================================================
#  10) Backup script
# =============================================================================
say "Installing the backup script..."
cat > /usr/local/bin/boniad-backup <<BACKUP
#!/usr/bin/env bash
# Database backup for the Personal Information Form System
set -euo pipefail
APP_DIR="${APP_DIR}"
OUT="\${APP_DIR}/storage/backup"
STAMP="\$(date +%Y-%m-%d_%H%M%S)"
mkdir -p "\$OUT"

case "${PDO_DRIVER}" in
  mysql)
    mysqldump --single-transaction --default-character-set=utf8mb4 \\
      -u '${DB_USER}' -p'${DB_PASS}' '${DB_NAME}' | gzip > "\$OUT/db_\${STAMP}.sql.gz" ;;
  pgsql)
    PGPASSWORD='${DB_PASS}' pg_dump -h 127.0.0.1 -U '${DB_USER}' '${DB_NAME}' | gzip > "\$OUT/db_\${STAMP}.sql.gz" ;;
  sqlite)
    gzip -c '${DB_NAME}' > "\$OUT/db_\${STAMP}.sqlite.gz" ;;
esac

find "\$OUT" -name 'db_*.gz' -mtime +30 -delete
echo "Backup created: \$OUT/db_\${STAMP}"
BACKUP
chmod 750 /usr/local/bin/boniad-backup

cat > /etc/cron.d/boniad-backup <<CRON
# Daily backup at 02:00
0 2 * * * root /usr/local/bin/boniad-backup >/dev/null 2>&1
CRON
ok "Daily backup enabled (storage/backup, 30 copies kept)"

# =============================================================================
#  11) Final checks
# =============================================================================
if [[ -f "$APP_DIR/tools/selftest.php" ]]; then
  say "Running the built-in test suite..."
  if sudo -u "$APP_USER" php "$APP_DIR/tools/selftest.php"; then
    ok "Built-in tests passed"
  else
    warn "Some built-in tests failed - review the output above."
  fi
fi

say "Checking the login captcha..."
if php -r 'exit(extension_loaded("gd") && function_exists("imagettftext") ? 0 : 1);'; then
  if [[ -f "$APP_DIR/public/assets/fonts/Vazirmatn-Bold.ttf" ]] \
     || ls /usr/share/fonts/truetype/dejavu/*.ttf >/dev/null 2>&1; then
    ok "Image captcha is ready"
  else
    warn "No TrueType font found; captcha will be drawn at lower quality."
  fi
else
  warn "PHP GD extension is missing; captcha falls back to SVG."
fi

say "Testing the service..."
SCHEME="http"; [[ "$USE_SSL" == "yes" ]] && SCHEME="https"
sleep 1
HTTP_CODE="$(curl -sk -o /dev/null -w '%{http_code}' --max-time 15 "$SCHEME://127.0.0.1:$APP_PORT/" || echo 000)"
if [[ "$HTTP_CODE" == "200" ]]; then
  ok "Service responds (HTTP $HTTP_CODE)"
else
  warn "Service returned HTTP $HTTP_CODE"
  warn "Logs: /var/log/nginx/${SITE_NAME}.error.log and $APP_DIR/storage/logs/php-error.log"
fi

# =============================================================================
#  Summary
# =============================================================================
CRED_FILE="/root/boniad-form-credentials.txt"
{
  echo "==============================================================="
  echo " Personal Information Form System - Installation details"
  echo " Installed at: $(date)"
  echo "==============================================================="
  echo
  echo "[ URLs ]"
  echo "  Public form   : $SCHEME://$SERVER_IP:$APP_PORT/"
  echo "  Admin panel   : $SCHEME://$SERVER_IP:$APP_PORT/admin"
  echo "  Track status  : $SCHEME://$SERVER_IP:$APP_PORT/track"
  [[ "$PMA_ENABLED" == "yes" ]] && echo "  phpMyAdmin    : $SCHEME://$SERVER_IP:$APP_PORT/phpmyadmin"
  echo
  echo "[ Admin panel login ]"
  echo "  Username : $ADMIN_USER"
  echo "  Password : $ADMIN_PASS"
  echo
  echo "[ Database ($DB_ENGINE) ]"
  echo "  Name     : $DB_NAME"
  echo "  User     : $DB_USER"
  echo "  Password : $DB_PASS"
  if [[ "$PMA_ENABLED" == "yes" ]]; then
    echo
    echo "[ phpMyAdmin login ]"
    echo "  User     : $PMA_DB_USER"
    echo "  Password : $PMA_DB_PASS"
    if [[ "$SECURE_PMA" == "yes" ]]; then
      echo "  Extra HTTP auth -> user: $PMA_HTTP_USER  password: $PMA_HTTP_PASS"
    fi
  fi
  echo
  echo "[ Paths ]"
  echo "  Application  : $APP_DIR"
  echo "  Config file  : $APP_DIR/app/config.php"
  echo "  App log      : $APP_DIR/storage/logs/php-error.log"
  echo "  Nginx log    : /var/log/nginx/${SITE_NAME}.error.log"
  echo "  Backups      : $APP_DIR/storage/backup  (daily at 02:00)"
  echo "  Manual backup: sudo /usr/local/bin/boniad-backup"
} > "$CRED_FILE"
chmod 600 "$CRED_FILE"

echo
hr
echo -e "  ${C_G}${C_B}Installation completed successfully${C_R}"
hr
cat "$CRED_FILE"
hr
echo -e "  ${C_Y}These details were saved to:${C_R} $CRED_FILE"
[[ "$USE_SSL" != "yes" ]] && echo -e "  ${C_Y}Tip:${C_R} re-run with --ssl to encrypt traffic on the network."
echo -e "  ${C_Y}Change the admin password from Settings after your first login.${C_R}"
echo
